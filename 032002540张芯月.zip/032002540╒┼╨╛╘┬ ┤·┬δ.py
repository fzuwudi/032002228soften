
import csv
import time
import requests
from lxml import etree
import re


def get_index():
    # 请求头
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Cookie": "sVoELocvxVW0S=5kg1.lFMQ0hlKDnWW2pesQmpsknehFKkwP9YhfZ5qvrxbdurnNYGW7yvKu4cBur1cp0XQSeJ7x2YDWu86S28ziG; yfx_c_g_u_id_10006654=_ck22042910223211215570902119737; insert_cookie=67313298; yfx_f_l_v_t_10006654=f_t_1651198952121__r_t_1663405559870__v_t_1663422731911__r_c_1; security_session_verify=b6451a64bc2c34b92c0d7728a901633c; sVoELocvxVW0T=53nUVRbW20daqqqDk1ZKXfGI9GmEqnIjqwtW5SSoF91zRmMwbK6fXvSAKyuxlRbEt2FIi_83YBDqJWx9ZAMli5hQK9Z0r0442i._s.72XU4LFAEswKLvp5QcvuvhnPRJK8FqV72qgqUU8lVt_9NC2e1KT_qDqheXd7mY0c2q.25voRqPFk5hpQTgtwczXhpBLws6NIyCmCdNJ6l4N9qURdMsXqN..VOjIzrDVjEitTSofh03wHPv9DCZkYfoCIO0jFV4giSoy__74ZBVHbzRfczQ0FSiKixlKhXLr4vXrgecO6AlC40ihD4FhQsYu0TdoQ",
        "Host": "www.nhc.gov.cn",
        "Pragma": "no-cache",
        "Referer": "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_2.shtml",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33"
    }
    # 循环1~43页
    for i in range(1, 43):
        # 第一页的url和后续构造不同，所以单独写
        if i == 1:
            url = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml"
        else:
            url = f'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_{i}.shtml'
        # 访问，写入头，url
        r = requests.get(url, headers=headers, verify=False)
        html = etree.HTML(r.text)
        # print(r.text)
        # 提取文本，并利用xpath提取要的全部节点
        lis = html.xpath('.//ul[@class="zxxx_list"]/li')
        print(f'正在保存第{i}页...')
        # 遍历节点，提取url，title，url用于后续访问，title用于后续文本命名
        for li in lis:
            href = li.xpath('.//a/@href')
            title = li.xpath('.//a/@title')
            print(title[0], 'http://www.nhc.gov.cn' + href[0])
            with open('url_info.csv', 'a', encoding='utf-8', newline='') as f:
                writer = csv.writer(f)
                writer.writerow([title[0], 'http://www.nhc.gov.cn' + href[0]])
        time.sleep(1)


def get_info():
    headers = {
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
        "Accept-Encoding": "gzip, deflate",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
        "Cache-Control": "no-cache",
        "Connection": "keep-alive",
        "Cookie": "sVoELocvxVW0S=5kg1.lFMQ0hlKDnWW2pesQmpsknehFKkwP9YhfZ5qvrxbdurnNYGW7yvKu4cBur1cp0XQSeJ7x2YDWu86S28ziG; yfx_c_g_u_id_10006654=_ck22042910223211215570902119737; insert_cookie=67313298; yfx_f_l_v_t_10006654=f_t_1651198952121__r_t_1663405559870__v_t_1663425683243__r_c_1; security_session_verify=1db8371cde04995c3cbc3d9f81e68265; sVoELocvxVW0T=53nUGHKW26eWqqqDk1dPl_A5qd4FOXqAXZHnhD3O53.wjPSsiJH9dXSJpbI8eJJzZI6UI9pzZH_vM4D5dnueKnxbEMUYDqMoFT3cx_8KQoJylBJtazU7K7cdfKZwA1zq0bHMHRh3CHLlMMZI7NGSqkR7G4u.KnBhcTj_Cg6K9BpJLZV_kda_12oIBppUD4rQATfK6CkDzp02KK1uZd8kiCoD6n83dj4Cd3SKSWgaB5QVRaurWEaVPgkGDzgaktnSih_IRhQQ4sCrhr4EqfwNoD0xMp_hbI8dSIpL6y.4SqR_a",
        "Host": "www.nhc.gov.cn",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33"
    }
    # 调用第一个函数跑出来的结果
    with open('url_info.csv', 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        step = 1
        for row in reader:
            # 设置阙值，因为cookie很容易过期，所以需要手动更改一下
            if step == 141:  # >= 308
                print(f'正在爬取第{step}页...')
                print(row[1])
                r = requests.get(url=row[1], headers=headers, timeout=5)
                html = etree.HTML(r.text)
                ps = html.xpath('.//div[@id="xw_box"]/p')
                # 这个是为了防止cookie过期后，无内容跑，直接break，提示换headers
                if not ps:
                    print(f'第{step}页无内容')
                    break
                # 遍历全部的段落，将段落按行写入txt，txt的命名就是上个函数获取的标题title
                for p in ps:
                    texts = p.xpath('.//text()')
                    content = ''
                    for text in texts:
                        content += text
                    print(content)
                    with open(f'./文本/{row[0]}.txt', 'a', encoding='utf-8') as ff:
                        ff.write(content)
                        ff.write('\n')
                time.sleep(1)
            step += 1


def ana_data():
    # 这里为了获取全部的标题，所以再次打开了url_info.csv
    with open('url_info.csv', 'r', encoding='utf-8') as f:
        reader = csv.reader(f)
        step = 1
        for row in reader:
            # 这个total是全国新增，无症状，这样写为了防止后续如果没有内容，造成缺少数据
            total = [row[0], 0, 0]
            # 控制到今年之内的数据
            if step <= 259:
                print(row[0])
                with open(f'./文本/{row[0]}.txt', 'r', encoding='utf-8') as ff:
                    # 按行读取，因为要的内容在第一行和第三行
                    contents = ff.readlines()
                    # 这个字典存储每个省份的确诊
                    data_china = {}
                    # 这个字段存储每个省份的无症状
                    data_province = {}
                    for content_ in contents:
                        # 删除换行符
                        content = content_.strip()
                        # 匹配到全国新增
                        if content.count('新增确诊病例'):
                            # 匹配每个省份的确诊的那一段文本
                            self_tu = re.findall('本土病例(.*?)无症状感染者', content, re.S)
                            # 因为有两种写法，这里再次写了个正则，防止拿不到数据
                            if self_tu:
                                pass
                            else:
                                self_tu = re.findall('本土病例(.*?)）', content, re.S)
                            # 遍历全部省份，拿到所有确诊数
                            for city in ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                                         '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                                         '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海', '天津']:
                                num = re.findall(f'{city}(.*?)例', self_tu[0], re.S)
                                # 因为不一定有全部省份，所以加入try,如果不含有该省份确诊就跳过
                                try:
                                    data_china[city] = data_china.get(city, 0) + int(num[0])
                                except:
                                    pass
                            # 输出方便调试
                            print(self_tu)
                            print(data_china)
                            # 这里加入标题，供后续方便查看
                            store_all = [row[0]]
                            # 再次遍历省份，拿到每个省的确诊人数，全国的本土确诊
                            for city in ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                                         '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                                         '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海', '天津']:
                                # 拿每个省的确诊人数
                                try:
                                    num = data_china.get(city)
                                    store_all.append(int(num))
                                except:
                                    store_all.append(0)
                            # 求全国的确诊人数
                            total[1] = sum(store_all[1:])
                            with open('all_province_sure.csv', 'a', encoding='utf-8', newline='') as f_al:
                                writer1 = csv.writer(f_al)
                                writer1.writerow(store_all)
                            # print(content)
                        # 匹配无症状
                        if content.count('新增无症状感染者'):
                            # 匹配无症状的那段话
                            self_tu_no = re.findall('本土(.*?)）', content, re.S)
                            # 下面实现和上面确诊是一样的
                            if self_tu_no:
                                print(self_tu_no)
                                for city in ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                                             '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                                             '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海']:
                                    num = re.findall(f'{city}(.*?)例', self_tu_no[0], re.S)
                                    try:
                                        data_province[city] = data_province.get(city, 0) + int(num[0])
                                    except:
                                        pass
                                store_all = [row[0]]
                                for city in ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                                             '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                                             '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海', '天津']:
                                    try:
                                        num = data_province.get(city)
                                        store_all.append(int(num))
                                    except:
                                        store_all.append(0)
                                total[2] = sum(store_all[1:])
                                with open('all_province_unsure.csv', 'a', encoding='utf-8', newline='') as f_al:
                                    writer1 = csv.writer(f_al)
                                    writer1.writerow(store_all)
                                print(data_province)
                                # print(content)
                            # 如果没数据，就全写0
                            else:
                                for city in ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                                             '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                                             '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海', '天津']:
                                    try:
                                        num = data_province.get(city)
                                        store_all.append(num)
                                    except:
                                        store_all.append(0)
                                with open('all_province_unsure.csv', 'a', encoding='utf-8', newline='') as f_al:
                                    writer1 = csv.writer(f_al)
                                    writer1.writerow(store_all)
                                print(self_tu_no)
                                print(data_province)
                with open('all_total.csv', 'a', encoding='utf-8', newline='') as f_total:
                    writer_total = csv.writer(f_total)
                    writer_total.writerow(total)
            step += 1


if __name__ == '__main__':
    # 写入文件夹,将全省确诊写入all_province_sure.csv,将全省无症状写入all_province_unsure.csv,将全国的写入all_total.csv
    with open('all_province_sure.csv', 'a', encoding='utf-8', newline='') as fff:
        writer = csv.writer(fff)
        writer.writerow(['日期', '河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                        '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                        '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海', '天津'])
    with open('all_province_unsure.csv', 'a', encoding='utf-8', newline='') as fff:
        writer = csv.writer(fff)
        writer.writerow(['日期', '河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '重庆',
                        '江西', '山东', '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '北京',
                        '云南', '陕西', '甘肃', '青海', '内蒙', '广西', '西藏', '宁夏', '新疆', '上海', '天津'])
    with open('all_total.csv', 'a', encoding='utf-8', newline='') as fff:
        writer = csv.writer(fff)
        writer.writerow(['日期', '全国新增', '全国无症状'])
    # 这个模块是爬取外部全部链接,就是进入内部提取文件的详细地址,保存至url_info.csv
     get_index()
    # 这个模块是访问每天的具体内容,随后将内容按行写入文本文件夹中的txt
      get_info()
    # 这个模块是分析数据，提取数据，将数据提取出来放到上面的三个文件夹
    ana_data()
