
import os
import asyncio
import re
import xlwt
from pyppeteer import launcher
from pyecharts import options as opts
from pyecharts.charts import Map
from pyecharts.faker import Faker
# 在导入 launch 之前 把 --enable-automation 禁用 防止监测webdriver
launcher.DEFAULT_ARGS.remove("--enable-automation")

from pyppeteer import launch
from bs4 import BeautifulSoup


async def pyppteer_fetchUrl(url):
    browser = await launch({'headless': False, 'dumpio': True, 'autoClose': True})
    page = await browser.newPage()

    await page.goto(url)
    await asyncio.wait([page.waitForNavigation()])
    str = await page.content()
    await browser.close()
    return str


def fetchUrl(url):
    return asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(url))


def getPageUrl():
    for page in range(1, 10):
        if page == 1:
            yield 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
        else:
            surl = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_' + str(page) + '.shtml'
            yield surl


def getTitleUrl(html):
    bsobj = BeautifulSoup(html, 'html.parser')
    titleList = bsobj.find('div', attrs={"class": "list"}).ul.find_all("li")
    for item in titleList:
        link = "http://www.nhc.gov.cn" + item.a["href"]
        title = item.a["title"]
        date = item.span.text
        yield title, link, date


def getContent(html):
    bsobj = BeautifulSoup(html, 'html.parser')
    cnt = bsobj.find('div', attrs={"id": "xw_box"}).find_all("p")
    s = ""
    if cnt:
         for item in cnt:
            s += item.text
         return s
    return "爬取失败！"


def saveFile(path, filename, content):
    if not os.path.exists(path):
        os.makedirs(path)

    # 保存文件
    with open(path + filename + ".txt", 'w', encoding='utf-8') as f:
        f.write(content)

def special_area_data(mes1,mes2):#根据今日与昨日数据获取港澳台新增确诊数据
    dict={'香港':0,'澳门':0, '台湾':0}
    datalist=[]
    for i in range(1,4):
        data1 = re.search('累计收到港澳台地区通报确诊病例.*?例。其中.*?香港特别行政区(.*?)例.*?澳门特别行政区(.*?)例.*?台湾地区(.*?)例',mes1).group(i)
        data2 = re.search('累计收到港澳台地区通报确诊病例.*?例。其中.*?香港特别行政区(.*?)例.*?澳门特别行政区(.*?)例.*?台湾地区(.*?)例',mes2).group(i)
        datalist.append(int(data1)-int(data2))
    count=0
    for i in dict.keys():
        dict[i]=datalist[count]
        count+=1
    return dict




def data_detail(str):#获取各个省市数据
    dict = \
    {
        "西藏": 0, "澳门": 0, "青海": 0, "台湾": 0, "香港": 0, "贵州": 0, "吉林": 0, "新疆": 0, "宁夏": 0, "内蒙古": 0,
        "甘肃": 0,
        "天津": 0, "山西": 0, "辽宁": 0, "黑龙江": 0, "海南": 0, "河北": 0, "陕西": 0, "云南": 0, "广西": 0, "福建": 0,
        "上海": 0,
        "北京": 0, "江苏": 0, "四川": 0, "山东": 0, "江西": 0, "重庆": 0, "安徽": 0, "湖南": 0, "河南": 0, "广东": 0,
        "浙江": 0, "湖北": 0
    }
    provi = \
        ["(西藏)(.*?)例", "(澳门)(.*?)例", "(青海)(.*?)例", "(台湾)(.*?)例", "(香港)(.*?)例", "(贵州)(.*?)例",
         "(吉林)(.*?)例", "(新疆)(.*?)例", "(宁夏)(.*?)例", "(内蒙古)(.*?)例",
         "(甘肃)(.*?)例", "(天津)(.*?)例", "(山西)(.*?)例", "(辽宁)(.*?)例", "(黑龙江)(.*?)例", "(海南)(.*?)例",
         "(河北)(.*?)例", "(陕西)(.*?)例", "(云南)(.*?)例", "(广西)(.*?)例",
         "(福建)(.*?)例", "(上海)(.*?)例", "(北京)(.*?)例", "(江苏)(.*?)例", "(四川)(.*?)例", "(山东)(.*?)例",
         "(江西)(.*?)例", "(重庆)(.*?)例", "(安徽)(.*?)例", "(湖南)(.*?)例",
         "(河南)(.*?)例", "(广东)(.*?)例", "(浙江)(.*?)例", "(湖北)(.*?)例"]

    for item in provi:
        num = re.search(item, str)
        if num:
            dict[num.group(1)] = int(num.group(2))

    return dict


def write_file(data):
    book = xlwt.Workbook(encoding='utf-8') #创建Workbook，相当于创建Excel

    # 创建sheet，Sheet1为表的名字，cell_overwrite_ok为是否覆盖单元格
    sheet1 = book.add_sheet(u'Sheet1', cell_overwrite_ok=True)

    data1={}
    r = 0

    for i in data.keys():   # i表示data中的key，j表示data中的value
        sheet1.write(r, 0, i)
    for j in data.values():
        sheet1.write(r, 0, j)

        r += 1  # 行数

    #sheet_merge() 合并单元格

    book.save('D:\系统默认\桌面\dataa.xlsx')


if "__main__" == __name__:
    for url in getPageUrl():
        s = fetchUrl(url)
        for title, link, date in getTitleUrl(s):
            print(title, link)

            html = fetchUrl(link)
            content = getContent(html)
            print(content)

            gat_data1={}
            gat_data2={}

            number = 0
            if number == 0:
                gat_data1=content
                number = 1
            else:
                gat_data2 = content
                number = 0

         #   gat_data = special_area_data(gat_data1, gat_data2)


            news = content
            # print(news)   #每页全部信息
            ch_all_dict = {}
            province_all_dict = {}  # 用于记录省份的每日新增等数据
            every_province_dict_1 = {}
            every_province_dict_2 = {}
            all_dict = {} #用于记录全中国的每日新增等数据

            all_dict['今日日期'] = re.search('截至(.*?)24时', news).group(1)  # group(1)代表括号里的内容
            print(all_dict['今日日期'])
            # 全中国的新增确诊人数
            all_dict['新增确诊'] = re.search('31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例(.*?)；本土(.*?)例', news).group(2)
            # 全中国的新增新增无症状
            all_dict['新增无症状'] = re.search('31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者(.*?)，本土(.*?)例', news).group(2)
            # 省份的新增确诊人数
            province_all_dict['新增确诊'] = re.search('31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例(.*?)（(.*?)），含(.*?)例由无症状感染者转为确诊病例', news).group(2)
            # 省份的新增无症状
            province_all_dict['新增无症状'] = re.search('31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者(.*?)（(.*?)）。当日解除医学观察的无症状感染者', news).group(2)
            # 各个省份的新增确诊人数
            every_province_dict_1 = data_detail(province_all_dict['新增确诊'])
            print(every_province_dict_1.items())
            write_file(every_province_dict_1)
            # 各个省份的新增无症状人数
            every_province_dict_2 = data_detail(province_all_dict['新增无症状'])
            # print(every_province_dict_2.items())
            provinces = every_province_dict_1.keys()
            province_values_1 = every_province_dict_1.values()
            province_values_2 = every_province_dict_2.values()



            c = (
                Map()
                .add("疫情新增人数分布图", [list(z) for z in zip(provinces, province_values_1)], "china")
                .set_global_opts(
                    title_opts=opts.TitleOpts(title="Map-VisualMap（连续型）"),
                    visualmap_opts=opts.VisualMapOpts(max_=100),
                )
                .render("map_visualmap_piecewise.html")
            )

            c = (
                Map()
                .add("疫情新增人数分布图", [list(z) for z in zip(provinces, province_values_2)], "china")
                .set_global_opts(
                    title_opts=opts.TitleOpts(title="Map-VisualMap（连续型）"),
                    visualmap_opts=opts.VisualMapOpts(max_=100),
                )
                .render("map_visualmap_piecewise.html")
            )

            saveFile("D:/系统默认/桌面/DATA1/", title, content)
            print("-----" * 20)

