import cProfile
import pstats
import 港澳台确诊

cProfile.run('港澳台确诊.main()','restats')

q = pstats.Stats('restats')
q.sort_stats('cumulative').print_stats(10)
