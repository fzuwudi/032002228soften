# def f1(url,lll,llllll):
#     .....
#
#
#     return ....,,
#
#
# def main():
#     .....
#
#     return ....,,
#
#
# k = f1(ll,lll,lllll)
#

List = ['1','2','3','55ckoxfojxf']
def getHTMLText(url):
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
        'cookie': 'yfx_c_g_u_id_10006654=_ck22090522142012772195013675521; insert_cookie=91349450; sVoELocvxVW0T=53SLtWCWFkrGqqqDkoM.jsAZXMs6MhV.QZa11hGaT2WGOmdmbQqXyFwxwA5NVcVfTkKGlER3Dd6vQsNF5amRhMXc7J_OUPFnYVificZMQK6xVWl1ctTvqTt4rLiFXDE7VmEn5rL4AyublPKFq3g9BjDnzYtEoWDxRNoRHD_Sn8Rj4HKSdnhqxl6ROfWh6MTd8K6dEDHEb4gnyeRJFpdrtxyksCsio_.yfYkcnlBDuQIuJw56myw88jF69mZPhTPbqqCX0m712pPcQUWdiZyA0naC10516Av7oToUwG6W34anJJ_fsy5CCuI0238DzjfIS9MLDlR11VQ_zIvawe9egU31TD8.bX.kGoAwEC1zqW_3A; yfx_f_l_v_t_10006654=f_t_1662387260271__r_t_1662686249486__v_t_1662686249486__r_c_2; security_session_verify=89607556861ac76924e5df4695f3c6bd'
       # 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.27'
    }
    try:
        r = requests.get(url=url, headers=headers, timeout=30)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        return "产生异常"




def main():
    Str = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd'
    for i in range(0, 42):
        if i == 1:
            str2 = Str
        else:
            str2 = Str + '_' + str(i)
        url = str2 + '.shtml'
        page_text = getHTMLText(url)


# 获取子网页文本内容
            Content = div_tag.text
            # 以下是国家卫健委对于新增病例的8种描述：
            # 1 本土病例5例（上海3例，内蒙古1例，辽宁1例）    2022-06-19
            # 2 本土病例6例，均在北京 2020-06-13
            # 3 其中10例为本土病例（湖北5例，吉林3例，辽宁1例，黑龙江1例）  2020-05-11
            # 4 新增确诊病例4例，均为本土病例（均在吉林）  2020-05-15
            # 5 新增病例17例，无死亡病例。
            # 6 新增确诊病例119例，        （此时还没有境外输入，所以都是属于本土） 2020-03-04
            # 7 新增新型冠状病毒感染的肺炎确诊病例77例（湖北省72例，上海市2例，北京市3例）  2020-01-21
            # 8 新型冠状病毒感染的肺炎病例41例    2020-01-11

            describe = -1  # describe = i表示描述i的匹配
            describe_list = ['(本土病例[0-9]{1,10}例（.*?）)',
                             '本土病例[0-9]{1,10}例，均在[\u4e00-\u9fa5]{2,3}',
                             '[0-9]{1,10}例为本土病例（.*?）',
                             '新增确诊病例[0-9]{1,10}例，均为本土病例',
                             '新增病例[0-9]{1,10}例',
                             '新增确诊病例[0-9]{1,10}例',
                             '新增新型冠状病毒感染的肺炎确诊病例[0-9]{1,10}例（.*?）',
                             '新型冠状病毒感染的肺炎病例[0-9]{1,10}例'
                             ]

            for j in range(0, 8):
                pattern = describe_list[j]
                if describe == -1:
                    try:
                        new_confirmed = re.findall(pattern, Content)[0]  #re.findall(pattern,string) ,在string中匹配pattern
                        describe = j
                    except:
                        pass


            # 排除类似‘新增确诊病例19例，均为境外输入病例’
            # 新增确诊病例1例，为境外输入病例（在广东）  2020-06-04
            # 无新增新型冠状病毒感染的肺炎病例 2020-01-15
            try:
                other_country = re.findall('新增确诊病例[0-9]{1,10}例，均为境外输入病例',Content)[0]
                describe = -1
            except:
                pass
            try:
                other_country = re.findall('新增确诊病例[0-9]{1,10}例，为境外输入病例',Content)[0]
                describe = -1
                # new_confirmed = '无新增确诊'
            except:
                pass
            try:
                is_new = re.findall('无新增新型冠状病毒感染的肺炎病例',Content)[0]
                describe = -1
                # new_confirmed = '无新增确诊'
            except:
                pass

            if describe == -1:
                new_confirmed = '无新增确诊'

            # 处理描述6的详细信息
            if describe == 5:
                try:
                    detail_msg = re.findall('湖北新增确诊病例[0-9]{1,10}例',Content)[0]
                    new_confirmed = new_confirmed + '，' + detail_msg
                except:
                    pass

describe_list = ['(本土病例[0-9]{1,10}例（.*?）)',
                             '本土病例[0-9]{1,10}例，均在[\u4e00-\u9fa5]{2,3}',
                             '[0-9]{1,10}例为本土病例（.*?）',
                             '新增确诊病例[0-9]{1,10}例，均为本土病例',
                             '新增病例[0-9]{1,10}例',
                             '新增确诊病例[0-9]{1,10}例',
                             '新增新型冠状病毒感染的肺炎确诊病例[0-9]{1,10}例（.*?）',
                             '新型冠状病毒感染的肺炎病例[0-9]{1,10}例'
                             ]
#新增病例的表述
    #1 本土病例188例（四川126例，西藏11例，北京10例）
    #2 新型冠状病毒感染的肺炎病例41例        2020 01 11
    #3 新增病例59例    2020 01 20
    #4 新增新型冠状病毒感染的肺炎确诊病例77例（湖北省72例，上海市2例，北京市3例） 2020 01 21
    #5 新增确诊病例259例 2020 01 24
    #6 本土病例56例

    s = ['(本土病例[0-9]{1,6}例 （.*?）)',
     '新型冠状病毒感染的肺炎病例[0-9]{1,6}例',
     '新增病例[0-9]{1,6}例',
     '新增新型冠状病毒感染的肺炎确诊病例[0-9]{1,6}例（.*?）',
     '新增确诊病例[0-9]{1,6}例',
     '本土病例[0-9]{1,6}例（.*?）'
     ]


