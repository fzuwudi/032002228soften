# -*- coding = utf-8 -*-
# @Time ：2022/9/15 15:18
# @File :data.py
import requests
from bs4 import BeautifulSoup
import re
import xlwings as xw
import xlrd
from pyecharts import options as opts
from pyecharts.charts import Line, Grid
import show
# 爬虫主体部分，直接运行该程序即可通过调用函数方式调动show文件实行后续可视化
# 运行程序前应提前建立好表格命名为“新冠数据”，同时将sheet名字改为“all”
# 重复运行时应记得将表格内容清空，否则会默认在上次的导出数据后接着导入，造成可视化输出产生问题


# 通过标题关键词语爬取记录数据的页面
def get_href(url, i):
    r = requests.get(url, headers=head)
    soup = BeautifulSoup(r.text, 'lxml')
    # find_all 查找所有疫情最新情况对应的href及相关日期
    a_all = soup.find_all(name='a', attrs={'target': '_blank'}, text=re.compile(r'新型冠状病毒'))
    page_dict = []
    for a in a_all:
        # print('---')
        latest_news = 'http://www.nhc.gov.cn' + a.attrs['href']
        # print(latest_news)
        day_format = a.find_next_sibling(name='span').text
        # print(day_format)
        new_dict = get_data(i, latest_news, day_format)
        page_dict.append(new_dict)
    # print(page_dict)
    return page_dict


# 获取具体数据
def get_data(i, url, day):
    r = requests.get(url, headers=head)
    soup = BeautifulSoup(r.text, 'lxml')
    news = soup.get_text()
    all_dict = {}
    all_dict['日期'] = day
    # 提前检索章节内是否存在对应关键词，防止因为关键词不存在导致程序出错
    # 新增确诊
    if 39 <= i < 42:  # 这几页的关键词描述不同，需要另外计算
        if re.search('新增确诊病例(\d+)例', news) is not None:
            a = int(re.search('新增确诊病例(\d+)例', news).group(1))
            if re.search('新增报告境外输入确诊病例(\d+)例', news) is not None:
                b = int(re.search('新增报告境外输入确诊病例(\d+)例', news).group(1))
            else:
                b = 0
            all_dict['本土新增确诊'] = str(a - b)
            find_word1(news, all_dict)
        else:
            all_dict['本土新增确诊'] = '0'
            # print(all_dict['本土新增确诊'])
    else:
        if re.search('新增确诊病例.*?本土病例(\d+)例', news) is not None:
            all_dict['本土新增确诊'] = re.search('新增确诊病例.*?本土病例(\d+)例', news).group(1)
            find_word1(news, all_dict)
        else:
            all_dict['本土新增确诊'] = '0'
            all_dict['重庆新增确诊'] = '0'
            all_dict['上海新增确诊'] = '0'
            all_dict['天津新增确诊'] = '0'
            all_dict['北京新增确诊'] = '0'
            all_dict['新疆新增确诊'] = '0'
            all_dict['宁夏新增确诊'] = '0'
            all_dict['西藏新增确诊'] = '0'
            all_dict['广西新增确诊'] = '0'
            all_dict['内蒙古新增确诊'] = '0'
            all_dict['青海新增确诊'] = '0'
            all_dict['甘肃新增确诊'] = '0'
            all_dict['陕西新增确诊'] = '0'
            all_dict['云南新增确诊'] = '0'
            all_dict['贵州新增确诊'] = '0'
            all_dict['四川新增确诊'] = '0'
            all_dict['海南新增确诊'] = '0'
            all_dict['广东新增确诊'] = '0'
            all_dict['湖南新增确诊'] = '0'
            all_dict['湖北新增确诊'] = '0'
            all_dict['河南新增确诊'] = '0'
            all_dict['山东新增确诊'] = '0'
            all_dict['江西新增确诊'] = '0'
            all_dict['福建新增确诊'] = '0'
            all_dict['安徽新增确诊'] = '0'
            all_dict['浙江新增确诊'] = '0'
            all_dict['江苏新增确诊'] = '0'
            all_dict['黑龙江新增确诊'] = '0'
            all_dict['吉林新增确诊'] = '0'
            all_dict['辽宁新增确诊'] = '0'
            all_dict['山西新增确诊'] = '0'
            all_dict['河北新增确诊'] = '0'
        # 新增无症状感染者
        if re.search('新增无症状感染者.*?本土(\d+)例', news) is not None:
            all_dict['本土新增无症状'] = re.search('新增无症状感染者.*?本土(\d+)例', news).group(1)
            find_word2(news, all_dict)
        else:
            all_dict['本土新增无症状'] = '0'
            all_dict['重庆新增无症状'] = '0'
            all_dict['上海新增无症状'] = '0'
            all_dict['天津新增无症状'] = '0'
            all_dict['北京新增无症状'] = '0'
            all_dict['新疆新增无症状'] = '0'
            all_dict['宁夏新增无症状'] = '0'
            all_dict['西藏新增无症状'] = '0'
            all_dict['广西新增无症状'] = '0'
            all_dict['内蒙古新增无症状'] = '0'
            all_dict['青海新增无症状'] = '0'
            all_dict['甘肃新增无症状'] = '0'
            all_dict['陕西新增无症状'] = '0'
            all_dict['云南新增无症状'] = '0'
            all_dict['贵州新增无症状'] = '0'
            all_dict['四川新增无症状'] = '0'
            all_dict['海南新增无症状'] = '0'
            all_dict['广东新增无症状'] = '0'
            all_dict['湖南新增无症状'] = '0'
            all_dict['湖北新增无症状'] = '0'
            all_dict['河南新增无症状'] = '0'
            all_dict['山东新增无症状'] = '0'
            all_dict['江西新增无症状'] = '0'
            all_dict['福建新增无症状'] = '0'
            all_dict['安徽新增无症状'] = '0'
            all_dict['浙江新增无症状'] = '0'
            all_dict['江苏新增无症状'] = '0'
            all_dict['黑龙江新增无症状'] = '0'
            all_dict['吉林新增无症状'] = '0'
            all_dict['辽宁新增无症状'] = '0'
            all_dict['山西新增无症状'] = '0'
            all_dict['河北新增无症状'] = '0'
    # 港澳台累计确诊数据
    if re.search('香港.*?(\d+)例', news) is not None:
        all_dict['香港累计确诊'] = re.search('香港.*?(\d+)例', news).group(1)
    else:
        all_dict['香港累计确诊'] = '0'
    if re.search('澳门.*?(\d+)例', news) is not None:
        all_dict['澳门累计确诊'] = re.search('澳门.*?(\d+)例', news).group(1)
    else:
        all_dict['澳门累计确诊'] = '0'
    if re.search('台湾.*?(\d+)例', news) is not None:
        all_dict['台湾累计确诊'] = re.search('台湾.*?(\d+)例', news).group(1)
    else:
        all_dict['台湾累计确诊'] = '0'
    return all_dict


# 提前检索关键词，防止因为找不到而出错
# 寻找各省份新增确诊
def find_word1(news, all_dict):
    if re.search('新增确诊病例.*?本土.*?河北.*?(\d+)例', news) is not None:
        all_dict['河北新增确诊'] = re.search('新增确诊病例.*?本土.*?河北.*?(\d+)例', news).group(1)
    elif re.search('新增确诊感病例.*?本土.*?均在河北', news) is not None:  # 翻阅后面的记录时发现还存在“均在”这种表示方法，单独列出以防漏记
        all_dict['河北新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['河北新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?山西.*?(\d+)例', news) is not None:
        all_dict['山西新增确诊'] = re.search('新增确诊病例.*?本土.*?山西.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在山西', news) is not None:
        all_dict['山西新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['山西新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?辽宁.*?(\d+)例', news) is not None:
        all_dict['辽宁新增确诊'] = re.search('新增确诊病例.*?本土.*?辽宁.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在辽宁', news) is not None:
        all_dict['辽宁新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['辽宁新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?吉林.*?(\d+)例', news) is not None:
        all_dict['吉林新增确诊'] = re.search('新增确诊病例.*?本土.*?吉林.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在吉林', news) is not None:
        all_dict['吉林新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['吉林新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?黑龙江.*?(\d+)例', news) is not None:
        all_dict['黑龙江新增确诊'] = re.search('新增确诊病例.*?本土.*?黑龙江.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在黑龙江', news) is not None:
        all_dict['黑龙江新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['黑龙江新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?江苏.*?(\d+)例', news) is not None:
        all_dict['江苏新增确诊'] = re.search('新增确诊病例.*?本土.*?江苏.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在江苏', news) is not None:
        all_dict['江苏新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['江苏新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?浙江.*?(\d+)例', news) is not None:
        all_dict['浙江新增确诊'] = re.search('新增确诊病例.*?本土.*?浙江.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在浙江', news) is not None:
        all_dict['浙江新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['浙江新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?安徽.*?(\d+)例', news) is not None:
        all_dict['安徽新增确诊'] = re.search('新增确诊病例.*?本土.*?安徽.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在安徽', news) is not None:
        all_dict['安徽新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['安徽新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?福建.*?(\d+)例', news) is not None:
        all_dict['福建新增确诊'] = re.search('新增确诊病例.*?本土.*?福建.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在福建', news) is not None:
        all_dict['福建新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['福建新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?江西.*?(\d+)例', news) is not None:
        all_dict['江西新增确诊'] = re.search('新增确诊病例.*?本土.*?江西.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在江西', news) is not None:
        all_dict['江西新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['江西新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?山东.*?(\d+)例', news) is not None:
        all_dict['山东新增确诊'] = re.search('新增确诊病例.*?本土.*?山东.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在山东', news) is not None:
        all_dict['山东新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['山东新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?河南.*?(\d+)例', news) is not None:
        all_dict['河南新增确诊'] = re.search('新增确诊病例.*?本土.*?河南.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在河南', news) is not None:
        all_dict['河南新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['河南新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?湖北.*?(\d+)例', news) is not None:
        all_dict['湖北新增确诊'] = re.search('新增确诊病例.*?本土.*?湖北.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在湖北', news) is not None:
        all_dict['湖北新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['湖北新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?湖南.*?(\d+)例', news) is not None:
        all_dict['湖南新增确诊'] = re.search('新增确诊病例.*?本土.*?湖南.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在湖南', news) is not None:
        all_dict['湖南新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['湖南新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?广东.*?(\d+)例', news) is not None:
        all_dict['广东新增确诊'] = re.search('新增确诊病例.*?本土.*?广东.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在广东', news) is not None:
        all_dict['广东新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['广东新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?海南.*?(\d+)例', news) is not None:
        all_dict['海南新增确诊'] = re.search('新增确诊病例.*?本土.*?海南.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在海南', news) is not None:
        all_dict['海南新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['海南新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?四川.*?.*?(\d+)例', news) is not None:
        all_dict['四川新增确诊'] = re.search('新增确诊病例.*?本土.*?四川.*?.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在四川', news) is not None:
        all_dict['四川新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['四川新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?贵州.*?(\d+)例', news) is not None:
        all_dict['贵州新增确诊'] = re.search('新增确诊病例.*?本土.*?贵州.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在贵州', news) is not None:
        all_dict['贵州新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['贵州新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?云南.*?(\d+)例', news) is not None:
        all_dict['云南新增确诊'] = re.search('新增确诊病例.*?本土.*?云南.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在云南', news) is not None:
        all_dict['云南新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['云南新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?陕西.*?(\d+)例', news) is not None:
        all_dict['陕西新增确诊'] = re.search('新增确诊病例.*?本土.*?陕西.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在陕西', news) is not None:
        all_dict['陕西新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['陕西新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?甘肃.*?(\d+)例', news) is not None:
        all_dict['甘肃新增确诊'] = re.search('新增确诊病例.*?本土.*?甘肃.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在甘肃', news) is not None:
        all_dict['甘肃新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['甘肃新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?青海.*?(\d+)例', news) is not None:
        all_dict['青海新增确诊'] = re.search('新增确诊病例.*?本土.*?青海.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在青海', news) is not None:
        all_dict['青海新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['青海新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?内蒙古.*?(\d+)例', news) is not None:
        all_dict['内蒙古新增确诊'] = re.search('新增确诊病例.*?本土.*?内蒙古.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在内蒙古', news) is not None:
        all_dict['内蒙古新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['内蒙古新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?广西.*?(\d+)例', news) is not None:
        all_dict['广西新增确诊'] = re.search('新增确诊病例.*?本土.*?广西.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在广西', news) is not None:
        all_dict['广西新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['广西新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?西藏.*?(\d+)例', news) is not None:
        all_dict['西藏新增确诊'] = re.search('新增确诊病例.*?本土.*?西藏.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在西藏', news) is not None:
        all_dict['西藏新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['西藏新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?宁夏.*?(\d+)例', news) is not None:
        all_dict['宁夏新增确诊'] = re.search('新增确诊病例.*?本土.*?宁夏.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在宁夏', news) is not None:
        all_dict['宁夏新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['宁夏新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?新疆.*?(\d+)例', news) is not None:
        all_dict['新疆新增确诊'] = re.search('新增确诊病例.*?本土.*?新疆.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在新疆', news) is not None:
        all_dict['新疆新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['新疆新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?北京.*?(\d+)例', news) is not None:
        all_dict['北京新增确诊'] = re.search('新增确诊病例.*?本土.*?北京.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在北京', news) is not None:
        all_dict['北京新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['北京新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?天津.*?(\d+)例', news) is not None:
        all_dict['天津新增确诊'] = re.search('新增确诊病例.*?本土.*?天津.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在天津', news) is not None:
        all_dict['天津新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['天津新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?上海.*?(\d+)例', news) is not None:
        all_dict['上海新增确诊'] = re.search('新增确诊病例.*?本土.*?上海.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在上海', news) is not None:
        all_dict['上海新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['上海新增确诊'] = '0'
    if re.search('新增确诊病例.*?本土.*?重庆.*?(\d+)例', news) is not None:
        all_dict['重庆新增确诊'] = re.search('新增确诊病例.*?本土.*?重庆.*?(\d+)例', news).group(1)
    elif re.search('新增确诊病例.*?本土.*?均在重庆', news) is not None:
        all_dict['重庆新增确诊'] = all_dict['本土新增确诊']
    else:
        all_dict['重庆新增确诊'] = '0'


# 寻找各省份新增无症状
def find_word2(news, all_dict):
    if re.search('新增无症状感染者.*?河北(\d+)例', news) is not None:
        all_dict['河北新增无症状'] = re.search('新增无症状感染者.*?河北(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在河北', news) is not None:  # 翻阅后面的记录时发现还存在“均在”这种表示方法，单独列出以防漏记
        all_dict['河北新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['河北新增无症状'] = '0'
    if re.search('新增无症状感染者.*?山西(\d+)例', news) is not None:
        all_dict['山西新增无症状'] = re.search('新增无症状感染者.*?山西(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在山西', news) is not None:
        all_dict['山西新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['山西新增无症状'] = '0'
    if re.search('新增无症状感染者.*?辽宁(\d+)例', news) is not None:
        all_dict['辽宁新增无症状'] = re.search('新增无症状感染者.*?辽宁(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在辽宁', news) is not None:
        all_dict['辽宁新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['辽宁新增无症状'] = '0'
    if re.search('新增无症状感染者.*?吉林(\d+)例', news) is not None:
        all_dict['吉林新增无症状'] = re.search('新增无症状感染者.*?吉林(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在吉林', news) is not None:
        all_dict['吉林新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['吉林新增无症状'] = '0'
    if re.search('新增无症状感染者.*?黑龙江(\d+)例', news) is not None:
        all_dict['黑龙江新增无症状'] = re.search('新增无症状感染者.*?黑龙江(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在黑龙江', news) is not None:
        all_dict['黑龙江新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['黑龙江新增无症状'] = '0'
    if re.search('新增无症状感染者.*?江苏(\d+)例', news) is not None:
        all_dict['江苏新增无症状'] = re.search('新增无症状感染者.*?江苏(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在江苏', news) is not None:
        all_dict['江苏新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['江苏新增无症状'] = '0'
    if re.search('新增无症状感染者.*?浙江(\d+)例', news) is not None:
        all_dict['浙江新增无症状'] = re.search('新增无症状感染者.*?浙江(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在浙江', news) is not None:
        all_dict['浙江新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['浙江新增无症状'] = '0'
    if re.search('新增无症状感染者.*?安徽(\d+)例', news) is not None:
        all_dict['安徽新增无症状'] = re.search('新增无症状感染者.*?安徽(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在安徽', news) is not None:
        all_dict['安徽新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['安徽新增无症状'] = '0'
    if re.search('新增无症状感染者.*?福建(\d+)例', news) is not None:
        all_dict['福建新增无症状'] = re.search('新增无症状感染者.*?福建(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在福建', news) is not None:
        all_dict['福建新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['福建新增无症状'] = '0'
    if re.search('新增无症状感染者.*?江西(\d+)例', news) is not None:
        all_dict['江西新增无症状'] = re.search('新增无症状感染者.*?江西(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在江西', news) is not None:
        all_dict['江西新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['江西新增无症状'] = '0'
    if re.search('新增无症状感染者.*?山东(\d+)例', news) is not None:
        all_dict['山东新增无症状'] = re.search('新增无症状感染者.*?山东(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在山东', news) is not None:
        all_dict['山东新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['山东新增无症状'] = '0'
    if re.search('新增无症状感染者.*?河南(\d+)例', news) is not None:
        all_dict['河南新增无症状'] = re.search('新增无症状感染者.*?河南(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在河南', news) is not None:
        all_dict['河南新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['河南新增无症状'] = '0'
    if re.search('新增无症状感染者.*?湖北(\d+)例', news) is not None:
        all_dict['湖北新增无症状'] = re.search('新增无症状感染者.*?湖北(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在湖北', news) is not None:
        all_dict['湖北新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['湖北新增无症状'] = '0'
    if re.search('新增无症状感染者.*?湖南(\d+)例', news) is not None:
        all_dict['湖南新增无症状'] = re.search('新增无症状感染者.*?湖南(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在湖南', news) is not None:
        all_dict['湖南新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['湖南新增无症状'] = '0'
    if re.search('新增无症状感染者.*?广东(\d+)例', news) is not None:
        all_dict['广东新增无症状'] = re.search('新增无症状感染者.*?广东(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在广东', news) is not None:
        all_dict['广东新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['广东新增无症状'] = '0'
    if re.search('新增无症状感染者.*?海南(\d+)例', news) is not None:
        all_dict['海南新增无症状'] = re.search('新增无症状感染者.*?海南(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在海南', news) is not None:
        all_dict['海南新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['海南新增无症状'] = '0'
    if re.search('新增无症状感染者.*?四川(\d+)例', news) is not None:
        all_dict['四川新增无症状'] = re.search('新增无症状感染者.*?四川(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在四川', news) is not None:
        all_dict['四川新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['四川新增无症状'] = '0'
    if re.search('新增无症状感染者.*?贵州(\d+)例', news) is not None:
        all_dict['贵州新增无症状'] = re.search('新增无症状感染者.*?贵州(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在贵州', news) is not None:
        all_dict['贵州新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['贵州新增无症状'] = '0'
    if re.search('新增无症状感染者.*?云南(\d+)例', news) is not None:
        all_dict['云南新增无症状'] = re.search('新增无症状感染者.*?云南(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在云南', news) is not None:
        all_dict['云南新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['云南新增无症状'] = '0'
    if re.search('新增无症状感染者.*?陕西(\d+)例', news) is not None:
        all_dict['陕西新增无症状'] = re.search('新增无症状感染者.*?陕西(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在陕西', news) is not None:
        all_dict['陕西新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['陕西新增无症状'] = '0'
    if re.search('新增无症状感染者.*?甘肃(\d+)例', news) is not None:
        all_dict['甘肃新增无症状'] = re.search('新增无症状感染者.*?甘肃(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在甘肃', news) is not None:
        all_dict['甘肃新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['甘肃新增无症状'] = '0'
    if re.search('新增无症状感染者.*?青海(\d+)例', news) is not None:
        all_dict['青海新增无症状'] = re.search('新增无症状感染者.*?青海(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在青海', news) is not None:
        all_dict['青海新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['青海新增无症状'] = '0'
    if re.search('新增无症状感染者.*?内蒙古(\d+)例', news) is not None:
        all_dict['内蒙古新增无症状'] = re.search('新增无症状感染者.*?内蒙古(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在内蒙古', news) is not None:
        all_dict['内蒙古新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['内蒙古新增无症状'] = '0'
    if re.search('新增无症状感染者.*?广西(\d+)例', news) is not None:
        all_dict['广西新增无症状'] = re.search('新增无症状感染者.*?广西(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在广西', news) is not None:
        all_dict['广西新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['广西新增无症状'] = '0'
    if re.search('新增无症状感染者.*?西藏(\d+)例', news) is not None:
        all_dict['西藏新增无症状'] = re.search('新增无症状感染者.*?西藏(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在西藏', news) is not None:
        all_dict['西藏新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['西藏新增无症状'] = '0'
    if re.search('新增无症状感染者.*?宁夏(\d+)例', news) is not None:
        all_dict['宁夏新增无症状'] = re.search('新增无症状感染者.*?宁夏(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在宁夏', news) is not None:
        all_dict['宁夏新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['宁夏新增无症状'] = '0'
    if re.search('新增无症状感染者.*?新疆(\d+)例', news) is not None:
        all_dict['新疆新增无症状'] = re.search('新增无症状感染者.*?新疆(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在新疆', news) is not None:
        all_dict['新疆新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['新疆新增无症状'] = '0'
    if re.search('新增无症状感染者.*?北京(\d+)例', news) is not None:
        all_dict['北京新增无症状'] = re.search('新增无症状感染者.*?北京(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在北京', news) is not None:
        all_dict['北京新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['北京新增无症状'] = '0'
    if re.search('新增无症状感染者.*?天津(\d+)例', news) is not None:
        all_dict['天津新增无症状'] = re.search('新增无症状感染者.*?天津(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在天津', news) is not None:
        all_dict['天津新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['天津新增无症状'] = '0'
    if re.search('新增无症状感染者.*?上海(\d+)例', news) is not None:
        all_dict['上海新增无症状'] = re.search('新增无症状感染者.*?上海(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在上海', news) is not None:
        all_dict['上海新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['上海新增无症状'] = '0'
    if re.search('新增无症状感染者.*?重庆(\d+)例', news) is not None:
        all_dict['重庆新增无症状'] = re.search('新增无症状感染者.*?重庆(\d+)例', news).group(1)
    elif re.search('新增无症状感染者.*?均在重庆', news) is not None:
        all_dict['重庆新增无症状'] = all_dict['本土新增无症状']
    else:
        all_dict['重庆新增无症状'] = '0'


# 写入excel
def get_into_excel():
    app = xw.App(visible=False, add_book=False)
    app.display_alerts = False
    app.screen_updating = False
    wb = app.books.open('新冠数据.xlsx')  # 需提前建立表格命名为“新冠数据”
    ws = wb.sheets['all']  # 将对应sheet命名为all
    max_row = ws.api.UsedRange.Rows.count
    # print(max_row)
    # 循环提取数据
    # print(all_data[0]['本土新增确诊'])
    ws.range('B' + str(max_row)).value = '本土新增确诊'
    ws.range('C' + str(max_row)).value = '河北新增确诊'
    ws.range('D' + str(max_row)).value = '山西新增确诊'
    ws.range('E' + str(max_row)).value = '辽宁新增确诊'
    ws.range('F' + str(max_row)).value = '吉林新增确诊'
    ws.range('G' + str(max_row)).value = '黑龙江新增确诊'
    ws.range('H' + str(max_row)).value = '江苏新增确诊'
    ws.range('I' + str(max_row)).value = '浙江新增确诊'
    ws.range('J' + str(max_row)).value = '安徽新增确诊'
    ws.range('K' + str(max_row)).value = '福建新增确诊'
    ws.range('L' + str(max_row)).value = '江西新增确诊'
    ws.range('M' + str(max_row)).value = '山东新增确诊'
    ws.range('N' + str(max_row)).value = '河南新增确诊'
    ws.range('O' + str(max_row)).value = '湖北新增确诊'
    ws.range('P' + str(max_row)).value = '湖南新增确诊'
    ws.range('Q' + str(max_row)).value = '广东新增确诊'
    ws.range('R' + str(max_row)).value = '海南新增确诊'
    ws.range('S' + str(max_row)).value = '四川新增确诊'
    ws.range('T' + str(max_row)).value = '贵州新增确诊'
    ws.range('U' + str(max_row)).value = '云南新增确诊'
    ws.range('V' + str(max_row)).value = '陕西新增确诊'
    ws.range('W' + str(max_row)).value = '甘肃新增确诊'
    ws.range('X' + str(max_row)).value = '青海新增确诊'
    ws.range('Y' + str(max_row)).value = '内蒙古新增确诊'
    ws.range('Z' + str(max_row)).value = '广西新增确诊'
    ws.range('AA' + str(max_row)).value = '西藏新增确诊'
    ws.range('AB' + str(max_row)).value = '宁夏新增确诊'
    ws.range('AC' + str(max_row)).value = '新疆新增确诊'
    ws.range('AD' + str(max_row)).value = '北京新增确诊'
    ws.range('AE' + str(max_row)).value = '天津新增确诊'
    ws.range('AF' + str(max_row)).value = '上海新增确诊'
    ws.range('AG' + str(max_row)).value = '重庆新增确诊'
    ws.range('AH' + str(max_row)).value = '本土新增无症状'
    ws.range('AI' + str(max_row)).value = '河北新增无症状'
    ws.range('AJ' + str(max_row)).value = '山西新增无症状'
    ws.range('AK' + str(max_row)).value = '辽宁新增无症状'
    ws.range('AL' + str(max_row)).value = '吉林新增无症状'
    ws.range('AM' + str(max_row)).value = '黑龙江新增无症状'
    ws.range('AN' + str(max_row)).value = '江苏新增无症状'
    ws.range('AO' + str(max_row)).value = '浙江新增无症状'
    ws.range('AP' + str(max_row)).value = '安徽新增无症状'
    ws.range('AQ' + str(max_row)).value = '福建新增无症状'
    ws.range('AR' + str(max_row)).value = '江西新增无症状'
    ws.range('AS' + str(max_row)).value = '山东新增无症状'
    ws.range('AT' + str(max_row)).value = '河南新增无症状'
    ws.range('AU' + str(max_row)).value = '湖北新增无症状'
    ws.range('AV' + str(max_row)).value = '湖南新增无症状'
    ws.range('AW' + str(max_row)).value = '广东新增无症状'
    ws.range('AX' + str(max_row)).value = '海南新增无症状'
    ws.range('AY' + str(max_row)).value = '四川新增无症状'
    ws.range('AZ' + str(max_row)).value = '贵州新增无症状'
    ws.range('BA' + str(max_row)).value = '云南新增无症状'
    ws.range('BB' + str(max_row)).value = '陕西新增无症状'
    ws.range('BC' + str(max_row)).value = '甘肃新增无症状'
    ws.range('BD' + str(max_row)).value = '青海新增无症状'
    ws.range('BE' + str(max_row)).value = '内蒙古新增无症状'
    ws.range('BF' + str(max_row)).value = '广西新增无症状'
    ws.range('BG' + str(max_row)).value = '西藏新增无症状'
    ws.range('BH' + str(max_row)).value = '宁夏新增无症状'
    ws.range('BI' + str(max_row)).value = '新疆新增无症状'
    ws.range('BJ' + str(max_row)).value = '北京新增无症状'
    ws.range('BK' + str(max_row)).value = '天津新增无症状'
    ws.range('BL' + str(max_row)).value = '上海新增无症状'
    ws.range('BM' + str(max_row)).value = '重庆新增无症状'
    ws.range('BN' + str(max_row)).value = '香港累计确诊'
    ws.range('BO' + str(max_row)).value = '澳门累计确诊'
    ws.range('BP' + str(max_row)).value = '台湾累计确诊'

    for a in all_data:
        max_row = max_row + 1
        ws.range('A' + str(max_row)).value = a['日期']
        if '本土新增确诊' in a:
            ws.range('B' + str(max_row)).value = a['本土新增确诊']
        if '河北新增确诊' in a:
            ws.range('C' + str(max_row)).value = a['河北新增确诊']
        if '山西新增确诊' in a:
            ws.range('D' + str(max_row)).value = a['山西新增确诊']
        if '辽宁新增确诊' in a:
            ws.range('E' + str(max_row)).value = a['辽宁新增确诊']
        if '吉林新增确诊' in a:
            ws.range('F' + str(max_row)).value = a['吉林新增确诊']
        if '黑龙江新增确诊' in a:
            ws.range('G' + str(max_row)).value = a['黑龙江新增确诊']
        if '江苏新增确诊' in a:
            ws.range('H' + str(max_row)).value = a['江苏新增确诊']
        if '浙江新增确诊' in a:
            ws.range('I' + str(max_row)).value = a['浙江新增确诊']
        if '安徽新增确诊' in a:
            ws.range('J' + str(max_row)).value = a['安徽新增确诊']
        if '福建新增确诊' in a:
            ws.range('K' + str(max_row)).value = a['福建新增确诊']
        if '江西新增确诊' in a:
            ws.range('L' + str(max_row)).value = a['江西新增确诊']
        if '山东新增确诊' in a:
            ws.range('M' + str(max_row)).value = a['山东新增确诊']
        if '河南新增确诊' in a:
            ws.range('N' + str(max_row)).value = a['河南新增确诊']
        if '湖北新增确诊' in a:
            ws.range('O' + str(max_row)).value = a['湖北新增确诊']
        if '湖南新增确诊' in a:
            ws.range('P' + str(max_row)).value = a['湖南新增确诊']
        if '广东新增确诊' in a:
            ws.range('Q' + str(max_row)).value = a['广东新增确诊']
        if '海南新增确诊' in a:
            ws.range('R' + str(max_row)).value = a['海南新增确诊']
        if '四川新增确诊' in a:
            ws.range('S' + str(max_row)).value = a['四川新增确诊']
        if '贵州新增确诊' in a:
            ws.range('T' + str(max_row)).value = a['贵州新增确诊']
        if '云南新增确诊' in a:
            ws.range('U' + str(max_row)).value = a['云南新增确诊']
        if '陕西新增确诊' in a:
            ws.range('V' + str(max_row)).value = a['陕西新增确诊']
        if '甘肃新增确诊' in a:
            ws.range('W' + str(max_row)).value = a['甘肃新增确诊']
        if '青海新增确诊' in a:
            ws.range('X' + str(max_row)).value = a['青海新增确诊']
        if '内蒙古新增确诊' in a:
            ws.range('Y' + str(max_row)).value = a['内蒙古新增确诊']
        if '广西新增确诊' in a:
            ws.range('Z' + str(max_row)).value = a['广西新增确诊']
        if '西藏新增确诊' in a:
            ws.range('AA' + str(max_row)).value = a['西藏新增确诊']
        if '宁夏新增确诊' in a:
            ws.range('AB' + str(max_row)).value = a['宁夏新增确诊']
        if '新疆新增确诊' in a:
            ws.range('AC' + str(max_row)).value = a['新疆新增确诊']
        if '北京新增确诊' in a:
            ws.range('AD' + str(max_row)).value = a['北京新增确诊']
        if '天津新增确诊' in a:
            ws.range('AE' + str(max_row)).value = a['天津新增确诊']
        if '上海新增确诊' in a:
            ws.range('AF' + str(max_row)).value = a['上海新增确诊']
        if '重庆新增确诊' in a:
            ws.range('AG' + str(max_row)).value = a['重庆新增确诊']
        if '本土新增无症状' in a:
            ws.range('AH' + str(max_row)).value = a['本土新增无症状']
        if '河北新增无症状' in a:
            ws.range('AI' + str(max_row)).value = a['河北新增无症状']
        if '山西新增无症状' in a:
            ws.range('AJ' + str(max_row)).value = a['山西新增无症状']
        if '辽宁新增无症状' in a:
            ws.range('AK' + str(max_row)).value = a['辽宁新增无症状']
        if '吉林新增无症状' in a:
            ws.range('AL' + str(max_row)).value = a['吉林新增无症状']
        if '黑龙江新增无症状' in a:
            ws.range('AM' + str(max_row)).value = a['黑龙江新增无症状']
        if '江苏新增无症状' in a:
            ws.range('AN' + str(max_row)).value = a['江苏新增无症状']
        if '浙江新增无症状' in a:
            ws.range('AO' + str(max_row)).value = a['浙江新增无症状']
        if '安徽新增无症状' in a:
            ws.range('AP' + str(max_row)).value = a['安徽新增无症状']
        if '福建新增无症状' in a:
            ws.range('AQ' + str(max_row)).value = a['福建新增无症状']
        if '江西新增无症状' in a:
            ws.range('AR' + str(max_row)).value = a['江西新增无症状']
        if '山东新增无症状' in a:
            ws.range('AS' + str(max_row)).value = a['山东新增无症状']
        if '河南新增无症状' in a:
            ws.range('AT' + str(max_row)).value = a['河南新增无症状']
        if '湖北新增无症状' in a:
            ws.range('AU' + str(max_row)).value = a['湖北新增无症状']
        if '湖南新增无症状' in a:
            ws.range('AV' + str(max_row)).value = a['湖南新增无症状']
        if '广东新增无症状' in a:
            ws.range('AW' + str(max_row)).value = a['广东新增无症状']
        if '海南新增无症状' in a:
            ws.range('AX' + str(max_row)).value = a['海南新增无症状']
        if '四川新增无症状' in a:
            ws.range('AY' + str(max_row)).value = a['四川新增无症状']
        if '贵州新增无症状' in a:
            ws.range('AZ' + str(max_row)).value = a['贵州新增无症状']
        if '云南新增无症状' in a:
            ws.range('BA' + str(max_row)).value = a['云南新增无症状']
        if '陕西新增无症状' in a:
            ws.range('BB' + str(max_row)).value = a['陕西新增无症状']
        if '甘肃新增无症状' in a:
            ws.range('BC' + str(max_row)).value = a['甘肃新增无症状']
        if '青海新增无症状' in a:
            ws.range('BD' + str(max_row)).value = a['青海新增无症状']
        if '内蒙古新增无症状' in a:
            ws.range('BE' + str(max_row)).value = a['内蒙古新增无症状']
        if '广西新增无症状' in a:
            ws.range('BF' + str(max_row)).value = a['广西新增无症状']
        if '西藏新增无症状' in a:
            ws.range('BG' + str(max_row)).value = a['西藏新增无症状']
        if '宁夏新增无症状' in a:
            ws.range('BH' + str(max_row)).value = a['宁夏新增无症状']
        if '新疆新增无症状' in a:
            ws.range('BI' + str(max_row)).value = a['新疆新增无症状']
        if '北京新增无症状' in a:
            ws.range('BJ' + str(max_row)).value = a['北京新增无症状']
        if '天津新增无症状' in a:
            ws.range('BK' + str(max_row)).value = a['天津新增无症状']
        if '上海新增无症状' in a:
            ws.range('BL' + str(max_row)).value = a['上海新增无症状']
        if '重庆新增无症状' in a:
            ws.range('BM' + str(max_row)).value = a['重庆新增无症状']
        if '香港累计确诊' in a:
            ws.range('BN' + str(max_row)).value = a['香港累计确诊']
        if '澳门累计确诊' in a:
            ws.range('BO' + str(max_row)).value = a['澳门累计确诊']
        if '台湾累计确诊' in a:
            ws.range('BP' + str(max_row)).value = a['台湾累计确诊']
    # print(type(all_data['本土新增确诊']))
    wb.save()
    wb.close()
    app.quit()


# 当程序执行时
if __name__ == "__main__":
    head = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.0.0 Safari/537.36',
        'Cookie': 'yfx_c_g_u_id_10006654=_ck22090611221816175939417102458; sVoELocvxVW0T=53SF4DbWKBHWqqqDklUFh1AVp_nS5CnH50HPwYb7n6CLIVHRCxJjBntJikbphecMmuIUD.qGw9xXfueMZEdrSc2L4q6XOAJQDvvERlhgHxgzCR2fVosLLcdD_Bfys6DXV5_O3oPohP4N3wSN8wYbyYn1Paasj9W8Hn6RcoRq3qNgP9PWBf9C249hG8xNABl5iTZZ0Mgg9BW0wU3mDxaMcN5XK78RbB1UxAU2ARkEHlcF2Rgb5hq5lumFIk98Q.IrgvlMpVMQIB4.ibhhxJ2SyxQsbhsT2KsdCSMArySG6TYayN8h2AhYmxAlAeJFeBaV9kJ97XRkBEvkP91qMehCtLobjs9AvRca_8HlA6Ox2EE1q; insert_cookie=91349450; yfx_f_l_v_t_10006654=f_t_1662434538608__r_t_1662434538608__v_t_1662445845218__r_c_0; security_session_verify=d6433e31e497575c415ce41a7ff5bf1d',
        'Host': 'www.nhc.gov.cn'
    }
    # 获取数据
    all_data = []
    try:
        for i in range(1, 42):
            print(i)
            if i == 1:
                # 第一页的网址没有带数字，需要特殊考虑
                url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
                all_data = all_data + get_href(url, i)
            else:
                url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_' + str(i) + '.shtml'
                all_data = all_data + get_href(url, i)
        # print('全国数据：{}\n'.format(all_data))
        print('已读取数据，正在进行导入！')
    except:
        print('全国数据未更新')
    # 将数据导出到excel
    if all_data != {}:
        get_into_excel()
        print('Excel刷新成功！')
        show.create_charts()
        print('折线图生成完毕！')