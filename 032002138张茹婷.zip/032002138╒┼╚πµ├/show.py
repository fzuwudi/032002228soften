# -*- coding = utf-8 -*-
# @Time ：2022/9/18 10:01
# @File :show.py
import xlrd
from pyecharts import options as opts
from pyecharts.charts import Line, Grid
# 程序主体在data中，这部分是可视化实现，在data执行过程中通过调用函数方式进行使用


def create_charts():
    # 读取表格
    data = xlrd.open_workbook("新冠数据.xlsx")
    # 获取表格的sheets
    table = data.sheets()[0]

    bendi = []
    date = []
    hebei = []
    shanxi = []
    liaoning = []
    jilin = []
    heilongjiang = []
    jiangsu = []
    zhejiang = []
    anhui = []
    fujian = []
    jiangxi = []
    shandong = []
    henan = []
    hubei = []
    hunan = []
    guangdong = []
    hainan = []
    sichuan = []
    guizhou = []
    yunnan = []
    shananxi = []
    gansu = []
    qinghai = []
    neimenggu = []
    guangxi = []
    xizang = []
    ningxia = []
    xinjiang = []
    beijing = []
    tianjin = []
    shanghai = []
    chongqing = []

    # 获取新增无症状
    for i in range(1, table.nrows):
        # print(table.col_values(i)[2])
        # 转换日期格式输出
        d = table.row_values(i)[0]
        da = xlrd.xldate.xldate_as_datetime(d, 0).date()
        date.append(da)
        # 读取新增确诊数据
        bendi.append(table.row_values(i)[1])
        hebei.append(table.row_values(i)[2])
        shanxi.append(table.row_values(i)[3])
        liaoning.append(table.row_values(i)[4])
        jilin.append(table.row_values(i)[5])
        heilongjiang.append(table.row_values(i)[6])
        jiangsu.append(table.row_values(i)[7])
        zhejiang.append(table.row_values(i)[8])
        anhui.append(table.row_values(i)[9])
        fujian.append(table.row_values(i)[10])
        jiangxi.append(table.row_values(i)[11])
        shandong.append(table.row_values(i)[12])
        henan.append(table.row_values(i)[13])
        hubei.append(table.row_values(i)[14])
        hunan.append(table.row_values(i)[15])
        guangdong.append(table.row_values(i)[16])
        hainan.append(table.row_values(i)[17])
        sichuan.append(table.row_values(i)[18])
        guizhou.append(table.row_values(i)[19])
        yunnan.append(table.row_values(i)[20])
        shananxi.append(table.row_values(i)[21])
        gansu.append(table.row_values(i)[22])
        qinghai.append(table.row_values(i)[23])
        neimenggu.append(table.row_values(i)[24])
        guangxi.append(table.row_values(i)[25])
        xizang.append(table.row_values(i)[26])
        ningxia.append(table.row_values(i)[27])
        xinjiang.append(table.row_values(i)[28])
        beijing.append(table.row_values(i)[29])
        tianjin.append(table.row_values(i)[30])
        shanghai.append(table.row_values(i)[31])
        chongqing.append(table.row_values(i)[32])

    # 绘制折线图
    line1 = (
        Line()
        .set_global_opts(title_opts=opts.TitleOpts(title="新增确诊"), xaxis_opts=opts.AxisOpts(axislabel_opts={"rotate": 45, "interval": 0}))
        # 添加数据
        .add_xaxis(date)
        .add_yaxis("河北", hebei)
        .add_yaxis("山西", shanxi)
        .add_yaxis("辽宁", liaoning)
        .add_yaxis("吉林", jilin)
        .add_yaxis("黑龙江", heilongjiang)
        .add_yaxis("江苏", jiangsu)
        .add_yaxis("浙江", zhejiang)
        .add_yaxis("安徽", anhui)
        .add_yaxis("福建", fujian)
        .add_yaxis("江西", jiangxi)
        .add_yaxis("山东", shandong)
        .add_yaxis("河南", henan)
        .add_yaxis("湖北", hubei)
        .add_yaxis("湖南", hunan)
        .add_yaxis("广东", guangdong)
        .add_yaxis("海南", hainan)
        .add_yaxis("四川", sichuan)
        .add_yaxis("贵州", guizhou)
        .add_yaxis("云南", yunnan)
        .add_yaxis("陕西", shananxi)
        .add_yaxis("甘肃", gansu)
        .add_yaxis("青海", qinghai)
        .add_yaxis("内蒙古", neimenggu)
        .add_yaxis("广西", guangxi)
        .add_yaxis("西藏", xizang)
        .add_yaxis("宁夏", ningxia)
        .add_yaxis("新疆", xinjiang)
        .add_yaxis("北京", beijing)
        .add_yaxis("天津", tianjin)
        .add_yaxis("上海", shanghai)
        .add_yaxis("重庆", chongqing)
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    )
    line2 = (
        Line()
        .set_global_opts(title_opts=opts.TitleOpts(title="新增确诊"), xaxis_opts=opts.AxisOpts(axislabel_opts={"rotate": 45, "interval": 0}))
        .add_xaxis(date)
        .add_yaxis("", bendi)
        # .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    )
    grid = Grid(init_opts=opts.InitOpts(width="20000px", height="1500px"))  # 设置图表全局大小
    grid.add(line1, grid_opts=opts.GridOpts(pos_bottom='80%', pos_left='0.5%'))  #修改图表位置
    grid.add(line2, grid_opts=opts.GridOpts(pos_bottom='5%', pos_left='0.5%'))
    grid.render("chart1.html")

    # 获取新增无症状
    bendi = []
    date = []
    hebei = []
    shanxi = []
    liaoning = []
    jilin = []
    heilongjiang = []
    jiangsu = []
    zhejiang = []
    anhui = []
    fujian = []
    jiangxi = []
    shandong = []
    henan = []
    hubei = []
    hunan = []
    guangdong = []
    hainan = []
    sichuan = []
    guizhou = []
    yunnan = []
    shananxi = []
    gansu = []
    qinghai = []
    neimenggu = []
    guangxi = []
    xizang = []
    ningxia = []
    xinjiang = []
    beijing = []
    tianjin = []
    shanghai = []
    chongqing = []
    for i in range(1, table.nrows):
        # print(table.col_values(i)[2])
        # 转换日期格式输出
        d = table.row_values(i)[0]
        da = xlrd.xldate.xldate_as_datetime(d, 0).date()
        date.append(da)
        bendi.append(table.row_values(i)[33])
        hebei.append(table.row_values(i)[34])
        shanxi.append(table.row_values(i)[35])
        liaoning.append(table.row_values(i)[36])
        jilin.append(table.row_values(i)[37])
        heilongjiang.append(table.row_values(i)[38])
        jiangsu.append(table.row_values(i)[39])
        zhejiang.append(table.row_values(i)[40])
        anhui.append(table.row_values(i)[41])
        fujian.append(table.row_values(i)[42])
        jiangxi.append(table.row_values(i)[43])
        shandong.append(table.row_values(i)[44])
        henan.append(table.row_values(i)[45])
        hubei.append(table.row_values(i)[46])
        hunan.append(table.row_values(i)[47])
        guangdong.append(table.row_values(i)[48])
        hainan.append(table.row_values(i)[49])
        sichuan.append(table.row_values(i)[50])
        guizhou.append(table.row_values(i)[51])
        yunnan.append(table.row_values(i)[52])
        shananxi.append(table.row_values(i)[53])
        gansu.append(table.row_values(i)[54])
        qinghai.append(table.row_values(i)[55])
        neimenggu.append(table.row_values(i)[56])
        guangxi.append(table.row_values(i)[57])
        xizang.append(table.row_values(i)[58])
        ningxia.append(table.row_values(i)[59])
        xinjiang.append(table.row_values(i)[60])
        beijing.append(table.row_values(i)[61])
        tianjin.append(table.row_values(i)[62])
        shanghai.append(table.row_values(i)[63])
        chongqing.append(table.row_values(i)[64])

    # 绘制折线图
    line1 = (
        Line()
            .set_global_opts(title_opts=opts.TitleOpts(title="新增确诊"), xaxis_opts=opts.AxisOpts(axislabel_opts={"rotate": 45, "interval": 0}))
            # 添加数据
            .add_xaxis(date)
            .add_yaxis("河北", hebei)
            .add_yaxis("山西", shanxi)
            .add_yaxis("辽宁", liaoning)
            .add_yaxis("吉林", jilin)
            .add_yaxis("黑龙江", heilongjiang)
            .add_yaxis("江苏", jiangsu)
            .add_yaxis("浙江", zhejiang)
            .add_yaxis("安徽", anhui)
            .add_yaxis("福建", fujian)
            .add_yaxis("江西", jiangxi)
            .add_yaxis("山东", shandong)
            .add_yaxis("河南", henan)
            .add_yaxis("湖北", hubei)
            .add_yaxis("湖南", hunan)
            .add_yaxis("广东", guangdong)
            .add_yaxis("海南", hainan)
            .add_yaxis("四川", sichuan)
            .add_yaxis("贵州", guizhou)
            .add_yaxis("云南", yunnan)
            .add_yaxis("陕西", shananxi)
            .add_yaxis("甘肃", gansu)
            .add_yaxis("青海", qinghai)
            .add_yaxis("内蒙古", neimenggu)
            .add_yaxis("广西", guangxi)
            .add_yaxis("西藏", xizang)
            .add_yaxis("宁夏", ningxia)
            .add_yaxis("新疆", xinjiang)
            .add_yaxis("北京", beijing)
            .add_yaxis("天津", tianjin)
            .add_yaxis("上海", shanghai)
            .add_yaxis("重庆", chongqing)
            .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    )
    line2 = (
        Line()
            .set_global_opts(title_opts=opts.TitleOpts(title="新增无症状"), xaxis_opts=opts.AxisOpts(axislabel_opts={"rotate": 45, "interval": 0}))
            .add_xaxis(date)
            .add_yaxis("", bendi)
        # .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
    )
    grid = Grid(init_opts=opts.InitOpts(width="20000px", height="1500px"))  # 设置图表全局大小
    grid.add(line1, grid_opts=opts.GridOpts(pos_bottom='80%', pos_left='0.5%'))  #修改图表位置
    grid.add(line2, grid_opts=opts.GridOpts(pos_bottom='5%', pos_left='0.5%'))
    grid.render("chart2.html")


if __name__ == "__main__":
    create_charts()