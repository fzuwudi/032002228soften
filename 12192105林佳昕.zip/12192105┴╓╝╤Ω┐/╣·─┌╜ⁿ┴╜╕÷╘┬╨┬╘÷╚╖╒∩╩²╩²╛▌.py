import requests
# import json
import pandas as pd


url="https://api.inews.qq.com/newsqa/v1/query/inner/publish/modules/list?modules=chinaDayList,chinaDayAddList,nowConfirmStatis,provinceCompare"
resp=requests.post(url)

# print(resp.text['data'])
# data=json.load(resp.json()['data'])
# print(resp.text)
# print(resp.json()['data']['chinaDayAddList'])
data_set=[]
for i in resp.json()['data']['chinaDayAddList']:
    data_dict={}
    data_dict['date'] = i['date']
    data_dict['confirm'] = i['confirm']
    # print(i['date'])
    # print(i['confirm'])
    data_set.append(data_dict)
print(data_set)
# print(type(resp.json()['data']['chinaDayAddList']))
df=pd.DataFrame(data_set)
df.to_csv('./data/metadata/国内近两个月新增确诊数数据.csv')