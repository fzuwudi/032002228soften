import time
from selenium import webdriver
import requests
import re
import uagent
import xlrd
import xlwt
from pyecharts import options as opts
from pyecharts.charts import Map
from pyecharts.faker import Faker
import requests
from datetime import date
import json

from pyecharts.globals import ThemeType

update_date = date.today()

flag = 1
province_data = []

Dict = (
 '河北', '山西', '辽宁', '吉林省', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南',
 '广东', '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海',
 '内蒙古', '西藏', '宁夏', '新疆', '广西', '北京', '天津', '上海', '重庆'
)
Lict =(
    '香港特别行政区', '澳门特别行政区', '台湾地区'
)

#对列表进行初始化
book = xlwt.Workbook(encoding='utf-8', style_compression=0)
sheet = book.add_sheet('本土及港澳台确诊病例', cell_overwrite_ok=True)
sheet.write(0, 0, '发布时间')

for j in range(2, 33):  # 在第一列中写入31个省份
    sheet.write(j, 0,Dict[j-2])
for u in range(37,68):
    sheet.write(u, 0, Dict[u-37])
sheet.write(1, 0, '本土病例')
sheet.write(36, 0, '本土')
for k in range(33, 36):
    sheet.write(k, 0, Lict[k-33])

# 请求全部网页
for i in range(1, 42):
    if i == 1:
        url = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml"
    else:
        url = f"http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_{i}.shtml"
    # 获取网页cookie 且进行反反爬措施
    driver = webdriver.Edge()
    driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
        "source": """
        Object.defineProperty(navigator, 'webdriver', {
          get: () => undefined
        })
      """
    })
    driver.get(url)
    Cookie = driver.get_cookies()
    strr = ''
    for c in Cookie:
        strr += c['name']
        strr += '='
        strr += c['value']
        strr += ';'
    full_cookie = strr
    ua = uagent.get_ua()
    headers = {
        'User-Agent': ua,
        'Cookie': full_cookie
    }

    resp = requests.get(url=url, headers=headers)
    time.sleep(1)
    resp.encoding = 'utf-8'
    # 提取该部分中的子页面链接并保存在列表中
    href_list = []
    obj1 = re.compile(r'<li>  <a href="(?P<href>.*?)" target.*?</span></li>', re.S)
    ret1 = obj1.finditer(resp.text)
    for it in ret1:
        href_list.append('http://www.nhc.gov.cn/' + it.group('href').strip('/'))

    count = 1

    for child_href in href_list:

        driver1 = webdriver.Edge()
        driver1.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": """
                Object.defineProperty(navigator, 'webdriver', {
                  get: () => undefined
                })
              """
        })
        driver1.get(child_href)
        Cookie1 = driver1.get_cookies()
        strr1 = ''
        for c in Cookie1:
            strr1 += c['name']
            strr1 += '='
            strr1 += c['value']
            strr1 += ';'
        full_cookie1 = strr1
        ub = uagent.get_ua()
        headers1 = {
            'User-Agent': ub,
            'Cookie': full_cookie1
        }

        child_resp = requests.get(url=child_href, headers=headers1)
        child_resp.encoding = 'utf-8'


        # 时间

        obj_time = re.compile(r'<meta name="PubDate" content="(?P<time>.*?) .*?/>', re.S)
        ret_time = obj_time.search(child_resp.text)
        if ret_time.group('time')=='2022-08-31':
            break
        sheet.write(0, count, ret_time.group('time'))

        for p in range(1, 68):
            sheet.write(p, count, '0')
        # 本土新增确诊

        obj2 = re.compile(r'<div class="con" id="xw_box">.*?例.*?；(?P<local>.*?)<.*?>(?P<number>.*?)<', re.S)  # 查找本土病例
        ret2 = obj2.search(child_resp.text)  # 本土病例

        sheet.write(1, count, ret2.group('number'))

        obj3 = re.compile(r'<div class="con" id="xw_box">.*?本土病例.*?</span>(?P<left>.*?)例），含', re.S)  # 将后半段提出
        ret3 = obj3.search(child_resp.text)  # 将后半段整体提出
        te = ret3.group('left')
        obj4 = re.compile(r'例.(?P<sm>.*?)<span.*?>(?P<sl>.*?)</span>', re.S)  # 提出各省份每日新增病例
        ret4 = obj4.finditer(te)
        for it in ret4:
            for t in range(0, 31):
                if it.group('sm') == Dict[t]:
                    sheet.write(t+2, count, it.group('sl'))
                    break
            if flag == 1:
                province_data.append(
                    [
                        it.group('sm'),
                        it.group('sl')
                    ]
                )
        if flag == 1:
            c = (
                Map(init_opts=opts.InitOpts(theme=ThemeType.DARK))
                .add("全国新增确诊人数", province_data, "china", is_map_symbol_show=False)
                .set_global_opts(
                    title_opts=opts.TitleOpts(
                        title="新冠状病毒全国新增疫情地图",
                        subtitle="更新日期:{}".format(update_date),
                    ),
                    # 视觉映射配置项
                    visualmap_opts=opts.VisualMapOpts(
                        is_show=True,  # 是否显示
                        min_=0,  # 左下角刻度最小值
                        max_=2000
                    )
                )
                .render("全国疫情可视化.html")
            )
            flag = 0

        # 本土新增无症状

        obj5 = re.compile(
            r'<div class="con" id="xw_box">.*?<p.*?新疆生产建设兵团报告新增无症状感染者.*?其中境外输入.*?</span>(?P<main>.*?)例）。.*?</p>', re.S)
        ret5 = obj5.search(child_resp.text)
        ta = ret5.group('main')
        obj6 = re.compile(r'例.(?P<sm>.*?)<span.*?>(?P<sl>.*?)</span>', re.S)
        ret6 = obj6.finditer(ta)
        for it in ret6:
            if it.group('sm') == '本土':
                sheet.write(36, count, it.group('sl'))
            else:
                for p in range(37, 68):
                    if it.group('sm') == Dict[p-37]:
                        sheet.write(p, count, it.group('sl'))
                        break
        # 港澳台
        obj7 = re.compile(r'<div class="con" id="xw_box">.*?<p.*?累计收到港澳台地区通报确诊病例.*?</span>例。其中(?P<gat>.*?)。.*?</p>', re.S)
        ret7 = obj7.search(child_resp.text)
        tb = ret7.group('gat')
        obj8 = re.compile(r'，(?P<name>.*?)<span.*?>(?P<number>.*?)</span>例.*?例）', re.S)
        ret8 = obj8.finditer(tb)  # 爬出当天确诊数
        ou = 33
        for it in ret8:
            sheet.write(ou, count, it.group('number'))
            ou=ou+1
        child_resp.close()
        # 转向下一列
        count = count+1
    resp.close()
    break

savepath = 'E:/Users/lenovo/PycharmProjects/pythonProject/爬虫/疫情.xls'
book.save(savepath)






