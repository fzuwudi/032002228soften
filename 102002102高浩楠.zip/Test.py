import requests
import os
import re
import xlwt
import time
import json
import matplotlib.pyplot as plt
import tkinter
from tkinter import ttk
from tkinter import *
from pyecharts.charts import Map
import pyecharts.options as opts

#1.获取数据

# 从网页中爬取数据
def get_data_html():

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.1 (KHTML, like Gecko) Chrome/14.0.835.163 '
                      'Safari/535.1'}

    # 请求网址页面
    response = requests.get('https://ncov.dxy.cn/ncovh5/view/pneumonia?from=timeline&isappinstalled=0', headers=headers,
                            timeout=3)
    # 重新编码
    response = str(response.content, 'utf-8')
    # 返回数据
    return response

def get_data_dictype():
    areas_type_dic_raw = re.findall('try { window.getAreaStat = (.*?)}catch\(e\)', get_data_html())
    areas_type_dic = json.loads(areas_type_dic_raw[0])
    # 返回json转换过后的数据
    return areas_type_dic


#检查数据目标路径
def make_dir():
    # 检查数据路径
    file_path = 'C:/Users/Dell/PycharmProjects/pythonProject/中国疫情最新信息'
    # 若数据路径不存在
    if not os.path.exists(file_path):
       print('数据目标文件夹不存在')
       #创建数据路径
       os.makedirs(file_path)
       print('数据目标文件夹创建成功,文件夹为%s' % (file_path))
    else:
        #数据路径已存在
        print('数据目标文件夹为：%s ' % (file_path))


#2. 导入Execl表

def createxcelsheet(workbook, name):
    worksheet = workbook.add_sheet(name, cell_overwrite_ok=True)
    for i in range(0, 9):
        worksheet.col(i).width = 256 * 15
    al = xlwt.Alignment()
    al.horz = 0x02  # 设置水平居中
    style = xlwt.XFStyle()
    style.alignment = al
    # 写入数据列标签
    worksheet.write(0, 0, '城市名称', style)
    worksheet.write(0, 1, '现存确诊人数', style)
    worksheet.write(0, 2, '累计确诊人数', style)
    worksheet.write(0, 3, '疑似人数', style)
    worksheet.write(0, 4, '治愈人数', style)
    worksheet.write(0, 5, '死亡人数', style)
    worksheet.write(0, 6, '地区ID编码', style)
    return worksheet, style

# 获得中国省份名称和累计确诊人数
global label, values
label = []
values = []

#将数据导入在Excel中
def save_data_to_excel():
    #创建文件夹
    make_dir()
    # 打开工作簿 创建工作表
    newworkbook = xlwt.Workbook()
    sheet, style = createxcelsheet(newworkbook, '中国各省')
    count = 1  # 中国各省的计数器
    for province_data in get_data_dictype():
        c_count = 1  # 某省的计数器
        provincename = province_data['provinceName']
        provinceshortName = province_data['provinceShortName']
        p_currentconfirmedCount = province_data['currentConfirmedCount']
        p_confirmedcount = province_data['confirmedCount']
        p_suspectedcount = province_data['suspectedCount']
        p_curedcount = province_data['curedCount']
        p_deadcount = province_data['deadCount']
        p_locationid = province_data['locationId']
        # 用循环获取省级以及该省以下城市的数据
        label.append(provincename)

        values.append(p_confirmedcount)
        sheet.write(count, 0, provincename, style)
        sheet.write(count, 1, p_currentconfirmedCount, style)
        sheet.write(count, 2, p_confirmedcount, style)
        sheet.write(count, 3, p_suspectedcount, style)
        sheet.write(count, 4, p_curedcount, style)
        sheet.write(count, 5, p_deadcount, style)
        sheet.write(count, 6, p_locationid, style)
        count += 1
        worksheet, style = createxcelsheet(newworkbook, provincename)
        worksheet.write(c_count, 0, provinceshortName, style)
        worksheet.write(c_count, 1, p_currentconfirmedCount, style)
        worksheet.write(c_count, 2, p_confirmedcount, style)
        worksheet.write(c_count, 3, p_suspectedcount, style)
        worksheet.write(c_count, 4, p_curedcount, style)
        worksheet.write(c_count, 5, p_deadcount, style)
        worksheet.write(c_count, 6, p_locationid, style)
        # 在工作表里写入省级数据
        c_count += 2  # 省与省下各城市之间空一行

        for citiy_data in province_data['cities']:
            # 该部分获取某个省下某城市的数据
            cityname = citiy_data['cityName']
            c_currentconfirmedCount = citiy_data['currentConfirmedCount']
            c_confirmedcount = citiy_data['confirmedCount']
            c_suspectedcount = citiy_data['suspectedCount']
            c_curedcount = citiy_data['curedCount']
            c_deadcount = citiy_data['deadCount']
            c_locationid = citiy_data['locationId']
            # 向Excel对应列标写入数据
            worksheet.write(c_count, 0, cityname, style)
            worksheet.write(c_count, 1, c_currentconfirmedCount, style)
            worksheet.write(c_count, 2, c_confirmedcount, style)
            worksheet.write(c_count, 3, c_suspectedcount, style)
            worksheet.write(c_count, 4, c_curedcount, style)
            worksheet.write(c_count, 5, c_deadcount, style)
            worksheet.write(c_count, 6, c_locationid, style)
            c_count += 1  # 此处为写入行数累加，在cities部分循环

    current_time = time.strftime("%Y年%m月%d日%H：%M：%S", time.localtime())
    newworkbook.save('C:/Users/Dell/PycharmProjects/pythonProject/中国疫情信息/实时采集-%s.xls' % current_time)
    print('******数据爬取成功******')

#3. 数据可视化
#中国疫情确诊人数前五省饼状图
def sjvisual():
    # 解决中文显示问题
    plt.rcParams['font.sans-serif'] = ['SimHei']
    # 解决负号显示问题
    plt.rcParams['axes.unicode_minus'] = False
    plt.figure(figsize=(7, 6))

    z = zip(label, values)
    s = sorted(z, key=lambda x: x[1], reverse=True)
    top5 = s[0:5:]
    labels = (dict(top5)).keys()
    values1 = (dict(top5)).values()
    # 绘制饼图
    plt.pie(values1, labels=labels, radius=1.2, pctdistance=0.8, autopct='%1.2f%%')
    # 保存饼图
    plt.savefig('C:/Users/Dell/PycharmProjects/pythonProject/中国疫情信息/中国疫情确诊人数前五省饼状图.png')
    plt.show()

#中国疫情累计感染人数分布地图
def Map():
    # 解决中文显示问题
    plt.rcParams['font.sans-serif'] = ['SimHei']
    # 解决负号显示问题
    plt.rcParams['axes.unicode_minus'] = False
    plt.figure(figsize=(7, 6))
    label = []
    values= []

    x = []  # 把各省感染人数与各省对应
    for i in range(len()):
        label.append()
        values.append()
    for z in zip(list(label), list(values)):
        list(z)
        x.append(z)

    area_map = Map()
    area_map.add("中国疫情感染人数分布图", x, "china", is_map_symbol_show=False)
    area_map.set_global_opts(title_opts=opts.TitleOpts(title="中国疫情累计感染人数分布地图"),
                             visualmap_opts=opts.VisualMapOpts(is_piecewise=True,
                                                               pieces=[
                                                                   {"min": 1500, "label": '>10000人',
                                                                    "color": "#6F171F"},
                                                                   {"min": 500, "max": 15000, "label": '500-1000人',
                                                                    "color": "#C92C34"},
                                                                   {"min": 100, "max": 499, "label": '100-499人',
                                                                    "color": "#E35B52"},
                                                                   {"min": 10, "max": 99, "label": '10-99人',
                                                                    "color": "#F39E86"},
                                                                   {"min": 1, "max": 9, "label": '1-9人',
                                                                    "color": "#FDEBD0"}]))
    area_map.render_notebook()
    area_map.savefig('C:/Users/Dell/PycharmProjects/pythonProject/中国疫情信息/中国疫情累计感染人数分布图.png')
    area_map.show()



#4. GUI界面

# 制作GUI界面
def GUI():
    global win
    win = tkinter.Tk()
    win.minsize(800, 660)
    win.title('中国各省疫情情况查询')
    tkinter.Label(win, text='请选择省份：', height=1, width=10).place(x=200, y=0)
    tkinter.Label(win, text='省份：').place(x=240, y=40)
    tkinter.Label(win, text='现存确诊人数：').place(x=240, y=70)
    tkinter.Label(win, text='累计确诊人数：').place(x=240, y=100)
    tkinter.Label(win, text='疑似人数：').place(x=240, y=130)
    tkinter.Label(win, text='治愈人数：').place(x=240, y=160)
    tkinter.Label(win, text='死亡人数：').place(x=240, y=190)

    # 将下拉列表框定义为全局变量
    global comboxlist
    comvalue = tkinter.StringVar()
    # 初始化
    comboxlist = ttk.Combobox(win, textvariable=comvalue)
    comboxlist["values"] = label
    comboxlist.current(0)
    comboxlist.bind("<<ComboboxSelected>>", go)
    comboxlist.pack()
    # 进入消息循环
    win.mainloop()


global tst
tst = []

# 处理事件，*args表示可变参数
def go(*args):
    for i in tst:
        i.place_forget()
    # 被选中的省份
    c = comboxlist.get()
    for province_data in get_data_dictype():
        provincename = province_data['provinceName']
        if c == provincename:
            tkinter.Label(win, text=provincename, height=1, width=15).place(x=400, y=40)
            tkinter.Label(win, text=province_data['currentConfirmedCount'], height=1, width=10).place(x=400, y=70)
            tkinter.Label(win, text=province_data['confirmedCount'], height=1, width=10).place(x=400, y=100)
            tkinter.Label(win, text=province_data['suspectedCount'], height=1, width=10).place(x=400, y=130)
            tkinter.Label(win, text=province_data['curedCount'], height=1, width=10).place(x=400, y=160)
            tkinter.Label(win, text=province_data['deadCount'], height=1, width=10).place(x=400, y=190)
            tkinter.Label(win, text='\t请选择' + provincename + '下地区：', height=1, width=20).place(x=50, y=220)
            # 设置城市按钮的位置
            lt = [(15, 240), (115, 240), (215, 240), (315, 240), (415, 240), (515, 240), (615, 240), (715, 240),
                  (15, 280), (115, 280), (215, 280), (315, 280), (415, 280), (515, 280), (615, 280), (715, 280),
                  (15, 320), (115, 320), (215, 320), (315, 320), (415, 320), (515, 320), (615, 320), (715, 320),
                  (15, 360), (115, 360), (215, 360), (315, 360), (415, 360), (515, 360), (615, 360), (715, 360),
                  (15, 400), (115, 400), (215, 400), (315, 400), (415, 400), (515, 400), (615, 400), (715, 400)]
            # 按钮位置计数器
            ct = 0
            for city_data in province_data['cities']:
                while ct < len(province_data['cities']):
                    b = Button(win, text=city_data['cityName'], height=1, width=10)
                    # 装入按钮
                    tst.append(b)
                    b.place(x=lt[ct][0], y=lt[ct][1])
                    # 当按钮被选中，绑定show函数
                    b.bind('<Button-1>', show)
                    ct += 1
                    break
                tkinter.Label(win, text='地区：').place(x=240, y=435)
                tkinter.Label(win, text='现存确诊人数：').place(x=240, y=465)
                tkinter.Label(win, text='累计确诊人数：').place(x=240, y=495)
                tkinter.Label(win, text='疑似人数：').place(x=240, y=525)
                tkinter.Label(win, text='治愈人数：').place(x=240, y=555)
                tkinter.Label(win, text='死亡人数：').place(x=240, y=585)

# 显示对应城市数据
def show(event):
    # comboxlist.get()得到查询的省份
    c = comboxlist.get()
    # 获得被选中城市（按钮）名称
    for province_data in get_data_dictype():
        provincename = province_data['provinceName']
        if c == provincename:
            for city_data in province_data['cities']:
                # event.widget[‘text’]能得到查询的省下地区
                if city_data['cityName'] == event.widget['text']:
                    tkinter.Label(win, text=city_data['cityName'], height=1, width=15).place(x=400, y=435)
                    tkinter.Label(win, text=city_data['currentConfirmedCount'], height=1, width=15).place(x=400, y=465)
                    tkinter.Label(win, text=city_data['confirmedCount'], height=1, width=15).place(x=400, y=495)
                    tkinter.Label(win, text=city_data['suspectedCount'], height=1, width=15).place(x=400, y=525)
                    tkinter.Label(win, text=city_data['curedCount'], height=1, width=15).place(x=400, y=555)
                    tkinter.Label(win, text=city_data['deadCount'], height=1, width=15).place(x=400, y=585)

save_data_to_excel()
sjvisual()
GUI()
Map()