import requests
import re
import openpyxl
import os
from lxml import etree
from pyecharts.charts import Map3D
from pyecharts.globals import ChartType
from pyecharts.commons.utils import JsCode
from pyecharts.charts import Bar, Grid, Line, Pie, Tab
from pyecharts.charts import Line
from pyecharts import options as opts
from pyecharts.charts import Map, Timeline

app_issue = ['本土病例', '北京', '天津', '上海', '重庆', '河北', '山西',
             '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南',
             '广东', '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海', '新疆', '内蒙古', '广西', '西藏',
             '宁夏', '台湾新增', '香港新增', '澳门新增', '台湾地区', '香港特别行政区', '澳门特别行政区']
not_issue = ['本土', '北京', '天津', '上海', '重庆', '河北', '山西', '辽宁',
             '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南', '广东',
             '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海', '新疆', '内蒙古', '广西', '西藏', '宁夏']
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Encoding': 'gzip, deflate',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Cookie': 'yfx_c_g_u_id_10006654=_ck22090517092711557123132504572; yfx_f_l_v_t_10006654=f_t_1662368967158__r_t_1662514638127__v_t_1662514638127__r_c_2; yfx_mr_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_mr_f_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_key_10006654=; sVoELocvxVW0S=57yh5eHi6BlWwbYuOEUHFMNXf_2SF8UL5VWS1759zdOiiImwtyLuvBL1rWffIpGlLnMEMoxnpQBHoAej5Qug.gG; security_session_verify=fc465e4f1828940ec0438b63374ada0a; sVoELocvxVW0T=53SI0.DWUeQ7qqqDkmRH3_AToYARjKiHRH568jKOM4B.OPNB2axXw5kqAtweBhHBYQOYh3hRO8OaMl8SZuRBb4HDDy8wWx_H9KnDMJfOHJhLKqwvylr_gmnhMbVf7Xl1INInmRUZl8aTrrguv1MWZmyUOXCgg2aOx6_4J72Gm.uCLEdwxtjF7hWLGGpO..CyBUuKFNGN8o.f7i5cTf3DueMgKy959yMbnxH14vnDsH.wVdK4nQbz4PLAMqYCxYgwjT4eY2xujVIScYsPVxnC5uNL45UyizBvMCagu5cjSPGfoWPa5mHqCrzryZOZ96c0axMDYQTxAdJ7LeVECT_l6vDQTiBIU5G26AzdTJ07AoQza; insert_cookie=91349450',
    'Host': 'www.nhc.gov.cn',
    'Referer': 'https://cn.bing.com/',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33'}
should_write_a_row = 0
should_write_n_row = 0

def init_xls():
    wb = openpyxl.Workbook()
    del wb["Sheet"]
    sheet_a = wb.create_sheet("新增普通")
    sheet_n = wb.create_sheet("新增无症状")

    sheet_a.cell(1, 1, "日期")
    for x1, x2 in zip(range(2, 40), app_issue):
        sheet_a.cell(1, x1, x2)
    should_write_a_row = should_write_a_row + 1
    # 初始化本土无症状新增表格头
    sheet_n.cell(1, 1, "日期")
    for x1, x2 in zip(range(2, 34), not_issue):
        sheet_n.cell(1, x1, x2)
    should_write_n_row = should_write_n_row + 1
    return wb

def getwebpage(page_limit):
    for page in range(1, page_limit):
        if page == 1:
            url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
        else:
            url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_{}.shtml'.format(page)


        respond = requests.get(url, headers=headers)
        ecode = etree.HTML(respond.text)
        html = ecode.xpath('//div[@class="w1024 mb50"]/div[@class="list"]/ul[@class="zxxx_list"]/li/a/@href')
        title = ecode.xpath('//div[@class="w1024 mb50"]/div[@class="list"]/ul[@class="zxxx_list"]/li/a/@title')

        for html_itr, title_itr in zip(html, title):
            #使用正则表达式解析数据
            first_pattern = re.compile('新增确诊[\u4e00-\u9fa5]+[0-9]+例[。|，][^。]+|新增无症状[\u4e00-\u9fa5]+[0-9]+例[。|，][^。]+|累计收到[\u4e00-\u9fa5]+[0-9]+[^ ]+')
            second_pattern = '本土病例[0-9]+例[^。）]+|本土[0-9]+例[^。）]+|累计收到[\u4e00-\u9fa5]+[0-9]+[^ ]+'
            digit_pattern = '[0-9]+'
            hanzi_pattern = '[\u4e00-\u9fa5]+'
            Li_pattern = '[\u4e00-\u9fa5]{2,}[0-9]+(?=例|人)'
            date_pattern = '[0-9]+月[0-9]+日'


            adata = dict.fromkeys(app_issue, 0)
            ndata = dict.fromkeys(not_issue, 0)

            surl = "http://www.nhc.gov.cn" + html_itr
            resq = requests.get(surl, headers=headers)

            secode = etree.HTML(resq.text)
            text_list = secode.xpath('string(.)')
            text = ''.join(text_list)

            #文本处理
            time_data = re.findall(date_pattern, title_itr)
            text_data_temp_list_1 = re.findall(first_pattern, text)
            text_data_temp_1 = ''.join(text_data_temp_list_1)
            text_data_temp_list_2 = re.findall(second_pattern, text_data_temp_1)
            text_data_temp_2 = '\n'.join(text_data_temp_list_2)
            text_data_list = re.findall(Li_pattern, text_data_temp_2)

            flag = 1
            for item in text_data_list:
                words = ''.join(re.findall(hanzi_pattern, item))
                num = ''.join(re.findall(digit_pattern, item))


                #文本解析后天然顺序普通新增在前面无症状在中间港澳台在最后所有设置一个flag来区分录入的信息
                if words == "本土病例":#普通新增flag=1
                    flag = 1
                elif words == "本土":#无症状flag=0
                    flag = 0

                if flag == 1:
                    if (words in adata):
                        adata[words] = int(num)
                    else:
                        continue

                elif flag == 0:
                    if (words in ndata):
                        ndata[words] = int(num)

                    elif (words in adata):#港澳台同一录入普通新增
                        adata[words] = int(num)
                    else:
                        continue
