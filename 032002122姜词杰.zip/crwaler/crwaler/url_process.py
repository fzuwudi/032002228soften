import urllib.request
import asyncio
import lxml
from lxml import etree
import requests
from pyppeteer import launch
from bs4 import BeautifulSoup
import time
import re
import openpyxl
from pyecharts import options as opts
from pyecharts.charts import Map3D
from pyecharts.globals import ChartType
from pyecharts.commons.utils import JsCode
from pyecharts.charts import Map, Timeline
import os

app_issue = ['本土病例', '北京', '天津', '上海', '重庆', '河北', '山西',
             '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南',
             '广东', '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海', '新疆', '内蒙古', '广西', '西藏',
             '宁夏','台湾新增','香港新增','澳门新增','台湾地区', '香港特别行政区', '澳门特别行政区']
not_issue = ['本土', '北京', '天津', '上海', '重庆', '河北', '山西', '辽宁',
             '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南', '广东',
             '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海', '新疆', '内蒙古', '广西', '西藏', '宁夏']
headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'Accept-Encoding': 'gzip, deflate',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Cookie': 'yfx_c_g_u_id_10006654=_ck22090517092711557123132504572; yfx_f_l_v_t_10006654=f_t_1662368967158__r_t_1662514638127__v_t_1662514638127__r_c_2; yfx_mr_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_mr_f_10006654=%3A%3Amarket_type_free_search%3A%3A%3A%3Abaidu%3A%3A%3A%3A%3A%3A%3A%3Awww.baidu.com%3A%3A%3A%3Apmf_from_free_search; yfx_key_10006654=; sVoELocvxVW0S=57yh5eHi6BlWwbYuOEUHFMNXf_2SF8UL5VWS1759zdOiiImwtyLuvBL1rWffIpGlLnMEMoxnpQBHoAej5Qug.gG; security_session_verify=fc465e4f1828940ec0438b63374ada0a; sVoELocvxVW0T=53SI0.DWUeQ7qqqDkmRH3_AToYARjKiHRH568jKOM4B.OPNB2axXw5kqAtweBhHBYQOYh3hRO8OaMl8SZuRBb4HDDy8wWx_H9KnDMJfOHJhLKqwvylr_gmnhMbVf7Xl1INInmRUZl8aTrrguv1MWZmyUOXCgg2aOx6_4J72Gm.uCLEdwxtjF7hWLGGpO..CyBUuKFNGN8o.f7i5cTf3DueMgKy959yMbnxH14vnDsH.wVdK4nQbz4PLAMqYCxYgwjT4eY2xujVIScYsPVxnC5uNL45UyizBvMCagu5cjSPGfoWPa5mHqCrzryZOZ96c0axMDYQTxAdJ7LeVECT_l6vDQTiBIU5G26AzdTJ07AoQza; insert_cookie=91349450',
        'Host': 'www.nhc.gov.cn',
        'Referer': 'https://cn.bing.com/',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33'}
#=====================================================
# 写入excel表格操作,创建excel表格
wb = openpyxl.Workbook()
del wb["Sheet"]
sheet_a = wb.create_sheet("新增普通")
sheet_n = wb.create_sheet("新增无症状")

#=====================================================
# 初始化本土普通新增表格头
sheet_a.cell(1, 1, "日期")
for x1, x2 in zip(range(2, 40), app_issue):
    sheet_a.cell(1, x1, x2)
# 初始化本土无症状新增表格头
sheet_n.cell(1, 1, "日期")
for x1, x2 in zip(range(2, 34), not_issue):
    sheet_n.cell(1, x1, x2)
#=====================================================
#爬取页数
range_up_limit=2
for i in range(1, range_up_limit):
    if i == 1:
        url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
    else:
        url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_{}.shtml'.format(i)

    req = requests.get(url, headers=headers)
    # print(req.status_code)
    e = etree.HTML(req.text)
    html = e.xpath('//div[@class="w1024 mb50"]/div[@class="list"]/ul[@class="zxxx_list"]/li/a/@href')
    title = e.xpath('//div[@class="w1024 mb50"]/div[@class="list"]/ul[@class="zxxx_list"]/li/a/@title')
    # print("I am here1")

    for html_ite, title_c, count_line in zip(html, title, range(len(html))):
        # print("I am here2")

        #省份字典操作
        adata = dict.fromkeys(app_issue, 0)
        ndata = dict.fromkeys(not_issue, 0)

        #访问网站并解析html
        surl = "http://www.nhc.gov.cn" + html_ite
        resq = requests.get(surl, headers=headers)
        se = etree.HTML(resq.text)

        #获取纯文本信息
        words_num = se.xpath('string(.)')
        text = ''.join(words_num)


        #单独获取新增确诊和新增无症状港澳台三段文字且进行拼接
        #正则表达式模式
        yiqing_pattern = '[\u4e00-\u9fa5]{2,}[0-9]+(?=例|人)'
        first_pattern = re.compile('新增确诊[\u4e00-\u9fa5]+[0-9]+例[。|，][^。]+|新增无症状[\u4e00-\u9fa5]+[0-9]+例[。|，][^。]+|累计收到[\u4e00-\u9fa5]+[0-9]+[^ ]+')
        digit_pattern = '[0-9]+'
        hanzi_pattern = '[\u4e00-\u9fa5]+'
        date_pattern = '[0-9]+月[0-9]+日'
        in_in_pattern = '本土病例[0-9]+例[^。）]+|本土[0-9]+例[^。）]+|累计收到[\u4e00-\u9fa5]+[0-9]+[^ ]+'

        time_data = re.findall(date_pattern, title_c)
        time_data_final=''.join(time_data)
        print(time_data_final + ":")


        #文本处理
        says_1 = re.findall(first_pattern, text)
        temp_1 = ''.join(says_1)
        says_2 = re.findall(in_in_pattern, temp_1)
        temp_2 = '\n'.join(says_2)
        final_says = re.findall(yiqing_pattern, temp_2)
        #病例信息录入字典
        flag = 1
        for item in final_says:
            words = ''.join(re.findall(hanzi_pattern, item))
            num = ''.join(re.findall(digit_pattern, item))
            # print("I am here")

            if words == "本土病例":
                flag = 1
            elif words == "本土":
                flag = 0


            if flag == 1:
                if(words in adata):
                    adata[words] = int(num)
                else:
                    continue

            elif flag == 0:
                if(words in ndata):
                    ndata[words] = int(num)

                elif(words in adata):
                    adata[words] = int(num)
                else:
                    continue

        #数据录入excel表格
        sheet_a.cell(1+(i-1)*24+count_line+1, 1).value = time_data_final
        for x1 in range(2, 40):
            if sheet_a.cell(1, x1).value == "台湾新增":
                if(i == range_up_limit-1 and count_line == len(html)-1):
                    sheet_a.cell(1 + (i - 1) * 24 + count_line + 1, x1).value = 0
                else:
                    str1 = 'AK' + str(1 + (i - 1) * 24 + count_line + 1)
                    str2 = 'AK' + str(1 + (i - 1) * 24 + count_line + 2)
                    str3 = str1 + '-' + str2
                    sheet_a.cell(1 + (i - 1) * 24 + count_line + 1, x1).value = '=' + str3

            elif sheet_a.cell(1, x1).value == "香港新增":
                if(i == range_up_limit-1 and count_line == len(html)-1):
                    sheet_a.cell(1 + (i - 1) * 24 + count_line + 1, x1).value = 0
                else:
                    str1 = 'AL' + str(1 + (i - 1) * 24 + count_line + 1)
                    str2 = 'AL' + str(1 + (i - 1) * 24 + count_line + 2)
                    str3 = str1 + '-' + str2
                    sheet_a.cell(1 + (i - 1) * 24 + count_line + 1, x1).value = '=' + str3

            elif sheet_a.cell(1, x1).value == "澳门新增":
                if(i == range_up_limit-1 and count_line == len(html)-1):
                    sheet_a.cell(1 + (i - 1) * 24 + count_line + 1, x1).value = 0
                else:
                    str1 = 'AM' + str(1 + (i - 1) * 24 + count_line + 1)
                    str2 = 'AM' + str(1 + (i - 1) * 24 + count_line + 2)
                    str3 = str1 + '-' + str2
                    sheet_a.cell(1 + (i - 1) * 24 + count_line + 1, x1).value = '=' + str3

            elif (sheet_a.cell(1, x1).value) in adata:
                sheet_a.cell(1+(i-1)*24+count_line+1, x1).value = adata[sheet_a.cell(1, x1).value]

        sheet_n.cell(1+(i-1)*24+count_line+1, 1).value = time_data_final
        for x1 in range(2, 34):
            sheet_n.cell(1+(i-1)*24+count_line+1, x1).value = ndata[sheet_n.cell(1, x1).value]

        #控制台检测数据
        for key, value in zip(adata.keys(), adata.values()):
            print(key,":",value)
        print("******************************************************")
        for key, value in zip(ndata.keys(), ndata.values()):
            print(key,":",value)
        print("======================================================")

        #将疫情信息导入表格中
        if(i == 1 and count_line == 0):
            example_data = [
                ("黑龙江", [127.9688, 45.368, adata["黑龙江"]]),
                ("内蒙古", [110.3467, 41.4899, adata["内蒙古"]]),
                ("吉林", [125.8154, 44.2584, adata["吉林"]]),
                ("辽宁", [123.1238, 42.1216, adata["辽宁"]]),
                ("河北", [114.4995, 38.1006, adata["河北"]]),
                ("天津", [117.4219, 39.4189, adata["天津"]]),
                ("山西", [112.3352, 37.9413, adata["山西"]]),
                ("陕西", [109.1162, 34.2004, adata["陕西"]]),
                ("甘肃", [103.5901, 36.3043, adata["甘肃"]]),
                ("宁夏", [106.3586, 38.1775, adata["宁夏"]]),
                ("青海", [101.4038, 36.8207, adata["青海"]]),
                ("新疆", [87.9236, 43.5883, adata["新疆"]]),
                ("西藏", [91.11, 29.97, adata["西藏"]]),
                ("四川", [103.9526, 30.7617, adata["四川"]]),
                ("重庆", [108.384366, 30.439702, adata["重庆"]]),
                ("山东", [117.1582, 36.8701, adata["山东"]]),
                ("河南", [113.4668, 34.6234, adata["河南"]]),
                ("江苏", [118.8062, 31.9208, adata["江苏"]]),
                ("安徽", [117.29, 32.0581, adata["安徽"]]),
                ("湖北", [114.3896, 30.6628, adata["湖北"]]),
                ("浙江", [119.5313, 29.8773, adata["浙江"]]),
                ("福建", [119.4543, 25.9222, adata["福建"]]),
                ("江西", [116.0046, 28.6633, adata["江西"]]),
                ("湖南", [113.0823, 28.2568, adata["湖南"]]),
                ("贵州", [106.6992, 26.7682, adata["贵州"]]),
                ("广西", [108.479, 23.1152, adata["广西"]]),
                ("海南", [110.3893, 19.8516, adata["海南"]]),
                ("上海", [121.4648, 31.2891, adata["上海"]]),
                ("北京", [116.46, 39.92, adata["北京"]]),
                ("香港", [114.1733, 22.3200, adata["香港新增"]]),
                # ("澳门", [114.1733, 22.3200, li["澳门"]]),
                ("云南", [100.2969, 25.7217, adata["云南"]]),
                ("澳门", [111.9586, 21.8, adata["澳门新增"]]),
                ("台湾", [121.5200, 25.0307, adata["台湾新增"]])
            ]
            c = (
                Map3D(init_opts=opts.InitOpts(width="1600px", height="900px"))
                .add_schema(
                    itemstyle_opts=opts.ItemStyleOpts(
                        color="rgb(2,115,115)",
                        opacity=1,
                        border_width=0.8,
                        border_color="rgb(1,64,64)",
                    ),
                    map3d_label=opts.Map3DLabelOpts(
                        is_show=False,
                        formatter=JsCode("function(data){return data.name + " " + data.value[2];}"),
                    ),
                    emphasis_label_opts=opts.LabelOpts(
                        is_show=False,
                        color="#fff",
                        font_size=10,
                        background_color="rgba(0,23,11,0)",
                    ),
                    light_opts=opts.Map3DLightOpts(
                        main_color="#fff",
                        main_intensity=1.2,
                        main_shadow_quality="high",
                        is_main_shadow=True,
                        main_beta=10,
                        ambient_intensity=0.3,
                    ),
                )
                .add(
                    series_name="今日新增确诊",
                    data_pair=example_data,
                    type_=ChartType.BAR3D,
                    bar_size=1,
                    shading="lambert",
                    label_opts=opts.LabelOpts(
                        is_show=True,
                        formatter=JsCode("function(data){return data.name + ' ' + data.value[2];}"),
                    ),
                )
                .set_global_opts(title_opts=opts.TitleOpts(title="今日疫情数据"), visualmap_opts=opts.VisualMapOpts(max_=150,  range_color=[
                "#313695",
                "#4575b4",
                "#74add1",
                "#abd9e9",
                "#e0f3f8",
                "#ffffbf",
                "#fee090",
                "#fdae61",
                "#f46d43",
                "#d73027",
                "#a50026",
            ]))
                .render("map3d_with_bar3d.html")
            )
            os.system("map3d_with_bar3d.html")
wb.save("covid-19.xls")




