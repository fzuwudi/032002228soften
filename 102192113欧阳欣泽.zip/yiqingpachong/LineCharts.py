#折线图

from ChineseMap import ChineseMap

import pandas as pd  # 读取excel
from pyecharts import options as opts  # 可视化选项
from pyecharts.charts import Timeline, Map, Line  # 时间线、地图



class LineCharts:
    #获取一月份的日期list
    def get_monthlist(self, year, month, choose):
        daylist = []
        bmongth = [1, 3, 5, 7, 8, 10, 12]
        mmongth = [4, 6, 9, 11]
        max = 0
        if month in bmongth:
            max = 32
        elif month in mmongth:
            max = 31
        else:
            max = 29
        for number in range(1, max):
            day = str(year) + "年" + str(month) + "月" + str(number) + "日"
            tmp = ChineseMap().get_daytitle_list(day, choose)
            daylist.append(tmp[1])

        return daylist

    #读取文件返回省份数据
    #input： filename 文件名，sheetname 页名， titlelist 列名list， sp为3时返回港澳台数据其他值返回大陆数据
    #output： resultlist 每日共计数据
    def read_file(self, filename, sheetname, titlelist):
        data = pd.read_excel(filename, sheet_name=sheetname, usecols=titlelist)
        label_need = data.keys()
        resultlist = []
        try:
            number = len(titlelist) - 1
            while number >= 0 :
                tmp = data[label_need[number]]
                result = tmp[32]
                resultlist.append(int(result))
                number = number - 1
            print(resultlist)
            return resultlist
        except:
            return resultlist
    #生成折线图
    #input：year 年 month 月 choose：1-大陆新增确诊 2-大陆新增无症状 3-港澳台累计
    #output：linecharts.render_notebook() tml文件
    def get_liecharts(self, year, month, choose):
        if choose == 3:
            return "no message!!"
        titlelist = self.get_monthlist(year, month, choose)
        linecharts = (
        #设置尺寸
            Line(init_opts=opts.InitOpts(width="1000px", height="600px"))
            #添加x y轴数据
            .add_xaxis(xaxis_data=titlelist)
            .add_yaxis(
                series_name="每日新增统计",
                y_axis=self.read_file("yiqing.xlsx", "mysheet", titlelist),

                # 显示平均值
                 markline_opts=opts.MarkLineOpts(
                 data=[opts.MarkLineItem(type_="average", name="平均值")]
                 ),
            )

            .set_global_opts(
                title_opts=opts.TitleOpts(title="大陆本月新增累计", subtitle="副标题"),
                xaxis_opts=opts.AxisOpts(type_="category", boundary_gap=False),
            ))

        return linecharts.render_notebook()