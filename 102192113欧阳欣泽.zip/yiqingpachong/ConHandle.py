import re
import numpy as np
import pandas as pd
import time
import csv
import openpyxl
import pathlib
import os
import gc
import objgraph
from openpyxl import load_workbook


class ConHandle:
    province = {'河北': 1, '山西': 2, '辽宁': 3, '吉林': 4, '黑龙江': 5, '江苏': 6, '浙江': 7, '安徽': 8, '福建': 9,
                '江西': 10, '山东': 11, '河南': 12, '湖北': 13, '湖南': 14, '广东': 15, '海南': 16, '四川': 17,
                '贵州': 18, '云南': 19, '陕西': 20, '甘肃': 21, '青海': 22, '内蒙古': 23, '西藏': 24, '宁夏': 25,
                '新疆': 26, '广西': 27, '北京': 28, '天津': 29, '上海': 30, '重庆': 31, '兵团': 32, '共计': 33}
    spprovince = {'香港特别行政区': 1, '澳门特别行政区': 2, '台湾地区': 3}
    year = 2022
    ws1_name = 'mysheet'
    #字符串中提取省份信息
    #input：str 输入字符串
    #ouput：pro_name，data list 省份名称+省份疫情数据即人数
    def get_pro_info(self, str):
        print("this is get_pro_info")
        #遍历字符串每个字符
        tmp = ""
        dig = ""
        sign = 0
        for item in str:
            #如果是数据则持续读取
            if item.isdigit():
                dig = dig + item
                sign = 1
            elif sign == 0 and not item.isdigit():
                tmp = tmp + item
                #字符时遇到以下字符则清空重新添加
                if ((item == "；") | (item == "在") | (item == "中")):
                    tmp = ""
            else:
                print("nothing")
        pro_name = tmp
        if dig == "":
            dig = dig + "0"
        data = int(dig)
        print(tmp)
        print(data)
        yield pro_name, data


    #写列名标题
    def write_title(self, t1, t2, co1, co2, filename, bg, sheet):
        print(t1)
        print(t2)
        sheet.cell(1, co1, t1)
        sheet.cell(1, co2, t2)
        bg.save(filename)
    #初始化文件
    #input：filename：文件名
    def creat_file(self, filename):
        wb = ""
        if not pathlib.Path(filename).exists():
            wb = openpyxl.Workbook()
            return wb
        else:
            wb = openpyxl.load_workbook(filename)
            return wb
    #写省份名称
    #input：co1 co2 co3指定列 sheet页面名
    def write_key(self, co1, co2, co3, sheet):
        for key in self.province.keys():
            line = self.province[key]
            sheet.cell(line + 1, co1, key)
            sheet.cell(line + 1, co2, key)
        for key in self.spprovince.keys():
            line = self.spprovince[key]
            sheet.cell(line + 1, co3, key)
    #填充未有数据的省份赋值为0
    #input dic dic2 dic3 传入省份字典与province字典key比较未存在则填充
    #col1 col2 col3 指定列
    #sheet 页名
    def fill_empty(self, dic, dic2, dic3, col1, col2, col3, sheet):
        for key in self.province.keys():
            if key not in dic.keys():
                line = self.province[key]
                sheet.cell(line + 1, col1, 0)
            if key not in dic2.keys():
                line = self.province[key]
                sheet.cell(line + 1, col2, 0)
        for key in self.spprovince.keys():
            if key not in dic3.keys():
                line = self.spprovince[key]
                sheet.cell(line + 1, col3, 0)
    #写入excel文件主函数
    #input：in_list 新增确诊数据list nolist 新增无症状数据list splist港澳台累计确诊list list给pro_info函数提取出具体的省份和数据
    #day具体日期****年*月*日 co1 co2 co3指定列  sum1大陆每日新增确诊统计 sum2大陆每日新增无症状统计
    def write(self, in_list, day, nolist, splist, co1, co2, co3, sum1, sum2):

        col1 = co1
        col2 = co2
        col3 = co3
        indic = {}
        nodic = {}
        spdic = {}
        wb = self.creat_file('yiqing-write.xlsx')
        if 'Sheet' in wb.sheetnames:
            wb['Sheet'].title = self.ws1_name
        ws1 = wb[self.ws1_name]
        self.write_title(day + "省份", day + "新增确诊病例", col1, col1 + 1, "yiqing-write.xlsx", wb, ws1)
        self.write_title(day + "省份*", day + "新增无症状病例", col2, col2 + 1, "yiqing-write.xlsx", wb, ws1)
        self.write_title(day + "港澳台地区", day + "累计病例", col3, col3 + 1, "yiqing-write.xlsx", wb, ws1)
        self.write_key(co1, co2, co3, ws1)
        #   copysum1 = 0
        # copysum2 = 0
        print("*************************")

        for r in in_list:
            for pro_info, digit in self.get_pro_info(r):
                if pro_info in self.province.keys():
                    #  copysum1 = copysum1 + digit
                    if (len(in_list) == 1):
                        indic[pro_info] = sum1
                    else:
                        indic[pro_info] = digit
                    line = self.province[pro_info]
                    ws1.cell(line + 1, col1 + 1, indic[pro_info])
                    print("write" + pro_info)

        for d in nolist:
            for pro_info, digit in self.get_pro_info(d):
                if pro_info in self.province.keys():
                    #  copysum2 = copysum2 + digit
                    if (len(nolist) == 1):
                        nodic[pro_info] = sum2
                    else:
                        nodic[pro_info] = digit

                    line = self.province[pro_info]
                    ws1.cell(line + 1, col2 + 1, nodic[pro_info])
                    print("write" + pro_info)

        for s in splist:
            for pro_info, digit in self.get_pro_info(s):
                if pro_info in self.spprovince.keys():
                    spdic[pro_info] = digit
                    line = self.spprovince[pro_info]
                    ws1.cell(line + 1, col3 + 1, digit)
                    print("write" + pro_info)
        line = self.province["共计"]

        self.fill_empty(indic, nodic, spdic, col1 + 1, col2 + 1, col3 + 1, ws1)

        ws1.cell(line + 1, col1 + 1, sum1)

        ws1.cell(line + 1, col2 + 1, sum2)

        wb.save("yiqing-write.xlsx")
        wb.close()
        del wb, ws1
        gc.collect()
    #内容处理主函数
    #input：con 爬虫获取文章的内容
    #co1 co2 co3 指定列
    def handle_content(self, con, co1, co2, co3):
        # print(con)
        splist = []
        #正则表达式提取
        pattern1 = re.compile('.*?(\d+).*?月.*?(\d+).*?日.*')
        pattern2 = re.compile('.*?新增确诊.*?本土病例(\d+)例.*?（(.*?)）.*')
        pattern3 = re.compile('.*?新增无症状感染者.*?本土(\d+)例.*?（(.*?)）.*')
        pattern4 = re.compile('.*?(?:港澳台地区).*?其中，?(.*?)（.*?），(.*?)（.*?），(.*?)（.*')
        day_list = pattern1.findall(con)
        day = ""
        for item in day_list:
            day = item[0] + "月" + item[1] + "日"

        colist = re.split('(?:[新疆生产建设]{6,6})', con)
        if day == "12月31日":
            self.year = self.year - 1
        day = str(self.year) + "年" + day
        insbuf = ""
        nosbuf = ""
        spsbuf = []
        sum1 = 0
        sum2 = 0
        for item in colist:
            print(item)
            tmp = pattern2.findall(item)
            if tmp:
                for i1 in tmp:
                    insbuf = insbuf + i1[1]
                    sum1 = int(i1[0])
            tmp = pattern3.findall(item)
            print(tmp)
            if tmp:
                for i2 in tmp:
                    nosbuf = nosbuf + i2[1]
                    sum2 = int(i2[0])
            tmp = pattern4.findall(item)
            if tmp:
                for i3 in tmp:
                    for sp in i3:
                        spsbuf.append(sp)

        print("------------------")
        #分割字符串
        result = re.split('[，；]', str(insbuf))
        noresult = re.split('[，；]', str(nosbuf))
        sp = re.split('[，；]', str(nosbuf))
        self.write(result, day, noresult, spsbuf, co1, co2, co3, sum1, sum2)

        del result, noresult, sp, pattern1, pattern2, pattern3, pattern4, insbuf, nosbuf
        gc.collect()

    def __init__(self):
        print("this is content")





