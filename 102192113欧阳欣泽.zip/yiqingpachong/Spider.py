import os
import asyncio
import time
from pyppeteer import launch
from bs4 import BeautifulSoup
from ConHandle import ConHandle as hand
import random
from pyppeteer_stealth import stealth
import gc
import objgraph

from urllib import request, parse
import urllib3


class Spider:
    stop = 0
    url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_35.shtml'
    #获取url页面
    #input：url 输入url地址
    #output html 返回页面内容
    def urllib_geturl(self, url):
        try:
            #构建请求头
            head = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.98 Safari/537.36'}
            http = urllib3.PoolManager()
            rq = http.request('GET', url=url, headers=head)
            html = rq.data
            print(str(html))
            return html
        #若失败则重试
        except:
            time.sleep(random.randint(1, 3))
            print("fail")
            self.urllib_geturl(url)

    #获取url内容
    #input：html
    #output：url链接的标题
    def geturlContent(self, html):
        try:
            bsobj = BeautifulSoup(html, 'html.parser')
            cnt = bsobj.find('ul', attrs={"class": "zxxx_list"}).find_all('li')
            print(cnt)
            bsobj.decompose()
            s = ""
            if cnt:
                for item in cnt:
                    s = s + str(item.text)
            # print(s)
            cnt = None
            gc.collect()
            return s
        #若失败则返回fail
        except Exception as e:
            gc.collect()
            return "fail!"
    #获取文章内容
    #input：html 页面文章的html文件
    #output：s文章内容字符串
    def getContent(self, html):
        try:
            bsobj = BeautifulSoup(html, 'html.parser')
            cnt = bsobj.find('div', attrs={"class": "con"}).find_all('p')
            print(cnt)
            bsobj.decompose()
            s = ""
            if cnt:
                for item in cnt:
                    s = s + str(item.text)
            cnt = None
            gc.collect()
            return s
        except Exception as e:
            gc.collect()
            return "fail!"
    #获取页面的所有链接
    #input：html 疫情通报选择页面的页面内容
    #output：linklist 所有链接的list
    def getUrl(self, html):
        try:
            bsobj = BeautifulSoup(html, 'html.parser')
            cnt = bsobj.find('ul', attrs={"class": "zxxx_list"}).find_all('li')
            bsobj.decompose()
            linklist = []
            if cnt:
                for item in cnt:
                    link = "http://www.nhc.gov.cn" + item.a["href"];
                    linklist.append(link)
                    # yield link
            cnt = None
            gc.collect()
            return linklist
        except Exception as e:
            gc.collect()
            return "fail!"
    #获取标题的url-每日热点功能
    #input：html 卫健委主页面的html文件
    #output：answerdic 卫健委官网新闻的标题及其链接字典
    def getTitleUrl(self, html):
        try:
            bsobj = BeautifulSoup(html, 'html.parser')
            cnt = bsobj.find('div', attrs={"class": "yqdt"}).find_all('li')
            bsobj.decompose()
            answerdic = {}
            if cnt:
                for item in cnt:
                    link = "http://www.nhc.gov.cn" + item.a["href"];
                    answerdic[item.a["title"]] = link

                    # yield link
            cnt = None
            gc.collect()
            return answerdic
        except Exception as e:
            gc.collect()
            return "fail!"
    #爬取一页的内容
    #input：s 卫健委疫情通报选择页面html文件
    #col 指定写入excel文件的起始列
    def getpagecon(self, s, col):

        print("this is getpagecon--------")
        time.sleep(random.randint(2, 4))
        print(s)
        col = col
        col1 = col + 2
        col2 = col1 + 2
        #爬取每个链接内容并写入excel文件
        for link in self.getUrl(s):
            a = self.urllib_geturl(link)
            con = self.getContent(a)
            #若返回失败则重新爬取
            while con == "fail!":
                time.sleep(random.randint(2, 4))
                a = self.urllib_geturl(link)
                con = self.getContent(a)
                print(con)
                a = None
                gc.collect()
            if self.stop == 1:
                break
            hand().handle_content(con, col, col1, col2)
            #  print(link)
            col = col2 + 2
            col1 = col + 2
            col2 = col1 + 2

            time.sleep(random.randint(2, 4))
            con = None
            gc.collect()

        return int(col)
    #爬虫停止函数
    def stop(self):
        stop = 1
    #爬取单页面- 每日热点功能
    #input：url 输入url地址
    #output：redic返回新闻标题及链接字典
    def get_onepage_hot(self, url):
        s = self.urllib_geturl(url)
        redic = self.getTitleUrl(s)
        print("this is get_onepage_hot")
        while (redic == "fail!"):
            time.sleep(random.randint(1, 3))
            s = self.urllib_geturl(url)
            redic = self.getTitleUrl(s)
        for key in redic:
            print(key)
            print(redic[key])
        return redic
    #爬虫主函数
    def run(self):
        gc.enable()
        #爬取第一个页面
        s = self.urllib_geturl(self.url)
        print("main------")
        linklist = self.geturlContent(s)
        while (linklist == "fail!"):
            time.sleep(random.randint(1, 3))
            s = self.urllib_geturl(self.url)
            linklist = self.geturlContent(s)

            print("repeat--------------------")
        #指定下一个页面值，以及写入excel文件的起始列
        i = 36
        col = 4891
        time.sleep(2)
        coreturn = self.getpagecon(s, col)

        s = None
        linklist = None
        gc.collect()
        #根据疫情通报页面规律循环爬取页面，从而爬取所有内容
        while (i <= 41):
            if self.stop == 1:
                break
            newurl = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_' + str(i) + '.shtml'
            page = self.urllib_geturl(newurl)
            linklist = self.geturlContent(page)

            while (linklist == "fail!"):
                time.sleep(random.randint(1, 3))
                page = self.urllib_geturl(newurl)
                linklist = self.geturlContent(page)

                print("repeat--------------------")
            coreturn = self.getpagecon(page, coreturn)
            print(newurl)
            i = i + 1
            time.sleep(random.randint(2, 4))
            page = None
            linklist = None
            gc.collect()
        gc.disable()





