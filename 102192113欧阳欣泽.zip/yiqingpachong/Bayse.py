# 导入相关模块
import numpy as np
from collections import Counter
import matplotlib.pyplot as plt
from sklearn.utils import shuffle
import pandas as pd
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

#贝叶斯分类器
class Bayes:
    #读取excel文件返回数据
    #input： filename文件名
    #output:data文件数据
    def read(self, filename):
        data = pd.read_excel(filename)
        return data

    #训练并给输入样本分类赋值，返回分类结果
    #input:test_example 测试样本
    #indata训练数据
    #output:result 测试样本分类结果
    def train(self, test_example, indata):
        data = indata
        label_need = data.keys()
        title = data[label_need].values[:, 0]
        title_label = data[label_need].values[0:, 1]
        print(len(title))
        titlelist = []
        title_labellist = []
        for r in title:
            titlelist.append(r)
        for r in title_label:
            title_labellist.append(r)

        #拆分训练集测试集
        x_train, x_test, y_train, y_test = train_test_split(titlelist, title_labellist, test_size=0.25, random_state=33)
        count = CountVectorizer()
        x_train = count.fit_transform(x_train)
        x_test = count.transform(x_test)
        classifier = MultinomialNB()
        model = classifier.fit(x_train, y_train)
        y_predect = model.predict(x_test)

        #输出训练结果
        print("the accuracy of is ", model.score(x_test, y_test))

        test_example_test = count.transform([test_example])
        #预测输入测试样本结果
        result = model.predict(test_example_test)
        return result

