# 计算年龄

from dateutil.relativedelta import relativedelta as rd
# 获取时间、格式化时间
from datetime import datetime
# 用来延迟
import time
# 用来生成网页
from pywebio.input import *
from pywebio.output import *
from ChineseMap import ChineseMap
from LineCharts import LineCharts
from Spider import Spider
from Bayse import Bayes
from threading import Thread
import re
import threading
import inspect







class Hot_Thread(threading.Thread):
    def __init__(self, url):
        threading.Thread.__init__(self)
        self.url = url
    def add_html(self, url, title):
        put_html("<p align=""left"">"
                     "<h4>"+title + url +"</h4></p>")
        print(url)
    # 重写run()方法
    def run(self):
        spider = Spider()
        put_loading(shape='border', color='dark')
        print("每日热点线程创建!!查询每日热点")
        #获取新闻标题及链接
        dic = spider.get_onepage_hot(self.url)
        #输入分类器判断类别
        bayse = Bayes()
        data = bayse.read('Bayes_data.xlsx')
        put_html("<p align=""left"">"
                 "<h4>每日热点新闻及链接</h4></p>")
        #页面输出
        for key in dic.keys():
            ishot = bayse.train(key, data)
            if ishot == 1:
                self.add_html(dic[key], key)


class WebIO:
    sign = 0
    find_sign = 0
    hot_sign = 0
    #生成地图输出
    def generate_map(self, year, month, choose):
        x = ChineseMap()
        y = LineCharts()
        clear()
        put_loading(shape='border', color='dark')
        put_html(x.ltimeline(year, month, choose))
        put_html(y.get_liecharts(year, month, choose))

    #返回函数
    def back(self):
        self.sign = 1

    #爬虫线程
    def Spider_run(self, spider):
        clear()
        if self.find_sign == 0:
            self.find_sign = 1
            mythread = threading.Thread(target=spider.run())
            mythread.start()
    #每日热点线程
    def Spider_hot(self, spider):
        clear()
        mythread = Hot_Thread("http://www.nhc.gov.cn/")
        mythread.start()


    def run(self):
        spider = Spider()
        while True:
            clear()  # 每次循环先清空所有数据
            self.sign = 0

            # 标题
            put_html("<p align=""left"">"
                     "<h4>软工第一次作业</h4></p>")

            put_buttons(['爬虫'], onclick=lambda _: self.Spider_run(spider))
            put_buttons(['每日热点'], onclick=lambda _: self.Spider_hot(spider))
            user = input_group("疫情查询", [
                input("请输入查询疫情月份(年月，格式为 yyyy-mm-dd 年月-dd为选择 1 大陆新增确诊 2大陆新增无症状 3港澳台累计确诊)", name="day", lplaceholder="年月，格式为 yyyy-mm-dd 年月-dd为选择 1 大陆新增确诊 2大陆新增无症状 3港澳台累计确诊"),
            ])

            input_answer = user["day"]
            try:
                val = datetime.strptime(input_answer, "%Y-%m-%d")
            except:
                # 如果格式错误，警告提示
                put_error("警告：日期格式不正确")
                time.sleep(3)
                continue
            answer = re.split("-", input_answer)
            year = answer[0]
            month = answer[1]
            choose = int(answer[2])
            if choose > 3 or choose <= 0:
                put_error("警告：日期格式不正确")
                time.sleep(3)
                continue
            print(choose)
            print(year)

            self.generate_map(year, month, choose)
            put_buttons(['返回'], onclick=lambda _: self.back())
            #阻塞直到返回按钮按下
            while self.sign == 0:
                time.sleep(1)

            clear()


