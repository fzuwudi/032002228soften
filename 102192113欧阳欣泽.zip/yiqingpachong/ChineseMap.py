import pandas as pd  # 读取excel
from pyecharts import options as opts  # 可视化选项
from pyecharts.charts import Timeline, Map, Line  # 时间线、地图
from pyecharts.globals import ThemeType, CurrentConfig, NotebookType  # 图表主题


class ChineseMap:
    # 获取指定年月日的列名
    # input：day 具体时间到日 ****年*月*日 choose：1-大陆新增确诊 2-大陆新增无症状 3-港澳台累计
    # output： titlelist 列名list
    def get_daytitle_list(self, day, choose):
        titlelist = []
        if choose == 1:
            titlelist.append(day + "省份")
            titlelist.append(day + "新增确诊病例")
        if choose == 2:
            titlelist.append(day + "省份*")
            titlelist.append(day + "新增无症状病例")
        if choose == 3:
            titlelist.append(day + "港澳台地区")
            titlelist.append(day + "累计病例")
        return titlelist

    # 获取指定年月日的列名
    # input：year 年 month 月 day 日 choose：1-大陆新增确诊 2-大陆新增无症状 3-港澳台累计
    # output： titlelist 列名list
    def get_daylist(self, year, month, day, choose):
        provinces = ["初始"]
        confirm_value = [0]
        try:

            time = str(year) + "年" + str(month) + "月" + str(day) + "日"
            titelist = self.get_daytitle_list(time, choose)
            dic = self.read_file("yiqing.xlsx", "mysheet", titelist, choose)
            for item_pv in dic:
                provinces.append(item_pv)
                confirm_value.append(dic[item_pv])
            zipped = zip(provinces, confirm_value)
            return zipped
        except ValueError as e:
            return zip(provinces, confirm_value)
    #获取指定年月名称
    #input：year 年 month 月 choose：1-大陆新增确诊 2-大陆新增无症状 3-港澳台累计
    #output： titlelist 列名list
    def get_mtitle_sername(self, year, month, choose):
        titlelist = []
        day = str(year) + "年" + str(month) + "月"
        if choose == 1:
            titlelist.append("新增确诊")
            titlelist.append(day + "全国新增确诊疫情地图")
        if choose == 2:
            titlelist.append("新增无症状病例")
            titlelist.append(day + "全国新增无症状地图")
        if choose == 3:
            titlelist.append("累计确诊")
            titlelist.append(day + "港澳台累计确诊地图")
        return titlelist
    #读取文件返回省份数据
    #input： filename 文件名，sheetname 页名， titlelist 列名list， sp为3时返回港澳台数据其他值返回大陆数据
    #output： pro_dic 省份数据字典
    def read_file(self, filename, sheetname, titlelist, sp):
        data = pd.read_excel(filename, sheet_name=sheetname, usecols=titlelist)
        print(titlelist)
        data[titlelist[1]] = data[titlelist[1]].astype(str).str[0:10]
        label_need = data.keys()
        province = data[label_need[0]].values
        pro_data = data[label_need[1]].values
        splist = ["香港", "澳门", "台湾"]
        # prokeys = self.province
        index = 0
        pro_dic = {}
        #sp3时添加港澳台数据
        if sp == 3:
            while (index < 3):
                pro_dic.update({splist[index]: pro_data[index]})
                index = index + 1
        # 否则添加大陆数据
        else:
            while index < 33:
                pro_dic.update({province[index]: pro_data[index]})
                index = index + 1
        return pro_dic

    #生成单月的疫情地图情况
    #input：year 年 month 月 choose：1-大陆新增确诊 2-大陆新增无症状 3-港澳台累计
    #output：tl.render_notebook() 地图html文件
    def ltimeline(self, year, month, choose) -> Timeline:
        tl = Timeline(init_opts=opts.InitOpts(page_title="疫情地图",
                                              theme=ThemeType.CHALK,
                                              width="900px",  # 图像宽度
                                              height="700px"),
                      )
        for idx in range(0, 31):
            provinces = []
            confirm_value = []
            namelist = self.get_mtitle_sername(year, month, choose)
            zipped = self.get_daylist(year, month, idx + 1, choose)  # 组合两个字段
            print(zipped)
            f_map = (
                Map(init_opts=opts.InitOpts(width="900px",
                                            height="700px",
                                            page_title="疫情地图",
                                            bg_color=None))
                .add(series_name=namelist[0],
                     data_pair=[list(z) for z in zipped],
                     maptype="china",
                     is_map_symbol_show=False)
                .set_global_opts(
                    # 设置标题
                    title_opts=opts.TitleOpts(title=namelist[1],
                                              subtitle=str(month) + "月{}日-当天数据\n"
                                                                    "......".format(idx + 1),
                                              pos_left="center", ),
                    # 设置图例
                    legend_opts=opts.LegendOpts(
                        is_show=True, pos_top="10%", pos_right="10%"),
                    # 设置视觉映射
                    visualmap_opts=opts.VisualMapOpts(
                        is_piecewise=True, range_text=['高', '低'], pieces=[  # 分段显示
                            {"min": 10000, "color": "#642100"},
                            {"min": 1000, "max": 9999, "color": "#a23400"},
                            {"min": 500, "max": 999, "color": "#bb5e00"},
                            {"min": 100, "max": 499, "color": "#ff8000"},
                            {"min": 10, "max": 99, "color": "#ffaf60"},
                            {"min": 1, "max": 9, "color": "#ffd1a4"},
                            {"min": 0, "max": 0, "color": "#fffaf4"}
                        ]),
                )
                .set_series_opts(label_opts=opts.LabelOpts(is_show=True),
                                 markpoint_opts=opts.MarkPointOpts(
                                     symbol_size=[90, 90], symbol='circle'),
                                 effect_opts=opts.EffectOpts(is_show='True', )
                                 )
            )
            tl.add(f_map, "{}日".format(idx + 1))
            tl.add_schema(is_timeline_show=True,  # 是否显示
                          play_interval=1000,  # 播放间隔
                          symbol=None,  # 图标
                          is_loop_play=True  # 循环播放
                          )
        return tl.render_notebook()




