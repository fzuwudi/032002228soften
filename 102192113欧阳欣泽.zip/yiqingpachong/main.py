from Web import WebIO

if __name__ == '__main__':
    WebIO().run()
