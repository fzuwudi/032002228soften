from wsgiref import headers
import requests  # 第三方模块(发送请求)
import re  # 正则
import json
import csv

url = 'https://voice.baidu.com/act/newpneumonia/newpneumonia/?from=osari_aladin_banner'
headers = {'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.89 Safari/537.36 SLBrowser/7.0.0.12151 SLBChan/30'}
response = requests.get(url=url, headers=headers)
data_html = response.text
json_str = re.findall('"component":\[(.*)\],', data_html)[0]
json_dict = json.loads(json_str)
caseList = json_dict['caseList']
for case in caseList:
    area = case['area']  # 省份
    curConfirm = case['curConfirm']  # 确诊人数
    confirmedRelative = case['confirmedRelative']  # 新增人数
    confirmed = case['confirmed']  # 累计确诊
    crued = case['crued']  # 累计治愈
    died = case['died']  # 累计死亡
    print(area, curConfirm, confirmedRelative, confirmed, crued, died)
with open('data.csv', mode='a', encoding='utf-8', newline='') as f:
    csv_writer = csv.writer(f)
