
from pyecharts import options as opts
from pyecharts.charts import Map
import pandas as pd
df = pd.read_csv('data.csv', encoding='utf-8')
china_map = (
    Map()
    .add("现有确诊", [list(i) for i in zip(df['area'].values.tolist(),df['curConfirm'].values.tolist())], "china")
    .set_global_opts(
        title_opts=opts.TitleOpts(title="各地区确诊人数"),
        visualmap_opts=opts.VisualMapOpts(max_=200, is_piecewise=True),
    )
)
china_map.render_notebook()

line = (
    Line()
    .add_xaxis(list(df['province'].values))
    .add_yaxis("治愈率", df['healRate'].values.tolist())
    .add_yaxis("死亡率", df['deadRate'].values.tolist())
    .set_global_opts(
        title_opts=opts.TitleOpts(title="死亡率与治愈率"),

    )
)
line.render_notebook()
bar = (
    Bar()
    .add_xaxis(list(df['province'].values)[:6])
    .add_yaxis("死亡", df['dead'].values.tolist()[:6])
    .add_yaxis("治愈", df['heal'].values.tolist()[:6])
    .set_global_opts(
        title_opts=opts.TitleOpts(title="各地区确诊人数与死亡人数情况"),
        datazoom_opts=[opts.DataZoomOpts()],
        )
)
bar.render_notebook()

cofirm, currentCofirm, cured, dead = [], [], [], []

tab = Tab()

_map = (
    Map(init_opts=opts.InitOpts(theme='dark', width='1000px'))
    .add("累计确诊人数", [list(i) for i in zip(df['area'].values.tolist(),df['confirmed'].values.tolist())], "china", is_map_symbol_show=False,  is_roam=False)
    .set_series_opts(label_opts=opts.LabelOpts(is_show=True))
    .set_global_opts(
        title_opts=opts.TitleOpts(title="新型冠状病毒全国疫情地图",
                                  ),
        legend_opts=opts.LegendOpts(is_show=False),
        visualmap_opts=opts.VisualMapOpts(is_show=True, max_=1000,
                                          is_piecewise=False,
                                          range_color=['#FFFFE0', '#FFA07A', '#CD5C5C', '#8B0000'])
    )
)
tab.add(_map, '累计确诊')

_map = (
    Map(init_opts=opts.InitOpts(theme='dark', width='1000px'))
    .add("当前确诊人数", [list(i) for i in zip(df['area'].values.tolist(),df['curConfirm'].values.tolist())], "china", is_map_symbol_show=False,  is_roam=False)
    .set_series_opts(label_opts=opts.LabelOpts(is_show=True))
    .set_global_opts(
        title_opts=opts.TitleOpts(title="新型冠状病毒全国疫情地图",
                                  ),
        legend_opts=opts.LegendOpts(is_show=False),
        visualmap_opts=opts.VisualMapOpts(is_show=True, max_=100,
                                          is_piecewise=False,
                                          range_color=['#FFFFE0', '#FFA07A', '#CD5C5C', '#8B0000'])
    )
)
tab.add(_map, '当前确诊')

_map = (
    Map(init_opts=opts.InitOpts(theme='dark', width='1000px'))
    .add("治愈人数", [list(i) for i in zip(df['area'].values.tolist(),df['crued'].values.tolist())], "china", is_map_symbol_show=False,  is_roam=False)
    .set_series_opts(label_opts=opts.LabelOpts(is_show=True))
    .set_global_opts(
        title_opts=opts.TitleOpts(title="新型冠状病毒全国疫情地图",
                                  ),
        legend_opts=opts.LegendOpts(is_show=False),
        visualmap_opts=opts.VisualMapOpts(is_show=True, max_=1000,
                                          is_piecewise=False,
                                          range_color=['#FFFFE0', 'green'])
    )
)
tab.add(_map, '治愈')

_map = (
    Map(init_opts=opts.InitOpts(theme='dark', width='1000px'))
    .add("死亡人数", [list(i) for i in zip(df['area'].values.tolist(),df['died'].values.tolist())], "china", is_map_symbol_show=False,  is_roam=False)
    .set_series_opts(label_opts=opts.LabelOpts(is_show=True))
    .set_global_opts(
        title_opts=opts.TitleOpts(title="新型冠状病毒全国疫情地图",
                                  ),
        legend_opts=opts.LegendOpts(is_show=False),
        visualmap_opts=opts.VisualMapOpts(is_show=True, max_=50,
                                          is_piecewise=False,
                                          range_color=['#FFFFE0', '#FFA07A', '#CD5C5C', '#8B0000'])
    )
)
tab.add(_map, '死亡')

tab.render_notebook()

