from bs4 import BeautifulSoup
import re
from tqdm import tqdm
import xlwt
import requests

# 代理ip的账号密码（不过流量快用完了)
orderId = "O22091223380673948494"
pwd = "jI1z0Ejw"
host = "flow.hailiangip.com"
port = "14223"
user = orderId
password = 'pwd='+pwd+"&pid=22"+"&cid=258"+"&uid="+"&sip=0"+"&nd=0"
targetUrl = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd"
# a作为全局变量分别控制写入excel的新增新冠疫情和新增无症状患者的行数,b作为每日热点标志连续b天本土每日新增确诊患者和无症状患者人数在100人以下（不包括港澳台）
# c,d为上一日的本土新增确诊人数和新增无症状感染者人数,e,f,g为前一日港澳台累积确诊人数
global a, b, c, d, e, f, g, flag
a = 1
b = 0
c = 0
d = 0
e = 0
f = 0
g = 0
flag = 0


def excel(book, sheet1, city_list1, city_list2, doc_3, doc_1):
    global a , b, c, d, e, f, g, flag
    # 写入  日期
    # 写入新增新冠患者省份及其对应的人数，新增无症状患者省份及其对应的人数
    for i in range(len(city_list1)):
        sheet1.write(a, 0, doc_3[0])
        sheet1.write(a, 1, list(city_list1.keys())[i])
        sheet1.write(a, 2, list(city_list1.values())[i])
        sheet1.write(a, 3, list(city_list2.keys())[i])
        sheet1.write(a, 4, list(city_list2.values())[i])
        a = a + 1
    # 港澳台每日新增人数为当日减去昨日的累积确诊人数
    if flag != 0:
        sheet1.write(a-40, 2, e - list(city_list1.values())[33])
        sheet1.write(a-39, 2, f - list(city_list1.values())[34])
        sheet1.write(a-38, 2, g - list(city_list1.values())[35])
    # 使得每天留一行为空
    a = a + 1
    # 写每日热点内容
    sheet1.write(a-6, 6, '每日热点')
    if list(city_list1.values())[0] + list(city_list2.values())[1] < 100:
        b = b + 1
    else:
        b = 0
    if b >= 7:
        sheet1.write(a-5, 6, '疫情已经快将离去，疫情的曙光就在眼前')
    else:
        sheet1.write(a-5, 6, '疫情尚未结束，防控不能松懈')
    # 最高本土新增确诊人数若小于30，则有
    if list(city_list1.values())[0] < 30 and list(city_list2.values())[1] < 100:
        sheet1.write(a-4, 6, '各个省份均未爆发疫情，值得祝贺')
    if list(city_list1.values())[0] > c*2 or list(city_list2.values())[1] > d*2 and flag != 0:
        sheet1.write(a-3, 6, '大家小心，疫情突然急剧恶化')
    c = list(city_list1.values())[0]
    d = list(city_list2.values())[1]
    e = list(city_list1.values())[33]
    f = list(city_list1.values())[34]
    g = list(city_list1.values())[35]
    flag = flag+1
    # 保存测试表
    if list(city_list1.values())[0] > c*5 and list(city_list2.values())[1] > d*2 and flag != 0:
        sheet1.write(a-2, 6, '疫情十分严重请大家注意')
    book.save('COVID.xls')


# 提取出存有计中国大陆每日本土新增确诊人数及新增无症状感染人数、所有省份包括港澳台每日本土新增确诊人数及新增无症状感染人数
# noinspection RegExpDuplicateCharacterInClass
def keyword(tex, book, sheet1):
    city = [
        '本土病例', '本土', '河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北',
        '湖南', '广东', '海南', '四川', '贵州',
        '云南', '陕西', '甘肃', '青海', '内蒙古', '广西', '西藏', '宁夏', '新疆', '北京', '天津', '上海', '重庆',
        '香港特别行政区', '澳门特别行政区', '台湾地区'
    ]
    city_list1 = dict.fromkeys(city, 0)
    city_list2 = dict.fromkeys(city, 0)
# 利用正则式提炼有效内容
    # 解决2021年11月18号前的新增本土新冠患者
    parttern7 = re.compile('本土病例\d*例.*')
    # 解决2022年前4月10号的无症状
    parttern6 = re.compile('本土\d*例[（].*[）].*当日转')
    # 捕获本土新增新冠患者
    parttern = re.compile('本土病例\d*例.*含')
    # 捕获本土新增无症状新冠患者
    parttern2 = re.compile('本土\d*例[（].*[）]。\n当日')
    # 捕获日期
    parttern3 = re.compile('\d+月\d+日')
    parttern4 = re.compile("([^x00-xff^市^区^；^（^，]{2,4})(\d*)(例)")
    # 捕获港澳台患者
    parttern5 = re.compile('累计收到港澳台地区通报确诊病例\d*例。其中，(香港特别行政区)(\d*)(例)')
    parttern8 = re.compile('.*(澳门特别行政区)(\d*)(例)')
    parttern9 = re.compile('.*(台湾地区)(\d*)(例)')
    doc_data = parttern3.findall(tex)
    if a < 11320:
        doc = parttern.findall(tex)
    else:
        doc = parttern7.findall(tex)
# 使字典连接成字符串，否则接下来无法再次用正则式
    doc = ''.join(doc)
    doc_1 = parttern4.findall(doc)
    for i in doc_1:
        if i[0] in city_list1.keys():
            city_list1[i[0]] = int(i[1])
    if a < 5980:
        doc2 = parttern2.findall(tex)
    else:
        doc2 = parttern6.findall(tex)
    doc2 = ''.join(doc2)
    doc_2 = parttern4.findall(doc2)
    for i in doc_2:
        if i[0] in city_list2.keys():
            city_list2[i[0]] = int(i[1])
    doc_3 = parttern5.findall(tex)#港澳台
    doc_4 = parttern8.findall((tex))
    doc_5 = parttern9.findall(tex)
# 将港澳台的字典信息导入到列表中
    if len(doc_3) != 0 and doc_3[0][0] in city_list1.keys():
        city_list1[doc_3[0][0]]=int(doc_3[0][1])
    if len(doc_4) != 0 and doc_4[0][0] in city_list1.keys():
        city_list1[doc_4[0][0]] = int(doc_4[0][1])
    if len(doc_5) != 0 and doc_5[0][0] in city_list1.keys():
        city_list1[doc_5[0][0]] = int(doc_5[0][1])
    # 日期
    doc_6 = parttern3.findall(tex)
    # 将所得列表送入写入excel函数中
    excel(book, sheet1, city_list1, city_list2, doc_6, doc_1)

# 申请url
def request_html(url):
    proxyUrl = "http://" + user + ":" + password + "@" + host + ":" + port
    proxy = {"http": proxyUrl, "https": proxyUrl}
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.140 Safari/537.36 Edge/18.17763'}
    # 多尝试几次避免得不到数据
    trytimes = 1000000
    for i in range(1, trytimes+1):
        try:
            request = requests.get(url=url, headers=headers, proxies=proxy, verify=False, timeout=3)
            print(request)
            # 说明成功申请
            if request.status_code == 200:
                break
        except:
            print(f'requests faild {i} time')
    return request


def parse_html(html, book, sheet1):
    # 用正则得到每个日期具体数据的URL
    pattern = re.compile('<a[^>]href="([^>]*l?)"\starget[^>]', re.I)
    href = pattern.findall(html)
    href_ = ["http://www.nhc.gov.cn/" + str(i) for i in href]
    # 查看打印下的是否均为每日通报的连接
    print(href_)
    for href in tqdm(href_, '采集数据'):
        # 先发送请求
        request = request_html(href)
        # 解析
        contect = request.content.decode()
        soup = BeautifulSoup(contect, 'lxml')
        # 将内容缩减
        script = soup.find(id='xw_box')
        tex = script.text
        # 准备提炼信息
        keyword(tex, book, sheet1)


# 处理除了第一面的其他面
def other_page(book, sheet1):
    # 除去第一面一共有41面,循环40次
    for number in tqdm(range(40)):
        number = number+2
        url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_'+str(number)+'.shtml'
        request = request_html(url)
        text = request.text
        parse_html(text, book, sheet1)


def run():
    # 创建excel和sheet表并绘制主要格式
    book = xlwt.Workbook(encoding='utf-8')
    sheet1 = book.add_sheet(u'sheet1', cell_overwrite_ok=True)
    sheet1.write(0, 0, '日期')
    sheet1.write(0, 1, '省份')
    sheet1.write(0, 2, '新冠患者新增人数')
    sheet1.write(0, 3, '省份')
    sheet1.write(0, 4, '无症状新冠新增患者人数')
    sheet1.write(0, 6, '本土病例是指大陆省份新增患者新增人数之和')
    sheet1.write(1, 6, '本土是指大陆省份新增无症状新冠患者人数之和')
    url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd'
# 先得到请求许可，然后得到html.text，然后解析html.text文
    request = request_html(url)
    text = request.text
    parse_html(text, book, sheet1)
    other_page(book, sheet1)

if __name__ == '__main__':
    run()
