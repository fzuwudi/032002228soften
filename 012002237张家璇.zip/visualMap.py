from pyecharts.charts import Map
from pyecharts.options import*
def dict_to_tuple(dict_total, str_type):
    visual_tuple_list = list()
    for i in range(0, 31):
        name_tmp = dict_total["数据表"][-1]["数据"][i]["name"]
        num_tmp = dict_total["数据表"][-1]["数据"][i]["news"][str_type]
        visual_tuple_list.append((name_tmp, num_tmp))

    return visual_tuple_list

def visual_map(dict_total, num_total):
    visual_tuple_list_confirm = dict_to_tuple(dict_total, "新增确诊")
    visual_tuple_list_asymptom = dict_to_tuple(dict_total, "新增无症状")
    map_confirm = Map()
    map_asymptom = Map()
    map_confirm.add("今日新增确诊", visual_tuple_list_confirm, "china")
    map_asymptom.add("今日新增无症状", visual_tuple_list_asymptom, "china")

    map_confirm.set_global_opts(
        title_opts=TitleOpts(
            title="今日新增确诊病例",
            subtitle="数据来源：卫健委"
        ),
        visualmap_opts=VisualMapOpts(max_=num_total[-1][0])
    )
    map_asymptom.set_global_opts(
        title_opts=TitleOpts(
            title="今日新增无症状感染者",
            subtitle="数据来源：卫健委"
        ),
        visualmap_opts=VisualMapOpts(
            is_show=True,
            is_piecewise=True,
            pieces=[
                {"min": 1, "max": 10, "label": "1-10人", "color": "#63EEEC"},
                {"min": 11, "max": 30, "label": "11-30人", "color": "#26D97B"},
                {"min": 31, "max": 100, "label": "31-100人", "color": "#C7D926"},
                {"min": 101, "max": 500, "label": "101-500人", "color": "#d96F26"},
                {"min": 500, "label": "500人以上", "color": "#DE1B24"}
            ]
        )
    )
    map_confirm.render("最新一天新增确诊病例.html")
    map_asymptom.render("最新一天新增无症状感染者.html")
