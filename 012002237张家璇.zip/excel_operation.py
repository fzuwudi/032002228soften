import xlrd
from xlutils.copy import copy

p0 = "国家/省份"
p1 = "新增确诊人数"
p2 = "新增无症状感染人数"
p3 = "累计确诊人数"
p4 = "累计无症状感染人数"


def init_sheet(table):
    table.write(0, 0, p0)
    table.write(0, 1, p1)
    table.write(0, 2, p2)
    table.write(0, 3, p3)
    table.write(0, 4, p4)

def excel_write(dict_total, num_total):
    a = 0
    for dictionary in dict_total["数据表"]:
        old_book = xlrd.open_workbook("pandemic1.xls")
        book = copy(old_book)
        table = book.add_sheet(dictionary["日期"], cell_overwrite_ok= True)
        init_sheet(table)   # 初始化工作表，设置标题

        index = book.sheet_index(dictionary["日期"])
        print(index)

        table.write(1, 0, "全国")
        table.write(1, 1, num_total[a][1])
        table.write(1, 2, num_total[a][3])

        if index == 1:
            table.write(1, 3, num_total[a][1])
            table.write(1, 4, num_total[a][3])
        elif index > 1:
            sheet_tmp_all = old_book.sheet_by_index(index - 1)
            rd1_all = sheet_tmp_all.cell(1, 3).value
            rd2_all = sheet_tmp_all.cell(1, 4).value
            table.write(1, 3, rd1_all + num_total[a][1])
            table.write(1, 4, rd2_all + num_total[a][3])
        a += 1

        for i in range(0, 32):   # 遍历每个省份的数据
            table.write(i + 2, 0, dictionary["数据"][i]["name"])
            table.write(i + 2, 1, dictionary["数据"][i]["news"]["新增确诊"])

            if i < 31:
                table.write(i + 2, 2, dictionary["数据"][i]["news"]["新增无症状"])
            else:
                table.write(i + 2, 2, "无数据")
            if index == 1:
                table.write(i + 2, 3, dictionary["数据"][i]["news"]["新增确诊"])
                if i < 31:
                    table.write(i + 2, 4, dictionary["数据"][i]["news"]["新增无症状"])
                else:
                    table.write(i + 2, 4, "无数据")
            elif index > 1:
                sheet_tmp = old_book.sheet_by_index(index - 1)
                rd1 = sheet_tmp.cell(i + 2, 3).value
                table.write(i + 2, 3, (dictionary["数据"][i]["news"]["新增确诊"] + rd1))   # 递推法计算累计确诊数量
                if i < 31:
                    rd2 = sheet_tmp.cell(i + 2, 4).value
                    table.write(i + 2, 4, (dictionary["数据"][i]["news"]["新增无症状"] + rd2))   # 递推法计算累计无症状数量
                else:
                    table.write(i + 2, 4, "无数据")
        book.save("pandemic1.xls")

# book = xlwt.Workbook(encoding = 'utf-8')

def get_hotspot(dict_total):
    old_book = xlrd.open_workbook("hot_spot.xls")
    book = copy(old_book)

    list_yesterday = list()   # 保存第一天的数据
    list_today = list()
    b = 3
    for i in range(0, 32):
        list_yesterday.append(dict_total["数据表"][0]["数据"][i]["news"]["新增确诊"])
    for dictionary in dict_total["数据表"]:
        table = book.add_sheet(dictionary["日期"], cell_overwrite_ok=True)
        table.write(0, 0, "省份")
        table.write(0, 1, "今日热点")
        for i in range(0, 32):
            list_today.append(dictionary["数据"][i]["news"]["新增确诊"])
            table.write(i + 1, 0, dictionary["数据"][i]["name"])
            # 判断热点问题
            if list_yesterday[i] == 0 and list_today[i] > 0:
                table.write(i + 1, 1, "震惊！%s发生疫情" % dictionary["数据"][i]["name"])
            elif list_yesterday[i] > 0 and list_today[i] > 0 and list_today[i] > b * list_yesterday[i]:
                table.write(i + 1, 1, "严峻！%s疫情确诊人数持续增加！" % dictionary["数据"][i]["name"])
            else:
                table.write(i + 1, 1,  "今天没啥可关注的")
        book.save("hot_spot.xls")

        list_yesterday.clear()
        for i in range(0, 32):
            list_yesterday.append(list_today[i])
        list_today.clear()

# 测试
if __name__ == "__main__":
    old_book = xlrd.open_workbook("pandemic.xls")
    book = copy(old_book)
    table = book.add_sheet("Test", cell_overwrite_ok= True)
    init_sheet(table)
    table.write(0, 0, "This is a test.")
    book.save("pandemic.xls")
