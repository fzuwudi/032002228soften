from crawl_data import *
from read_crawl import *
from regex_operation import *
from excel_operation import *
from visualMap import *
from visual_gridMap import *

# cols = crawl_all('http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml')   # 爬取卫健委网站数据，并存入一个excel。cols为天数
# 爬取的数据已存入"crawl_data.xls"，共968页，故此时不执行crawl_all()。crawl_all()函数在crawl_data.py中
# read_crawls(cols)
read_crawls(968)   # 将存储每一天疫情通告字符串的excel里的数据读出
dict_total = regex(time_list, text_list)   # 正则表达式处理存入字典
# excel_write(dict_total, num_total)   # 将处理过的数据存入excel中。数据已存入"pandemic.xls"
# get_hotspot(dict_total)  # 获得每日热点信息。数据已存入"hot_spot.xls"
visual_map(dict_total, num_total)   # 实现最新一天新增确诊和新增无症状的可视化
visualDynamic(dict_total, num_total)   # 实现动态可视化大屏