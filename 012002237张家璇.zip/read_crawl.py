import xlrd

text_list = list()   # 存储每一天的通报内容字符串
time_list = list()   # 存储每一天的日期，其索引值与text_list一一对应

def read_crawls(cols):
    book = xlrd.open_workbook("save_crawl.xls")
    table_content = book.sheet_by_index(0)
    table_time = book.sheet_by_index(1)
    for i in range(0, cols):
        text_list.insert(0, table_content.cell(int(i/255), i%255).value)
        time_list.insert(0, table_time.cell(int(i/255), i%255).value)
