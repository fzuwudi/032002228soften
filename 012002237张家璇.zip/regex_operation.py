import re

num_total = list()   # 初始化全国数据列表

patta = list()
patta.append("（.*?福建(\d+)例")
patta.append("（.*?浙江(\d+)例")
patta.append("（.*?江苏(\d+)例")
patta.append("（.*?广东(\d+)例")
patta.append("（.*?广西(\d+)例")
patta.append("（.*?江西(\d+)例")
patta.append("（.*?安徽(\d+)例")
patta.append("（.*?湖南(\d+)例")
patta.append("（.*?湖北(\d+)例")
patta.append("（.*?四川(\d+)例")
patta.append("（.*?陕西(\d+)例")
patta.append("（.*?河南(\d+)例")
patta.append("（.*?云南(\d+)例")
patta.append("（.*?贵州(\d+)例")
patta.append("（.*?青海(\d+)例")
patta.append("（.*?山东(\d+)例")
patta.append("（.*?山西(\d+)例")
patta.append("（.*?黑龙江(\d+)例")
patta.append("（.*?吉林(\d+)例")
patta.append("（.*?辽宁(\d+)例")
patta.append("（.*?内蒙古(\d+)例")
patta.append("（.*?宁夏(\d+)例")
patta.append("（.*?新疆(\d+)例")
patta.append("（.*?西藏(\d+)例")
patta.append("（.*?上海(\d+)例")
patta.append("（.*?北京(\d+)例")
patta.append("（.*?天津(\d+)例")
patta.append("（.*?重庆(\d+)例")
patta.append("（.*?海南(\d+)例")
patta.append("（.*?河北(\d+)例")
patta.append("（.*?甘肃(\d+)例")
patta.append("（.*?兵团(\d+)例")

pattc = list()
pattc.append(".*?福建.*?")
pattc.append(".*?浙江.*?")
pattc.append(".*?江苏.*?")
pattc.append(".*?广东.*?")
pattc.append(".*?广西.*?")
pattc.append(".*?江西.*?")
pattc.append(".*?安徽.*?")
pattc.append(".*?湖南.*?")
pattc.append(".*?湖北.*?")
pattc.append(".*?四川.*?")
pattc.append(".*?陕西.*?")
pattc.append(".*?河南.*?")
pattc.append(".*?云南.*?")
pattc.append(".*?贵州.*?")
pattc.append(".*?青海.*?")
pattc.append(".*?山东.*?")
pattc.append(".*?山西.*?")
pattc.append(".*?黑龙江.*?")
pattc.append(".*?吉林.*?")
pattc.append(".*?辽宁.*?")
pattc.append(".*?内蒙古.*?")
pattc.append(".*?宁夏.*?")
pattc.append(".*?新疆.*?")
pattc.append(".*?西藏.*?")
pattc.append(".*?上海.*?")
pattc.append(".*?北京.*?")
pattc.append(".*?天津.*?")
pattc.append(".*?重庆.*?")
pattc.append(".*?海南.*?")
pattc.append(".*?河北.*?")
pattc.append(".*?甘肃.*?")
pattc.append(".*?兵团.*?")

patt_province_num = list()
patt_province_name = list()
for k in range(0, 32):
    tmp1 = re.compile(patta[k])
    tmp2 = re.compile(pattc[k])
    patt_province_num.append(tmp1)
    patt_province_name.append(tmp2)

# 封装
def create_dict(time_list):   # 创建一个空的字典
    dict_total = dict()
    dict_total["时间表"] = time_list
    dict_total["数据表"] = list()

    return dict_total

def cope_asypmptom(text_list, prov_list, i):   # 处理无症状病例的函数
    patt_no_all = re.compile("新增无症状感染者(\d+)例")
    ls_no_all = patt_no_all.findall(text_list[i])
    if len(ls_no_all) > 0:
        num_total[i].append(int(ls_no_all[0]))
        # 新增本土无症状
        # 用no_para存储无症状段落的字符串
        patt_no_para = re.compile("新增无症状感染者.+?\n")
        no_para = patt_no_para.findall(text_list[i])[0]
        patt_no_overseas = re.compile("新增无症状感染者.+?境外输入")
        ls_no_overseas = patt_no_overseas.findall(no_para)
        if len(ls_no_overseas) > 0:
            patt_no_all_overseas = re.compile("均为境外输入")
            ls4_no_all_overseas = patt_no_all_overseas.findall(ls_no_overseas[0])

            if len(ls4_no_all_overseas) == 0:  # 存在本土病例
                patt_none_overseas = re.compile("无境外输入")
                ls3_no_overseas = patt_none_overseas.findall(ls_no_overseas[0])
                if len(ls3_no_overseas) > 0:
                    num_total[i].append(int(ls_no_all[0]))
                else:
                    patt_no_domestic = re.compile("新增无症状感染者.+?境外输入.*?(\d+)例")
                    numb = num_total[i][2] - int(patt_no_domestic.findall(no_para)[0])  # 本土 = 全国 - 境外输入
                    num_total[i].append(numb)
                # 统计各省份本土新增无症状
                patt_no_province = re.compile("新增无症状感染者.+?境外输入.*?本土.*?(（.+）)")
                no_province = patt_no_province.findall(no_para)
                if len(no_province) > 0:
                    # if len(re.findall("在.*?）", no_province[0])) > 0:   # “均在”还是“在”？
                    #     for j in range(0, 32):
                    #         ls_no_tmp = patt_province_name[j].findall(no_province[0])
                    #         if len(ls_no_tmp) > 0:
                    #             prov_list[j].append(numb)  # 全国新增确诊即为该省份新增确诊
                    #         else:
                    #             prov_list[j].append(0)
                    # else:
                    for j in range(0, 32):
                        prov_no_tmp = patt_province_num[j].findall(no_province[0])
                        if len(prov_no_tmp) == 0:
                            prov_list[j].append(0)
                        else:
                            prov_list[j].append(int(prov_no_tmp[0]))
                else:
                    for j in range(0, 32):
                        prov_list[j].append(0)
            else:
                num_total[i].append(0)
                for j in range(0, 32):
                    prov_list[j].append(0)
        else:
            num_total[i].append(0)
            for j in range(0, 32):
                prov_list[j].append(0)
    else:
        num_total[i].append(0)
        num_total[i].append(0)
        for j in range(0, 32):
            prov_list[j].append(0)

    return prov_list

def cope_confirm(text_list, prov_list, i):   # 处理确诊病例的函数
    patt_first_para = re.compile(".*?\n")
    # 存储第一段内容
    first_para = patt_first_para.findall(text_list[i])[0]
    patt_cf_all = re.compile("新增确诊病例(\d+)例")
    ls_cf_all = patt_cf_all.findall(first_para)
    if len(ls_cf_all) == 0:   # 全国无新增确诊病例
        num_total[i].append(0)
        num_total[i].append(0)
        for j in range(0, 32):
            prov_list[j].append(0)
    else:
        num_total[i].append(int(ls_cf_all[0]))

        # 新增本土确诊
        patt_cf_overseas = re.compile("新增确诊病例.+?均为境外输入.+?新增死亡病例")  # 判断是否均为境外输入
        ls_cf_overseas = patt_cf_overseas.findall(first_para)
        if len(ls_cf_overseas) == 0:  # 存在本土病例
            patt_cf_domestic1 = re.compile("新增确诊病例.+?本土病例(\d+)例")
            if len(patt_cf_domestic1.findall(first_para)) == 0:  # 格式二
                patt_cf_domestic2 = re.compile("新增确诊病例\d+?例.+?(\d+)例为境外输入病例")
                if len(patt_cf_domestic2.findall(first_para)) == 0:
                    patt_cf_domestic3 = re.compile("新增确诊病例\d+?例.+?(\d+)例为本土病例")
                    if len(patt_cf_domestic3.findall(first_para)) > 0:
                        numa = int(patt_cf_domestic3.findall(first_para)[0])
                    else:
                        numa = num_total[i][0]
                else:
                    numa = num_total[i][0] - int(patt_cf_domestic2.findall(first_para)[0])
            else:
                numa = int(patt_cf_domestic1.findall(first_para)[0])
            # pattc.append(".*?黑龙江.*?")
            # 用cf_province来存储本土新增确诊内容，用于找出省份数据
            patt_cf_province = re.compile("新增确诊病例.+?本土病例.*?(（.+?）)")
            cf_province_list = patt_cf_province.findall(first_para)
            if len(cf_province_list) > 0:
                cf_province = cf_province_list[0]
                # 检查是否集中在一个省份中
                # prov_all = re.findall("在.*", cf_province)
                # if len(prov_all) > 0:  # 集中在某一个省份
                #     for j in range(0, 32):
                #         ls_tmp = patt_province_name[j].findall(cf_province)
                #         if len(ls_tmp) > 0:
                #             prov_list[j].append(numa)  # 全国新增确诊即为该省份新增确诊
                #             for k in range(0, j):
                #                 prov_list[k].append(0)
                #             for k in range(j + 1, 32):  # 将其他省份数据置0
                #                 prov_list[k].append(0)
                #             break
                # else:
                for j in range(0, 32):  # 遍历各个省份/地区的数据，遍历参数j
                    prov_tmp = patt_province_num[j].findall(cf_province)
                    if len(prov_tmp) == 0:  # 未找到该省份的新增确诊
                        prov_list[j].append(0)
                    else:
                        prov_list[j].append(int(prov_tmp[0]))
            else:
                numa = num_total[i][0]
                patt_t = re.compile("新增确诊病例.*?(（.+\d*.*?例）)，.*重症病例")
                str_tlist = patt_t.findall(first_para)
                if len(str_tlist) > 0:
                    str_t = str_tlist[0]
                    patt_t_t = re.compile("湖北.*?(\d+)例")
                    num_hubei_list = patt_t_t.findall(str_t)
                    if len(num_hubei_list) > 0:
                        num_hubei = int(patt_t_t.findall(str_t)[0])
                        for j in range(0, 8):
                            prov_list[j].append(0)
                        prov_list[8].append(num_hubei)
                        for j in range(9, 32):
                            prov_list[j].append(0)
                    else:
                        for j in range(0, 32):
                            prov_list[j].append(0)
                else:
                    for j in range(0, 32):
                        prov_list[j].append(0)
        else:  # 均为境外输入
            numa = 0
            for j in range(0, 32):
                prov_list[j].append(0)
        num_total[i].append(numa)

    return prov_list

def cope_hk_mo_tw(text_list, i):
    patt_hk_mo_tw = re.compile("累计收到港澳台地区通报确诊病例(\d+)例")
    ls_hk_mo_tw = patt_hk_mo_tw.findall(text_list[i])
    if len(ls_hk_mo_tw) > 0:
        num_total[i].append(int(ls_hk_mo_tw[0]))
    else:
        if i == 0:
            num_total[i].append(10)
        elif i == 1:
            num_total[i].append(10)
        elif i == 2:
            num_total[i].append(17)
        elif i == 3:
            num_total[i].append(20)
        elif i == 4:
            num_total[i].append(23)
        elif i == 5:
            num_total[i].append(25)

def write_dict(time_list, prov_list, dict_total, i):
    dictionary = dict()
    dictionary["日期"] = time_list[i]  # 读入时间字符串
    dictionary["数据"] = list()
    for j in range(0, 31):  # 先不读取新疆生产兵团的数据
        dictionary["数据"].append({})
        dictionary["数据"][j]["name"] = prov_list[j][0]
        dictionary["数据"][j]["news"] = dict()
        dictionary["数据"][j]["news"]["新增确诊"] = prov_list[j][1]
        dictionary["数据"][j]["news"]["新增无症状"] = prov_list[j][2]

        # 累计数量通过递推法计算
        if len(dict_total["数据表"]) > 0:  # 非第一天的数据
            dictionary["数据"][j]["news"]["累计确诊"] = prov_list[j][1] + dict_total["数据表"][-1]["数据"][j]["news"][
                "累计确诊"]
            dictionary["数据"][j]["news"]["累计无症状"] = prov_list[j][2] + dict_total["数据表"][-1]["数据"][j]["news"][
                "累计无症状"]
        else:  # 第一天的数据
            dictionary["数据"][j]["news"]["累计确诊"] = dictionary["数据"][j]["news"]["新增确诊"]
            dictionary["数据"][j]["news"]["累计无症状"] = dictionary["数据"][j]["news"]["新增无症状"]

        # print(dictionary["数据"][j]["news"]["累计无症状"])
    # 将生产兵团并入新疆，列表索引22
    dictionary["数据"][22]["news"]["新增确诊"] += prov_list[31][1]
    dictionary["数据"][22]["news"]["新增无症状"] += prov_list[31][2]
    dictionary["数据"][22]["news"]["累计确诊"] += prov_list[31][1]
    dictionary["数据"][22]["news"]["累计无症状"] += prov_list[31][2]

    # 加上港澳台的数据
    dictionary["数据"].append({})
    dictionary["数据"][31]["name"] = "港澳台"
    dictionary["数据"][31]["news"] = dict()
    dictionary["数据"][31]["news"]["累计确诊"] = num_total[i][4]
    if len(dict_total["数据表"]) > 0:
        dictionary["数据"][31]["news"]["新增确诊"] = num_total[i][4] - dict_total["数据表"][-1]["数据"][31]["news"]["累计确诊"]
    else:
        dictionary["数据"][31]["news"]["新增确诊"] = dictionary["数据"][31]["news"]["累计确诊"]

    # 保证日期和数据的同步性，完成大表数据的追加
    dict_total["时间表"].append(time_list[i])
    dict_total["数据表"].append(dictionary)

    return dict_total

def regex(time_list, text_list):
    len_data = len(time_list)   # 列表的长度: 968
    dict_total = create_dict(time_list)   # 初始化省份数据字典 (包含时间表和数据表)
    for i in range(0, len_data):   # 遍历列表中的数据，遍历参数i
        prov_list = [["福建"], ["浙江"], ["江苏"], ["广东"], ["广西"], ["江西"], ["安徽"], ["湖南"], ["湖北"], ["四川"],
                ["陕西"], ["河南"], ["云南"], ["贵州"], ["青海"], ["山东"], ["山西"], ["黑龙江"], ["吉林"], ["辽宁"],
                ["内蒙古"], ["宁夏"], ["新疆"], ["西藏"], ["上海"], ["北京"], ["天津"], ["重庆"], ["海南"], ["河北"],
                ["甘肃"], ["兵团"]]
        num_total.append([])
        # 新增确诊
        prov_list = cope_confirm(text_list, prov_list, i)
        # 新增无症状
        prov_list = cope_asypmptom(text_list, prov_list, i)
        # 新增港澳台
        cope_hk_mo_tw(text_list, i)
        # 将数据写入字典中
        dict_total = write_dict(time_list, prov_list, dict_total, i)

    return dict_total
