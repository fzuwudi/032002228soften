from pyecharts.globals import ThemeType
from pyecharts.charts import Timeline, Grid, Bar, Map, Pie, Line
from pyecharts.options import *

def get_num_addup(num_total):
    num_total_addup = list()
    i = 0
    for x in num_total:
        if i == 0:
            num_total_addup.append(x[0])
        else:
            num_total_addup.append(x[0] + num_total_addup[i - 1])
        i += 1

    return num_total_addup

# 月份索引
month_index = [7, 36, 67, 97, 128, 158, 189, 220, 250, 281, 311, 342, 373, 401, 432, 462, 493, 523, 554, 585, 615, 646,
               676, 707, 738, 766, 797, 827, 858, 888, 919, 950]

# 创建折线图数据列表
time_list_month = list()
for i in range(2020, 2022):
    for j in range(1, 13):
        time_list_month.append(f"{i}年{j}月")
for j in range(1, 9):
    time_list_month.append(f"2022年{j}月")

# 创建省份月份数据列表
def get_month_data(dict_total, time_t):
    data_dynamic = list()
    k = 0
    for i in month_index:
        data_tmp = dict()
        data_tmp["time"] = time_list_month[k]
        data_tmp["data"] = list()
        for j in range(0, 31):
            dict_tmp = dict()
            dict_tmp["name"] = dict_total["数据表"][i]["数据"][j]["name"]
            dict_tmp["value"] = dict_total["数据表"][i]["数据"][j]["news"]["累计确诊"]
            data_tmp["data"].append(dict_tmp)
        data_dynamic.append(data_tmp)
        k += 1

    map_data = list()
    for i in data_dynamic:
        if i["time"] == time_t:
            for j in i["data"]:
                map_data.append([j["name"], j["value"]])
    return map_data

maxNum = 10000
minNum = 10

# 创建map_dynamic对象
def create_map_dynamic(map_data, time_t):
    map_dynamic = Map()
    map_dynamic.add(
        series_name="",
        data_pair=map_data,
        zoom=0.85,
        is_selected=True,
        center=[119.5, 34.5],
        is_map_symbol_show=True,
        itemstyle_opts={
            "normal": {"areaColor": "#8693f9", "borderColor": "#1b1413"},
            "emphasis": {
                "label": {"show": Timeline},
                "areaColor": "rgba(255, 255, 255, 0.5)"
            }
        }
    )
    map_dynamic.set_global_opts(
        title_opts=TitleOpts(
            title="" + str(time_t) + "全国累计确诊人数（单位：人）",
            subtitle="数据来源：卫健委",
            subtitle_link="http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml",
            pos_left="center",
            pos_top="top",
            title_textstyle_opts=TextStyleOpts(
                font_size=25, color="#f7f7f8"
            )
        ),
        tooltip_opts=TooltipOpts(
            is_show=False,
        ),
        visualmap_opts=VisualMapOpts(
            is_show=True,
            is_calculable=True,
            is_piecewise=True,
            dimension=0,
            pos_left="30",
            pos_top="center",
            textstyle_opts=TextStyleOpts(color="#ddd"),
            # background_color="#0a2b52",
            # border_color= "#0a2b52",
            # border_width= 1,
            pieces=[
                {"min": 0, "max": 300, "label": "1-300人", "color": "#f3f7f6"},
                {"min": 301, "max": 800, "label": "301-800人", "color": "#b0e1ee"},
                {"min": 801, "max": 2000, "label": "801-2000人", "color": "#d1e58a"},
                {"min": 2001, "max": 5000, "label": "2001-5000人", "color": "#ec835f"},
                {"min": 5000, "label": "5000人以上", "color": "#dc2835"}
            ]
        )
    )
    map_dynamic.set_series_opts(
        label_opts=LabelOpts(
            is_show=True,
            color = "#0a2b52"
        )
    )

    return map_dynamic

# 创建折线图
def create_line_dynamic(num_total_addup, num_total,time_t):
    line_dynamic = Line()
    line_data_y = list()
    line_data_area = list()
    for i in month_index:
        line_data_y.append(num_total_addup[i])
        line_data_area.append(num_total[i][4])
    data_mark_mainland = []
    j = 0
    for x in time_list_month:
        if x == time_t:
            data_mark_mainland.append(line_data_y[j])
        else:
            data_mark_mainland.append("")
        j = j + 1
    line_dynamic.add_xaxis(time_list_month)
    line_dynamic.extend_axis(
        yaxis=AxisOpts(
            type_="value",
            position="right",
            axislabel_opts=LabelOpts(formatter="{value} 人")
        )
    )
    line_dynamic.add_yaxis("大陆累计确诊", line_data_y, is_smooth=True, color="#ffffff")
    line_dynamic.add_yaxis(
        "", data_mark_mainland,
        markpoint_opts=MarkPointOpts(data=[MarkPointItem(type_="max")])
    )
    line_dynamic.set_series_opts(label_opts=LabelOpts(is_show=False))
    line_dynamic.set_global_opts(
        title_opts=TitleOpts(title="全国每月累计确诊人数2020年1月-2022年8月（单位：人）", pos_left="65%", pos_top="5%"),
    )

    return line_dynamic


# 创建柱状图
def create_bar_dynamic(map_data):
    bar_x_data = [x[0] for x in map_data]

    map_data.sort(key = lambda x:[x[1]], reverse=True)
    bar_y_data = [{"name": x[0], "value": x[1]} for x in map_data]
    bar_dynamic = Bar()
    bar_dynamic.add_xaxis(xaxis_data=bar_x_data)
    bar_dynamic.add_yaxis(
        series_name="",
        y_axis=bar_y_data,
        label_opts=LabelOpts(
            is_show=True, position="right", formatter="{b} : {c}"
        )
    )
    bar_dynamic.reversal_axis()
    bar_dynamic.set_global_opts(
        xaxis_opts=AxisOpts(
            max_=maxNum, axislabel_opts=LabelOpts(is_show=False)
        ),
        yaxis_opts=AxisOpts(axislabel_opts=LabelOpts(is_show=False)),
        tooltip_opts=TooltipOpts(is_show=False),
        visualmap_opts=VisualMapOpts(
            is_calculable=True,
            dimension=0,
            pos_left="10",
            pos_top="top",
            range_text=["High", "Low"],
            range_color=["lightskyblue", "yellow", "orangered"],
            textstyle_opts=TextStyleOpts(color="#ddd"),
            is_piecewise=True,
            pieces=[
                {"min": 0, "max": 300, "label": "1-300人", "color": "#f3f7f6"},
                {"min": 301, "max": 800, "label": "301-800人", "color": "#b0e1ee"},
                {"min": 801, "max": 2000, "label": "801-2000人", "color": "#d1e58a"},
                {"min": 2001, "max": 5000, "label": "2001-5000人", "color": "#ec835f"},
                {"min": 5000, "label": "5000人以上", "color": "#dc2835"}
            ]
        )
    )

    return bar_dynamic

# 创建饼图
def create_pie_dynamic(map_data):
    pie_data = [[x[0], x[1]] for x in map_data]
    pie_dynamic = Pie()
    pie_dynamic.add(
        series_name="",
        data_pair=pie_data,
        radius=["12%", "28%"],
        center=["80%", "82%"],
        itemstyle_opts=ItemStyleOpts(
            border_width=1, border_color="rgba(0,0,0,0.3)"
        )
    )
    pie_dynamic.set_global_opts(
        tooltip_opts=TooltipOpts(is_show=True, formatter="{b} {d}%"),
        legend_opts=LegendOpts(is_show=False),
        visualmap_opts=VisualMapOpts(
            is_piecewise=True,
            pieces=[
                {"min": 0, "max": 300, "label": "1-300人", "color": "#f3f7f6"},
                {"min": 301, "max": 800, "label": "301-800人", "color": "#b0e1ee"},
                {"min": 801, "max": 2000, "label": "801-2000人", "color": "#d1e58a"},
                {"min": 2001, "max": 5000, "label": "2001-5000人", "color": "#ec835f"},
                {"min": 5000, "label": "5000人以上", "color": "#dc2835"}
            ]
        )
    )

    return pie_dynamic

# 组合成grid图
def create_grid(time_t, num_total, dict_total):
    num_total_addup = get_num_addup(num_total)
    map_data = get_month_data(dict_total, time_t)
    grid_dynamic = Grid()
    map_dynamic = create_map_dynamic(map_data, time_t)
    bar_dynamic = create_bar_dynamic(map_data)
    line_dynamic = create_line_dynamic(num_total_addup, num_total, time_t)
    pie_dynamic = create_pie_dynamic(map_data)
    grid_dynamic.add(
        bar_dynamic,
        grid_opts=GridOpts(pos_left="10", pos_right="45%", pos_top="50%", pos_bottom="5")
    )
    grid_dynamic.add(
        line_dynamic,
        grid_opts=GridOpts(pos_left="65%", pos_right="80", pos_top="10%", pos_bottom="50%")
    )
    grid_dynamic.add(
        pie_dynamic,
        grid_opts=GridOpts(pos_left="45%", pos_top="50%")
    )
    grid_dynamic.add(
        map_dynamic,
        grid_opts=GridOpts(pos_left="60%", pos_right="80")
    )

    return grid_dynamic

def visualDynamic(dict_total, num_total):
    timeline = Timeline(
        init_opts=InitOpts(width="1600px", height="900px", theme=ThemeType.CHALK)
    )
    for y in time_list_month:
        grid_dynamic = create_grid(y, num_total, dict_total)
        timeline.add(grid_dynamic, time_point=str(y))

    timeline.add_schema(
        orient="vertical",
        is_auto_play=True,
        is_inverse=True,
        play_interval=1800,
        pos_left="null",
        pos_right="5",
        pos_top="20",
        pos_bottom="20",
        width="60",
        label_opts=LabelOpts(is_show=True, color="#fff"),
    )

    timeline.render("china_pandemic_from_202002_to_202209.html")

# 测试代码
if __name__ == "__main__":
    dict_total = dict()
    num_total = list()
    timeline = Timeline(
        init_opts=InitOpts(width="1600px", height="900px", theme=ThemeType.WONDERLAND)
    )
    for y in time_list_month:
        grid_dynamic = create_grid(y, num_total, dict_total)
        timeline.add(grid_dynamic, time_point=str(y))

    timeline.add_schema(
        orient="vertical",
        is_auto_play=True,
        is_inverse=True,
        play_interval=5000,
        pos_left="null",
        pos_right="5",
        pos_top="20",
        pos_bottom="20",
        width="60",
        label_opts=LabelOpts(is_show=True, color="#fff"),
    )

    timeline.render("china_pandemic_from_202002_to_202209.html")
