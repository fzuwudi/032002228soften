import time
import re
import xlrd
from xlutils.copy import copy
from selenium import webdriver
from selenium.webdriver import ChromeOptions
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
# from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
# desired_capabilities = DesiredCapabilities.CHROME
# desired_capabilities["pageLoadStrategy"] = "none"

option = ChromeOptions()
# option.add_argument("--headless")   # 无头模式的选择
option.add_experimental_option("excludeSwitches", ['enable-automation'])   # 关闭Chrome受到自动化测试的提示
option.add_experimental_option('useAutomationExtension', False)   # 关闭开发者模式
option.add_argument('user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36')
option.add_argument("--disable-blink-features=AutomationControlled")
option.add_argument('blink-settings=imagesEnabled=false')
browser = webdriver.Chrome(options=option)

with open('./stealth.min.js') as f:   # 隐藏模拟浏览器的指纹特征，避开反爬虫机制
    js = f.read()
browser.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
    'source': js
})

# # 反爬虫测试，保存结果截图为bypass_test.png
# browser.get('https://bot.sannysoft.com/')
# browser.save_screenshot("no_crawl_test.png")

url_list = list()   # 存储每一天疫情通报的链接
next_list = list()   # 存储通报板块下一页的链接，实现通报页面的翻页
# text_list = list()   # 存储每一天的通报内容字符串
# time_list = list()   # 存储每一天的日期，其索引值与text_list一一对应

def crawl_link(origin_link):
    browser.get(origin_link)
    while True:
        time.sleep(1)   # 隐式等待
        lis = browser.find_elements(By.PARTIAL_LINK_TEXT, "截至")
        for i in lis:
            url_list.append(i.get_attribute("href"))
        next_page_link_list = browser.find_elements(By.LINK_TEXT, "下一页")
        if len(next_page_link_list) == 0:
            break
        else:
            next_list.append(next_page_link_list[0].get_attribute("href"))
            browser.get(next_list[-1])

def crwal_content(link, i):
    browser.get(link)
    time.sleep(1)
    # 显式等待
    content_list1 = WebDriverWait(browser, 30, 0.5).until(EC.presence_of_element_located((By.XPATH, "/html/body/div[3]/div[2]/div[2]/span[1]")))
    content_list1 = browser.find_elements(By.XPATH, "/html/body/div[3]/div[2]/div[2]/span[1]")
    content_list2 = browser.find_elements(By.XPATH, "/html/body/div[3]/div[2]/div[3]")
    # 爬取时间，并做正则化处理
    str_tmp = content_list1[0].text
    patt_time = re.compile("\d+?-\d+?-\d+")
    ls_time = patt_time.findall(str_tmp)[0]
    print(f"OK! {ls_time}")
    # time_list.insert(0, ls_time)
    # text_list.insert(0, content_list2[0].text)
    old_book = xlrd.open_workbook("save_crawl.xls")
    book = copy(old_book)
    sheet1 = book.get_sheet(0)
    sheet2 = book.get_sheet(1)

    sheet1.write(int(i/255), i%255, content_list2[0].text)
    sheet2.write(int(i/255), i%255, ls_time)
    book.save("save_crawl.xls")

def crawl_all(origin_link):
    crawl_link(origin_link)
    i = 0
    for single_link in url_list:
        crwal_content(single_link, i)
        i += 1

    return i
