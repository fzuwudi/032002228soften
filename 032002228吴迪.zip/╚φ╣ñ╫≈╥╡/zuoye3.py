#用于检索每个文本中的信息，收集数据
import requests
import lxml.etree
from lxml import etree
import pandas as pd
import re
import os
cookies = {
    'yfx_c_g_u_id_10006654': '_ck22091015111912117933959175841',
    'sVoELocvxVW0S': '5ZK7.umO85UOS6zmF7f8md6WWcIlDbT6ABKG29Q1nqkx0I92Ak0eVZtLQEgE0Y3imld.YAiUQi4xzxEFdDKanwG',
    'insert_cookie': '96816998',
    'yfx_f_l_v_t_10006654': 'f_t_1662793879214__r_t_1663048365060__v_t_1663068814254__r_c_3',
    'security_session_verify': '0b3e5e432a0cd0cca9d59a9c0ae9ec6d',
    'sVoELocvxVW0T': '53nqG8DWGEo9qqqDkJj1lgG9Vhz8AKxRhwfboIjQ093hXUPPP31oFVACzWoveONjxXxf.Tg88Gs9zLvp8eRBvrHcnB23_SW8buKfvfAEYj541E3PQq0dqKIQzeSWUgir0YOE0Tl84wKjH4FtbTmDtQhOs.elRTFNm6vgmwElpTFe76ctNeL9gcVqP5Tv7pUioboR5BgrXWgFCB6C4eS3TN62IIS.Z7mzgGhek3HPpZ40iRf7jyySzZNdkCd27xTPyQdG3BMxBGc1Gqng0KJV_UL_45mkK_bDdr5pYJLQWNdozuxSgAGeS8QNjXXw93EXEd.FZh3.P6odHE0IRamdqwsf9lVUP4vDONsszqeBr5o2G',
}
headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6',
    'Cache-Control': 'max-age=0',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33',
}
wanzhi=[]
with open('web.txt','r',encoding='utf-8') as f:
    shuju=f.readlines()
    #按行读取
    #第一步是以字符串的形式存入的，所以现在按行读取出来的数据是一个又一个的字符串，每个字符串后面都有一个'\n'
    for i in shuju:
        i=i.replace('\n','')
        #把'\n'用''代替
        i=i.split()
        #以空格为分隔符
        i[0]='http://www.nhc.gov.cn'+i[0]
        #刚刚爬取得到的路径是不完整的，需要加上头部
        wanzhi.append(i)
for i in wanzhi[619:]:
    try:
        shiqi=i[1]
        print(shiqi)
        f=open('2020'+shiqi+'.txt',encoding='utf-8')   #设置文件对象
        str=f.read()     #将txt文件的所有内容读入到字符串str中
        f.close()   #将文件关闭
        print(str)
        全国新增确诊=re.findall('新增确诊病例.*?本土病例(.*?)例', str)[0]
        print(全国新增确诊)
        全国新增无症状=re.findall('新增无症状感染者.*?本土(.*?)例', str)[0]
        print(全国新增无症状)
        全省新增确诊=re.findall('新增确诊病例.*?本土病例.*?例.*?（(.*?)）。', str)[0]
        print(全省新增确诊)
        全省新增无症状=re.findall('新增无症状感染者.*?本土.*?例（(.*?)）', str)[0]
        print(全省新增无症状)
        香港新增= re.findall('香港特别行政区(.*?)例', str)[0]
        print(香港新增)
        澳门新增 = re.findall('澳门特别行政区(.*?)例', str)[0]
        print(澳门新增)
        台湾新增 = re.findall('台湾地区(.*?)例', str)[0]
        print(台湾新增)
        省 = '山西省，辽宁省，吉林省，黑龙江省，江苏省，浙江省，安徽省，福建省，江西省，山东省，河南省，湖北省，湖南省，广东省，海南省，四川省，贵州省，云南省，陕西省，甘肃省，青海省，北京，天津，上海，重庆，内蒙古，广西，宁夏，新疆，西藏，河北'
        省 = [i.replace('省', '') for i in 省.split('，')]
        moban=[0]*68
        if '山西' in 全省新增确诊:
            num=re.findall('山西(.*?)例',全省新增确诊)[0]
            print(num)
            moban[省.index('山西')] = num
        if '上海' in 全省新增确诊:
            num = re.findall('上海(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('上海')] = num
        if '辽宁' in 全省新增确诊:
            num = re.findall('辽宁(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('辽宁')] = num
        if '吉林' in 全省新增确诊:
            num = re.findall('吉林(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('吉林')] = num
        if '黑龙江' in 全省新增确诊:
            num = re.findall('黑龙江(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('黑龙江')] = num
        if '江苏' in 全省新增确诊:
            num = re.findall('江苏(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('江苏')] = num
        if '浙江' in 全省新增确诊:
            num = re.findall('浙江(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('浙江')] = num
        if '安徽' in 全省新增确诊:
            num = re.findall('安徽(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('安徽')] = num
        if '福建' in 全省新增确诊:
            num = re.findall('福建(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('福建')] = num
        if '江西' in 全省新增确诊:
            num = re.findall('江西(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('江西')] = num
        if '山东' in 全省新增确诊:
            num=re.findall('山东(.*?)例',全省新增确诊)[0]
            print(num)
            moban[省.index('山东')] = num
        if '河南' in 全省新增确诊:
            num = re.findall('河南(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('河南')] = num
        if '湖北' in 全省新增确诊:
            num = re.findall('湖北(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('湖北')] = num
        if '湖南' in 全省新增确诊:
            num = re.findall('湖南(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('湖南')] = num
        if '广东' in 全省新增确诊:
            num = re.findall('广东(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('广东')] = num
        if '海南' in 全省新增确诊:
            num = re.findall('海南(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('海南')] = num
        if '四川' in 全省新增确诊:
            num = re.findall('四川(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('四川')] = num
        if '贵州' in 全省新增确诊:
            num = re.findall('贵州(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('贵州')] = num
        if '云南' in 全省新增确诊:
            num = re.findall('云南(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('云南')] = num
        if '陕西' in 全省新增确诊:
            num = re.findall('陕西(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('陕西')] = num
        if '甘肃' in 全省新增确诊:
            num = re.findall('甘肃(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('甘肃')] = num
        if '青海' in 全省新增确诊:
            num = re.findall('青海(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('青海')] = num
        if '北京' in 全省新增确诊:
            num = re.findall('北京.*?(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('北京')] = num
        if '天津' in 全省新增确诊:
            num = re.findall('天津(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('天津')] = num
        if '重庆' in 全省新增确诊:
            num = re.findall('重庆(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('重庆')] = num
        if '内蒙古' in 全省新增确诊:
            num = re.findall('内蒙古(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('内蒙古')] = num
        if '广西' in 全省新增确诊:
            num = re.findall('广西(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('广西')] = num
        if '宁夏' in 全省新增确诊:
            num = re.findall('宁夏(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('宁夏')] = num
        if '新疆' in 全省新增确诊:
            num = re.findall('新疆(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('新疆')] = num
        if '西藏' in 全省新增确诊:
            num = re.findall('西藏(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('西藏')] = num
        if '河北' in 全省新增确诊:
            num = re.findall('河北(.*?)例', 全省新增确诊)[0]
            print(num)
            moban[省.index('河北')] = num

        if '山西' in 全省新增无症状:
            num=re.findall('山西(.*?)例',全省新增无症状)[0]
            print(num)
            moban[省.index('山西')+31] = num
        if '上海' in 全省新增无症状:
            num = re.findall('上海(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('上海')+31] = num
        if '辽宁' in 全省新增无症状:
            num = re.findall('辽宁(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('辽宁')+31] = num
        if '吉林' in 全省新增无症状:
            num = re.findall('吉林(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('吉林')+31] = num
        if '黑龙江' in 全省新增无症状:
            num = re.findall('黑龙江(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('黑龙江')+31] = num
        if '江苏' in 全省新增无症状:
            num = re.findall('江苏(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('江苏')+31] = num
        if '浙江' in 全省新增无症状:
            num = re.findall('浙江(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('浙江')+31] = num
        if '安徽' in 全省新增无症状:
            num = re.findall('安徽(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('安徽')+31] = num
        if '福建' in 全省新增无症状:
            num = re.findall('福建(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('福建')+31] = num
        if '江西' in 全省新增无症状:
            num = re.findall('江西(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('江西')+31] = num
        if '山东' in 全省新增无症状:
            num=re.findall('山东(.*?)例',全省新增无症状)[0]
            print(num)
            moban[省.index('山东')+31] = num
        if '河南' in 全省新增无症状:
            num = re.findall('河南(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('河南')+31] = num
        if '湖北' in 全省新增无症状:
            num = re.findall('湖北(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('湖北')+31] = num
        if '湖南' in 全省新增无症状:
            num = re.findall('湖南(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('湖南')+31] = num
        if '广东' in 全省新增无症状:
            num = re.findall('广东(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('广东')+31] = num
        if '海南' in 全省新增无症状:
            num = re.findall('海南(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('海南')+31] = num
        if '四川' in 全省新增无症状:
            num = re.findall('四川(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('四川')+31] = num
        if '贵州' in 全省新增无症状:
            num = re.findall('贵州(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('贵州')+31] = num
        if '云南' in 全省新增无症状:
            num = re.findall('云南(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('云南')+31] = num
        if '陕西' in 全省新增无症状:
            num = re.findall('陕西(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('陕西')+31] = num
        if '甘肃' in 全省新增无症状:
            num = re.findall('甘肃(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('甘肃')+31] = num
        if '青海' in 全省新增无症状:
            num = re.findall('青海(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('青海')+31] = num
        if '北京' in 全省新增无症状:
            num = re.findall('北京(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('北京')+31] = num
        if '天津' in 全省新增无症状:
            num = re.findall('天津(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('天津')+31] = num
        if '重庆' in 全省新增无症状:
            num = re.findall('重庆(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('重庆')+31] = num
        if '内蒙古' in 全省新增无症状:
            num = re.findall('内蒙古(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('内蒙古')+31] = num
        if '广西' in 全省新增无症状:
            num = re.findall('广西(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('广西')+31] = num
        if '宁夏' in 全省新增无症状:
            num = re.findall('宁夏(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('宁夏')+31] = num
        if '新疆' in 全省新增无症状:
            num = re.findall('新疆(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('新疆')+31] = num
        if '西藏' in 全省新增无症状:
            num = re.findall('西藏(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('西藏')+31] = num
        if '河北' in 全省新增无症状:
            num = re.findall('河北(.*?)例', 全省新增无症状)[0]
            print(num)
            moban[省.index('河北')+31] = num


        # moban.append(全国新增确诊)
        # moban.append(全国新增无症状)
        # moban.append(shiqi)
        省 = [i + '确诊' for i in 省] + [i + '无症状' for i in 省]
        省.append('香港')
        省.append('澳门')
        省.append('台湾')
        省.append('全国确诊')
        省.append('全国无症状')
        省.append('日期')
        moban[省.index('香港')] = 香港新增
        moban[省.index('澳门')] = 澳门新增
        moban[省.index('台湾')] = 台湾新增
        moban[省.index('全国确诊')] = 全国新增确诊
        moban[省.index('全国无症状')] = 全国新增无症状
        moban[省.index('日期')] = shiqi
        print(moban)
        print(省)
        zid={}
        for ki,kd in zip(省,moban):
            zid[ki]=[kd]

        if os.path.exists('shujuji5.xlsx'):
            df=pd.read_excel('shujuji5.xlsx')
            df=df.append(pd.DataFrame(zid))
            df.to_excel('shujuji5.xlsx',index=None)
        else:
            pd.DataFrame(zid).to_excel('shujuji5.xlsx',index=None)
    except:
        continue
    #第一次尝试的代码:
    #全国新增确诊、全国新增无症状、全省新增确诊、全省新增无症状都是str
    # 全省新增确诊= 全省新增确诊.split('，')
    # 全省新增确诊 = [i.replace('例', '') for i in 全省新增确诊]
    # 全省新增确诊数据=[]
    # for i in 全省新增确诊:
    #     for j in i:
    #         if '0' <= j <= '9':
    #             汉字 = i[:i.index(j)]
    #             数字 = i[i.index(j):]
    #             全省新增确诊数据.append([汉字, 数字])
    #             break;
    # # print(全省新增确诊数据)
    # 全省新增无症状= 全省新增无症状.split('，')
    # 全省新增无症状 = [i.replace('例', '') for i in 全省新增无症状]
    # 全省新增无症状数据=[]
    # for i in 全省新增无症状:
    #     for j in i:
    #         if '0' <= j <= '9':
    #             汉字 = i[:i.index(j)]
    #             数字 = i[i.index(j):]
    #             全省新增无症状数据.append([汉字, 数字])
    #             break;
    # # print(全省新增无症状数据)
    # 省 = '山西省，辽宁省，吉林省，黑龙江省，江苏省，浙江省，安徽省，福建省，江西省，山东省，河南省，湖北省，湖南省，广东省，海南省，四川省，贵州省，云南省，陕西省，甘肃省，青海省，北京，天津，上海，重庆，内蒙古，广西，宁夏，新疆，西藏，河北'
    # 省 = [i.replace('省', '') for i in 省.split('，')]
    # moban=[0]*62
    # for l in 全省新增确诊数据:
    #     try:
    #         moban[省.index(l[0])] = l[1]
    #     except:
    #         continue
    # for l in 全省新增无症状数据:
    #     try:
    #         moban[省.index(l[0]) + 31] = l[1]
    #     except:
    #         continue
    # 省 = [i + '确诊' for i in 省] + [i + '无症状' for i in 省]
    # moban.append(全国新增确诊)
    # moban.append(全国新增无症状)
    # moban.append(shiqi)
    # 省.append('全国确诊')
    # 省.append('全国无症状')
    # 省.append('日期')
    # print(省)
    # print(moban)
    # zid={}
    # for ki,kd in zip(省,moban):
    #     zid[ki]=[kd]
    #
    # if os.path.exists('shujuji3.xlsx'):
    #     df=pd.read_excel('shujuji3.xlsx')
    #     df=df.append(pd.DataFrame(zid))
    #     df.to_excel('shujuji3.xlsx',index=None)
    # else:
    #     pd.DataFrame(zid).to_excel('shujuji3.xlsx',index=None)




