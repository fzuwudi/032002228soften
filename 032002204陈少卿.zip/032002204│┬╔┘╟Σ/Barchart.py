# _*_coding : utf-8_*_
# @Time : 22-9-6 00:48
# @Name : Shaoqing Chen
# @File : python2
# @Project : python学
import openpyxl
from openpyxl.chart import BarChart, Reference, label


def mychart(excel_name):
    wb = openpyxl.load_workbook(excel_name)
    sheet = wb.active
    # 创建一个Reference
    for sheetname in wb.sheetnames:
        sheet = wb[f'{sheetname}']#遍历每一个sheet
        values = openpyxl.chart.Reference(sheet, min_row=1, min_col=2, max_row=32, max_col=2)# 设置数据区域
        # 创建图表对象
        chart = openpyxl.chart.BarChart()
        chart.legend=None
        chart.showGridLines = False # 不显示网格线
        chart.dLbls = label.DataLabelList()
        chart.dLbls.showVal =True
        chart.varyColors = True
        chart.width = 30
        chart.height =15
        chart.title='各省份每日新增'
        chart.x_axis.title='省份'
        chart.y_axis.title='新增人数'
        categs =openpyxl.chart.Reference(sheet, min_col=1, min_row=1, max_row=32, max_col=1)
        #往图表对象中添加数据
        chart.add_data(values)
        chart.set_categories(categs)
        #将图表添加到指定的sheet中
        sheet.add_chart(chart,'G2')
        wb.save(excel_name)
