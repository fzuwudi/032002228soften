# _*_coding : utf-8_*_
# @Time : 22-9-6 00:48
# @Name : Shaoqing Chen
# @File : python2
# @Project : python学
# 获取每一个网页的url

# 获取每一个网页的源代码
# 获取每一个网页中的疫情链接
# 获取疫情链接的源代码
# 解析源代码获取数据
# 保存到本地文件中
# 爬虫爬取疫情数据
import asyncio
import tkinter as tk
from pyppeteer import launch
from lxml import etree
import time
import os
# 设置窗口大小
def screen_size():
    # 创建一个新的窗口
    root = tk.Tk()
    # 获取当前屏幕的大小
    width = root.winfo_screenwidth()
    height = root.winfo_screenheight()
    root.quit()
    return width, height

async def pyppeteer_url(url):
    # 创建一个浏览器实例对象
    browser = await launch({'headless': False, 'dumpio': True})
    # 用浏览器打开一个网页，并创建page对象
    page = await browser.newPage()
    # 绕过浏览器的检测
    await page.evaluateOnNewDocument('() =>{ Object.defineProperties(navigator,'
                                     '{ webdriver:{ get: () => false } }) }')
    width, height = screen_size()
    # 设置页面视口的大小
    await page.setViewport({'width': width, 'height': height})
    await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.33')
    # 输入网址等待加载
    await page.goto(url)
    # 等待页面加载出来
    await asyncio.wait([page.waitForNavigation()])
    content = await page.content()
    await browser.close()
    return content

# 获取网页的源代码
def get_PageSource(url):
    # 用get_event_loop()方法创建一个事件循环
    loop = asyncio.get_event_loop()
    # 再调用事件循环对象loop的run_until_complete方法将协程注册到事件循环中
    return loop.run_until_complete(pyppeteer_url(url))

# 获取发布日期
def get_Date(s):
    date_list =[]
    date_tree = etree.HTML(s)
    li_list = date_tree.xpath("/html/body/div[3]/div[2]/ul/li")
    for li in li_list:
        # 获取当前节点下的span标签的内容
        date = li.xpath("./span/text()")
        # 将返回的列表转化为字符串
        date = "".join(date)
        date_list.append(date)
    return date_list

# 获取疫情数据链接
def get_Link(s):
    link_list = []
    link_tree = etree.HTML(s)
    li_list = link_tree.xpath("/html/body/div[3]/div[2]/ul/li")
    for li in li_list:
        day_link = li.xpath("./a/@href")
        day_link = "http://www.nhc.gov.cn" + "".join(day_link)
        link_list.append(day_link)
    return link_list

# 获取疫情数据
def get_Content(s):
    content_tree = etree.HTML(s)
    # 获取链接页面中的疫情数据
    all_content = content_tree.xpath("/html/body/div[3]/div[2]/div[3]//text()")
    day_content = "".join(all_content)
    return day_content

# 保存到本地
def savefile(path, filename, content):
    # 判断path文件是否存在
    if not os.path.exists(path):
        # 创建目录
        os.makedirs(path)
    # 保存文件,打开文件用于写入‘w'
    with open(path + filename + '.txt', 'w', encoding='utf-8')as f:
        f.write(content)

def get_PageUrl():
    url_list = []
    # 获取41页的url
    for page in range(1, 42):
        if page == 1:
            page_url = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml"
            url_list.append(page_url)
        else:
            page_url = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_" + str(page) + ".shtml"
            url_list.append(page_url)
    return url_list

if __name__ == '__main__':
    for url in get_PageUrl():
        # source为网页的源代码
        source = get_PageSource(url)
        time.sleep(3)
        dates = get_Date(source)
        print("日期列表:", dates)
        links = get_Link(source)
        print("页面链接", links)
        idx = 0
        for link in links:
            s = get_PageSource(link)# 获取链接页面的源代码
            content = get_Content(s)# 获取疫情数据
            print(dates[idx], "疫情数据", content)
            savefile("E:/疫情数据", dates[idx], content)
            idx = idx + 1
    print("over!")

