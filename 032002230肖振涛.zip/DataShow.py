
from matplotlib import pyplot as plt
import pandas as pd
import numpy as np

# matplotlib画图中中文显示会有问题，需要这两行设置默认字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# matplotlib画图中中文显示会有问题，需要这两行设置默认字体
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

df = pd.read_csv('2022年09月18日全国疫情累计数据.csv')
df = df.sort_values(by='nowConfirm', ascending=False)

x_label = np.array(df["province"])
x = np.arange(5)
y1 = np.array(df["nowConfirm"][:5])
y2 = np.array(df["heal"][:5])

fig = plt.figure(figsize=(10, 10))
plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)

plt.bar(x, y1, width=0.3, color='#00AFBB', label='nowConfirm', edgecolor='k', linewidth=0.25)
plt.bar(x + 0.3, y2, width=0.3, color='#FC4E07', label='heal', edgecolor='k', linewidth=0.25)
plt.xticks(x + 0.15, x_label[:5], size=12)
plt.yticks(size=12)
plt.legend(loc=(1, 0.5), ncol=1, frameon=False)
plt.grid(axis="y", c=(217 / 256, 217 / 256, 217 / 256))
plt.show()

df = pd.read_csv('2022年09月18日全国疫情累计数据.csv')

x_label = np.array(df["province"])[:5]

n_row, n_col = df.shape
x_value = np.arange(n_row)[:5]
y1 = np.array(df["nowConfirm"][:5])
y2 = np.array(df["heal"][:5])
y3 = np.array(df["dead"][:5])

fig = plt.figure(figsize=(10, 10))
plt.subplots_adjust(left=0.1, right=0.9, top=0.9, bottom=0.1)
plt.bar(x_value, y1, width=0.5, color='blue', label='nowConfirm', edgecolor='k', linewidth=0.25)
plt.bar(x_value, y2, width=0.5, color='green', label='heal', bottom=y1, edgecolor='k', linewidth=0.25)
plt.bar(x_value, y3, width=0.5, color='red', label='dead', bottom=np.array(y2) + np.array(y1), edgecolor='k',
        linewidth=0.25)

plt.xticks(x_value, x_label, size=10)
# plt.tick_params(axis="x",width=5)
plt.legend(loc=(1, 0.3), ncol=1, frameon=False)

plt.grid(axis="y", c=(166 / 256, 166 / 256, 166 / 256))
plt.show()

df = pd.read_csv('2022年09月18日全国疫情累计数据.csv')

x_label = np.array(df["province"])[:5]
n_row, n_col = df.shape
x_value = np.arange(n_row)[:5]
y1 = np.array(df["nowConfirm"])[:5] / (df["confirm"])[:5]
y2 = np.array(df["heal"])[:5] / (df["confirm"])[:5]
y3 = np.array(df["dead"])[:5] / (df["confirm"])[:5]

# bottom_y=np.zeros(n_col)

fig = plt.figure(figsize=(10, 10))
# plt.subplots_adjust(left=0.1, right=0.9, top=0.7, bottom=0.1)

plt.bar(x_value, y1, width=0.5, color='blue', label='nowConfirm', edgecolor='k', linewidth=0.25)
plt.bar(x_value, y2, width=0.5, color='green', label='heal', bottom=y1, edgecolor='k', linewidth=0.25)
plt.bar(x_value, y3, width=0.5, color='red', label='dead', bottom=np.array(y2) + np.array(y1), edgecolor='k',
        linewidth=0.25)
print(plt.gca().get_yticks())
plt.xticks(x_value, x_label, size=10)
plt.gca().set_yticklabels(['{:.0f}%'.format(x * 100) for x in plt.gca().get_yticks()])
# plt.tick_params(axis="x",width=5)
plt.legend(loc=(1, 0.3), ncol=1, frameon=False)

plt.grid(axis="y", c=(166 / 256, 166 / 256, 166 / 256))
plt.show()
