import time
from selenium import webdriver

browser = webdriver.Chrome()
browser.get("http://www.crazyant.net/")
print(browser.page_source)

time.sleep(1)
browser.quit()
