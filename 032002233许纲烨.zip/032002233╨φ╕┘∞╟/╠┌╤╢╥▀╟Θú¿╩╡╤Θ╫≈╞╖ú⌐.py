import matplotlib.pyplot as plt
import requests
import  csv
import re

def get_messages():
    url = 'https://api.inews.qq.com/newsqa/v1/query/pubished/daily/list?adCode=120000&limit=30'
    headers = {
        'Host': 'api.inews.qq.com',
        'Origin': 'https://news.qq.com',
        'Referer': 'https://news.qq.com/',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.42'

    }

    response = requests.post(url=url, headers=headers)
    response.encoding = response.apparent_encoding
    datas = response.json()['data']
    f = open("天津疫情历史数据.csv", mode="w", newline="", encoding="utf-8-sig")
    csv_write = csv.writer(f)
    csv_write.writerow(['日期', '总确诊数', '新增确诊数', '总治愈数', '总死亡数', '新增死亡数', '新增治愈数'])

    dates = []
    confirms = []
    with open("天津疫情历史数据.csv", mode="a+", newline="", encoding="utf-8-sig") as f:
        csv_write = csv.writer(f)
        for data in datas:
            dates.append(data['date'])
            confirms.append(data['confirm'])
            csv_write.writerow(
                [data['date'], data['confirm'], data['confirm_add'], data['heal'], data['dead'], data['newDead'],
                 data['newHeal']])
    f.close()

    # 开始可视化
    plt.plot(dates, confirms, label="确诊")
    plt.xlabel("日期")
    plt.ylabel("确诊数")
    plt.title("天津市确诊折线图")
    plt.rcParams['font.sans-serif'] = ['SimHei']
    plt.rcParams['axes.unicode_minus'] = False
    plt.legend()
    plt.show()

