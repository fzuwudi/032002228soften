import os
import asyncio
from pyppeteer import launch
from bs4 import BeautifulSoup
import re
import json
import xlwings as xw


async def pyppteer_fetchUrl(url):
    browser = await launch({'headless': False,'dumpio':True, 'autoClose':True})
    page = await browser.newPage()

    await page.goto(url)
    await asyncio.wait([page.waitForNavigation()])
    str = await page.content()
    await browser.close()
    return str

def fetchUrl(url):
    return asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(url))

def getPageUrl():
    for page in range(1,42):
        if page == 1:
            yield 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
        else:
            url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_'+ str(page) +'.shtml'
            yield url

def getTitleUrl(html):

    bsobj = BeautifulSoup(html,'lxml')
    titleList = bsobj.find('div', attrs={"class":"list"}).ul.find_all("li")
    for item in titleList:
        link = "http://www.nhc.gov.cn" + item.a["href"];
        title = item.a["title"]
        date = item.span.text
        yield title, link, date


def getContent(html):
    bsobj = BeautifulSoup(html, 'lxml')
    cnt = bsobj.find('div', attrs={"id": "xw_box"}).find_all("p")
    s = ""
    if cnt:
        for item in cnt:
            s += item.text
        return s

    return "爬取失败！"





#def saveFile(path, filename, content):
    # if not os.path.exists(path):
       # os.makedirs(path)

    # 保存文件
   # with open(path + filename + ".txt", 'w', encoding='utf-8') as f:
      #  f.write(content)

if "__main__" == __name__:
    for url in getPageUrl():
        s =fetchUrl(url)
        for title, link, date in getTitleUrl(s):
            print(title, link)
            html = fetchUrl(url)
            news = getContent(html)

            ch_all_dict = {}
            all_dict = {}
            gat_dict = {}

            '''我国31个省（自治区、直辖市）和新疆生产建设兵团（不包括港澳台）'''
            # 时间
            all_dict['pub_time'] = re.search('截至(.*?)24时', news).group(1)  # group(1)代表括号里的内容
            # 新增确诊
            all_dict['confirm_add'] = re.search('31个省（自治区、直辖市）和新疆生产建设兵团报告新增确诊病例(.*?)例',
                                                news).group(1)
            # 新增无症状感染
            all_dict['newnoconfirm_add'] = re.search(
                '31个省（自治区、直辖市）和新疆生产建设兵团报告新增无症状感染者(.*?)例',
                news).group(1)
            #

            wb = xw.Book()  # 相当于打开excel操作
            sht = wb.sheets('sheet1')  # 相当于在excel里加了一个工作表
            sht.range('A1').values = '地区'
            sht.range('B1').values = '新增确诊'
            sht.range('C1').values = '新增无症状感染'
            sht.range('D1').values = '日期'

            for i in range(1):
                today_confirm = all_dict['confirm_add']
                sht.range(f'B{i + 2}').value = today_confirm
                total_confirm = all_dict['newnoconfirm_add']
                sht.range(f'C{i + 2}').value = total_confirm
                date = all_dict['pub_time']
                sht.range(f'D{i + 2}').value = date


