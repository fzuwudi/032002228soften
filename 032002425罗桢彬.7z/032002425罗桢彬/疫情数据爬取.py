
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time,re
import xlwt
import re
import pandas as pd
from bs4 import BeautifulSoup
import urllib.request

#筛选数据函数
def shuru(string):
    try:
        all_dict[string] = re.search(string + '(.*?)例.*?，', temp1).group(1)
        all_dict2[string] = re.search(string + '(.*?)例.*?，', temp).group(1)
    except:
        all_dict[string] = 0
        all_dict2[string] = 0
list = (
    '河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南',
    '广东', '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海', '内蒙古', '广西', '西藏', '宁夏', '北京', '天津',
    '上海', '重庆')
s = Service("chromedriver.exe")
driver = webdriver.Chrome(service=s)
driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
    "source": """
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined
    })
  """
})



driver = webdriver.Chrome()
driver.get("http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml")
time.sleep(1)  # 留出加载时间


links = driver.find_elements(By.XPATH,'/html/body/div[3]/div[2]/ul//a')  # 获取到所有a标签，组成一个列表
length = len(links)  # 列表的长度，一共有多少个a标签


for i in range(0, length):  # 遍历列表的循环，使程序可以逐一点击
    links = driver.find_elements(By.XPATH,'/html/body/div[3]/div[2]/ul//a')  # 在每次循环内都重新获取a标签，组成列表
    link = links[i]  # 逐一将列表里的a标签赋给link
    url = link.get_attribute('href')  # 提取a标签内的链接
    driver.get(url)
    content = driver.page_source


    soup = BeautifulSoup(content, 'lxml')
    province_list = soup.select('div[class="con"] ')
    all_dict = {}
    all_dict2 = {}
    temp = re.search('本土病例.*?例（(.*?)）.*?，', province_list[0].get_text()).group(1)
    temp1 = re.search('报告新增无症状感染者.*?本土.*?例（(.*?)）.*?。', province_list[0].get_text()).group(1)
    date = re.search('(.*?)0.*?，', province_list[0].get_text()).group(1)
    quezhen_sum = re.search('本土病例(.*?)例', province_list[0].get_text()).group(1)
    wuzhengzhuang_sum = re.search('报告新增无症状感染者.*?本土(.*?)例', province_list[0].get_text()).group(1)
    for j in range(0, 30):
        shuru(list[j])

    try:
        all_dict['新疆'] = re.search('新疆(.*?)例.*?，', temp1).group(1)

    except:
        all_dict['新疆'] = 0

    try:
        all_dict2['新疆'] = re.search('新疆(.*?)例.*?', temp).group(1)
    except:
        all_dict2['新疆'] = 0

    for k, v in all_dict.items():
        print(k, v)
    for k, v in all_dict2.items():
        print(k, v)

    # 制成表格


    k = []
    for key in all_dict:
        num = [key, all_dict[key], all_dict2[key]]
        k.append(num)
    print(k)
    data = pd.DataFrame(k, columns=['省份', '新增无症状', '新增确诊'])
    writer = pd.ExcelWriter(date+'统计.xlsx')  # 写入Excel文件，表格名为当天通报的日期
    data.to_excel(writer)
    writer.save()

    writer.close()

    driver.back()  # 后退，返回原始页面目录页
    time.sleep(1)  # 留出加载时间

print(length)  # 打印列表长度，即有多少篇文章