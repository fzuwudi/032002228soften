from selenium.webdriver import Firefox
from selenium.webdriver import FirefoxOptions
from bs4 import BeautifulSoup
import time,re
import xlwt
from pyecharts import options as opts
from pyecharts.charts import Map

def getpage():   #页数函数
    for page in range(1,42):
        if page == 1:
            yield'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
        else:
            url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_'+str(page)+'.shtml'
            yield url
def getTime(url_text):
    soup = BeautifulSoup(url_text, "lxml")  # 再次创建对象
    Title_Get = soup.find('div', class_="tit").text
    regex1=re.compile('[0-9]+')
    Title_Get=regex1.findall(Title_Get)  #由于返回的是一个列表，所以取出列表的第一个内容,即日期
    release_Get = soup.find('div',class_='source').find_all('span')[3].text
    regex2=re.compile('[0-9]+')
    release_Get= regex2.findall(release_Get)  #
    if int(Title_Get[0])<int(release_Get[1]): #如果发布新闻的月份比通报的疫情日期还小，则年份要减一
        Title_year_Get= str(int(release_Get[0])-1)
    else:
        Title_year_Get = str(int(release_Get[0]))
    Title_month_Get = Title_Get[0]
    Title_day_Get = Title_Get[1]
    Time=(Title_year_Get+'年'+Title_month_Get+'月'+Title_day_Get+'日新型冠状病毒肺炎疫情')#返回一个文件标题
    return Time
def getLocal_add(url_text):
    soup = BeautifulSoup(url_text, "lxml")  # 创建对象
    p_list = soup.find('div', class_='con').find('p').text  # 找到第一条p标签，即本土病例的内容
    regex_1 = re.compile('本土病例.+.+(?=，)')
    p_list = regex_1.findall(p_list)[0]  #获得本土省份确诊人数
    local_definite_sum = re.search('(?<=本土病例)[0-9]*',p_list).group()#本地新增人数总和
    province_list = re.search('(?<=（).+.+(?=）)',p_list).group()
    province = re.findall('([\u4e00-\u9fa5]+)(?=[\d]+)',province_list)#获得存储省份的列表
    province_people = re.findall('[0-9]+', province_list)#获得存储人数的列表
    ll = [0]*len(province)  #创建一个跟省份数目相同的全为‘0’的列表
    nubmtuple = tuple(zip( map(int, province_people),ll)) #将确诊人数设置为（x，0)的元组
    a=dict(zip(province,nubmtuple))
    return a
def getNoSymptom_add(url_text):
    soup = BeautifulSoup(url_text, "lxml")  # 创建对象
    s_list = soup.find('div', class_='con').find_all('p')[4].text # 找到第一条p标签，即新增感染者的详细内容
    regex_1 = re.compile('本土.+.+(?=。)')
    s_list = regex_1.findall(s_list)[0]  #获得本土省份确诊人数
    NoSymptom_sum = re.search('(?<=本土)[0-9]*',s_list).group()
    province_list = re.search('(?<=（).+.+(?=）)',s_list).group()
    province = re.findall('([\u4e00-\u9fa5]+)(?=[\d]+)',province_list)#获得存储省份的列表
    province_people = re.findall('[0-9]+', province_list)##获得存储人数的列表
    ll = [0]*len(province)#创建一个跟省份数目相同的全为‘0’的列表
    nubmtuple = tuple(zip(ll, map(int, province_people)))  #将无症状感染人数设置为（0，x)的元组
    a=dict(zip(province,nubmtuple))
    return a
def getHMT_people(url_text):
    soup = BeautifulSoup(url_text, "lxml")  # 创建对象
    p_list = soup.find('div', class_='con').find_all('p')[6].text  # 找到第一条p标签，即新增感染者的详细内容
    regex_1 = re.compile('[0-9]+.(?=例（)')
    people_num = regex_1.findall(p_list) # 获得每个地方的累计确诊人数
    province = ["香港","澳门","台湾"]
    add = dict(zip(province,map(int,people_num)))
    return add
def add_data(a,b): #省份的确诊人数与无症状感染数据合并
    for i in b.keys():  #嵌套两个循环，从第一个字典的键开始查找是否跟第二个字典的键相匹配，
        # 匹配则将感染人数的两个信息合并，没有匹配项则增加到字典中
        flag =0
        for j in a.keys():
            if i == j:
               a[j]=(a[j][0],b[i][1])
               flag=1
               break
        if flag==0: #如果a字典的键中没有b的某一个键，则增加到a中
            a[i]=(b[i][0],b[i][1])
    return a
def write_to_excel(filename, dict1,dict2):
        # 创建一个excel文件
        work_book = xlwt.Workbook(encoding='utf-8')
        # 创建一个sheet表单
        sheet1 = work_book.add_sheet('内地疫情明细',cell_overwrite_ok=True)  # date 为表的名字
        sheet2 = work_book.add_sheet('港澳台疫情明细', cell_overwrite_ok=True)
        #表头
        heads1 = ['省份', '新增确诊人数','新增无症状感染人数']
        for i in range(len(heads1)):
            sheet1.write(0, i, heads1[i])  # write(行,列,内容),默认从0开始
        heads2 = ['省份', '累计确诊']
        for i in range(len(heads2)):
            sheet2.write(0, i, heads2[i])
        j=1
        sum1 = 0
        sum2 = 0
        for content1 in dict1.items():#写入内地疫情，用concent迭代字典的每一个键值对，
            # 并在j行的0、1、2列写入省份、确诊人数、无症状感染人数的数据
            sheet1.write(j, 0,content1[0])
            sheet1.write(j, 1, content1[1][0])
            sheet1.write(j, 2, content1[1][1])
            sum1 = sum1 + content1[1][0]
            sum2 = sum2 + content1[1][1]
            j=j+1
        sheet1.write(j, 0, '合计')
        sheet1.write(j, 1, sum1)
        sheet1.write(j, 2, sum2)
        k=1
        for content2 in dict2.items():#写入内地疫情
            sheet2.write(k, 0,content2[0])
            sheet2.write(k, 1, content2[1])
            k=k+1
        # 保存文件
        work_book.save(filename+'.xls')
        print(filename+'写入Excel成功')
def  getMap(fileName,a,b):
    map1 = (  #迭代的z是一个省份和人数的元组，将z转换成list形式，取出省份名称和确诊人数（或无症状感染人数、累计确诊人数），又讲其转换为list列表
        Map(init_opts=opts.InitOpts(width="1500px",height="600px"))
            .add("新增确诊人数", [list((list(z)[0], str(list(z)[1][0])))
                          for z in zip(list(a.keys()), list(a.values()))], "china")
            .add("无症状感染人数", [list((list(z)[0], str(list(z)[1][1])))
                             for z in zip(list(a.keys()), list(a.values()))], "china")
            .add("港澳台累计确诊", [list((list(z)[0], str(list(z)[1])))
                             for z in zip(list(b.keys()), list(b.values()))], "china")
            .set_global_opts(
            title_opts=opts.TitleOpts(title=fileName),
            visualmap_opts=opts.VisualMapOpts(max_=300, split_number=20, is_piecewise=True, ),
        )
    )
    map1.render(fileName + '.html')# 生成到本地网页形式打开
def main():
    for url_main in getpage():  #从第一页开始爬取该页的所有新闻链接

        option = FirefoxOptions()
        option.add_argument("--headless")  # 隐藏浏览器
        browser = Firefox(executable_path='geckodriver', options=option)
        browser.get(url_main)
        time.sleep(3)   #设置等待时间
        data = browser.page_source
        soup = BeautifulSoup(data, "lxml") #创建对象
        url_list = soup.find('div', class_='list').find_all('li')  #找到list中的所有li标签

        for i in url_list:
            url =  'http://www.nhc.gov.cn/' + i.find('a')['href'] #爬取a标签下href的内容,需要加上网址头
            try:
                #接下来爬取单独的网页
                browser.get(url)
                time.sleep(3)

                fileName = getTime(browser.page_source) #时间函数
                definite = getLocal_add(browser.page_source) #本土确诊人数函数
                nosymptom = getNoSymptom_add(browser.page_source) #本土无症状感染人数函数
                HMT_people = getHMT_people(browser.page_source)#港澳台累计确诊
                Midland_people = add_data(definite,nosymptom)
                write_to_excel(fileName, Midland_people,HMT_people)
                getMap(fileName,Midland_people,HMT_people)
                print("------------------------分割线---------------------")
            except Exception:
                print('该页面爬取失败！')
                continue
            time.sleep(3)
        time.sleep(3)
        browser.quit()

main()
