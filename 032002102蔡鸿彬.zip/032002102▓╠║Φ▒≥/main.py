import module
if __name__ == '__main__':
    module.crawler.yqtbCrawler()
    module.visualize.visualize()