
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import json
import numpy as np


with open("D:\python task\list\listdata2.json", "r",encoding='utf-8') as f:
    listdata = f.read()  # 读取文件p
listdata2=json.loads(listdata)

chinaDayList=listdata2['chinaDayList']  #将原数据文本中国记录的疫情数据（字典形式）装入一个数列
i=len(chinaDayList) #计算从开始统计疫情数据到今日为止的天数
china_date=pd.DataFrame()
for n in range(i):
    pd1=pd.DataFrame(data=chinaDayList[n],index=[n],columns=['confirm','dead','heal','nowConfirm','nowSevere','healRate','date'])
    china_date = pd.concat([china_date, pd1])
china_date=china_date.rename(columns={"confirm":"累计确诊","dead":"累计死亡","heal":"累计治愈","nowConfirm":"现有确诊","nowSevere":"本土新增","healRate":"治愈率","date":"日期"})
china_date.tail()
with pd.ExcelWriter('china_data.xlsx') as writer:
    china_date.to_excel(writer)

matplotlib.rcParams['font.sans-serif'] = ['SimHei']
plt.figure(figsize=(10,4),dpi=90)    #调整大小，清晰度
plt.xticks(rotation=70)      #字体倾斜
x=np.array(china_date['日期'])
y=np.array(china_date['累计确诊'])
plt.xticks(range(0,i,4))
plt.plot(x,y)
plt.title('全国疫情累计趋势图')
plt.xlabel("日  期")
plt.ylabel("感 染 人 数")
plt.show()


matplotlib.rcParams['font.sans-serif'] = ['SimHei']
plt.figure(figsize=(10,4),dpi=90)    #调整大小，清晰度
plt.xticks(rotation=70)      #字体倾斜
x=np.array(china_date['日期'])
y=np.array(china_date['本土新增'])
plt.xticks(range(0,i,4))
plt.plot(x,y)
plt.title('全国感染新增趋势图')
plt.xlabel("日  期")
plt.ylabel("感 染 人 数")
plt.show()
