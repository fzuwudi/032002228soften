url1 = "https://view.inews.qq.com/g2/getOnsInfo?name=disease_h5"
url2 = "https://view.inews.qq.com/g2/getOnsInfo?name=disease_other"


import requests
import json

'''
爬取url1
'''
headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36'}
resp=requests.get(url1,headers)   #将爬虫伪装成浏览器
listdata=resp.content.decode()
listdata=listdata.replace("'","\“") #json只能分辨双引号而不能单引号
listdata=json.loads(listdata)["data"]#'data'的value值为我们需要的数据


'''
爬取url2
'''
with open('D:\python task\listdata.json', 'w',encoding='utf-8') as f:
    f.write(listdata)
#得到的数据不符合JSON格式，需要在vscode里补齐各种括号（比如“}”，“]”），而且存到本地后，可以防止爬虫不稳定




resp2=requests.get(url2,headers)
listdata2=resp2.content.decode()
listdata2=listdata2.replace("'","\“")
listdata2=json.loads(listdata2)["data"]

with open('D:\python task\list\listdata2.json', 'w',encoding='utf-8') as f:
    f.write(listdata2)

#得到的数据不符合JSON格式，需要在vscode里补齐各种括号（比如“}”，“]”），而且存到本地后，可以防止爬虫不稳定