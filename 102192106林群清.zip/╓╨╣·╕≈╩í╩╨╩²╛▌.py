

 #导入必要的库函数
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import json
from pyecharts.charts import Map
import pyecharts.options as opts

with open("D:\python task\list\listdata1.json", "r",encoding='utf-8') as f:
    listdata = f.read()  # 读取文件p
listdata1=json.loads(listdata)#把'data'转换成字典类型方便分析

'''
#从文件中读取中国疫情的整体情况
'''

#从文件中读取中国疫情的整体情况
listtime=listdata1['lastUpdateTime']
pd_china=pd.DataFrame()
pd1=pd.DataFrame(listdata1['chinaTotal'],index=['chinaTotal'], columns=['confirm', 'heal','dead','nowConfirm','nowSevere','noInfect'])
pd_china=pd.concat([pd_china,pd1])
pd1=pd.DataFrame(listdata1['chinaAdd'],index=['chinaAdd'], columns=['confirm', 'heal','dead','nowConfirm','nowSevere','noInfect'])
pd_china=pd.concat([pd_china,pd1])
pd_china['lastUpdateTime']=listtime
pd_china=pd_china.rename(columns={"confirm": "累计确诊", "heal": "治愈","dead":"累计死亡","nowConfirm":"现有患者","noInfect":"无症状感染者","lastUpdateTime":"最近更新时间","nowSevere":"重症患者"})
pd_china=pd_china.rename(index={"chinaTotal":"中国累计","chinaAdd":"中国新增"})

with pd.ExcelWriter('中国本土总体情况.xlsx') as writer:
    pd_china.to_excel(writer)  #将数据输出为excel
'''
#获得中国各省市数据
'''


areaTree=listdata1['areaTree']
china_data=areaTree[0]['children']  #获得中国各省市数据
china_data
china_list = []
for a in range(len(china_data)):
    province = china_data[a]['name']   #得到所有的省
    province_list = china_data[a]['children']   #得到每个省的城市列表
    for b in range(len(province_list)):
        city = province_list[b]['name']
        total = province_list[b]['total']
        today = province_list[b]['today']
        china_dict = {}              #将每个城市的信息用字典存储
        china_dict['province'] = province
        china_dict['city'] = city
        china_dict['total'] = total
        china_dict['today'] = today
        china_list.append(china_dict)
china_data = pd.DataFrame(china_list)
china_data['最近更新时间']=listtime

# 定义数据处理函数
def confirm(x):        # 把从上面得到的 'total'或者 'today' (均为字典类型数据) 中'confirm'对应的值输出
    confirm = eval(str(x))['confirm']
    return confirm
def wzz(x):             # 把从上面得到的 'total'或者 'today' (均为字典类型数据) 中'suspect'对应的值输出
    wzz = eval(str(x))['wzz']
    return wzz
def dead(x):              # 把从上面得到的 'total'或者 'today' (均为字典类型数据) 中'dead'对应的值输出
    dead = eval(str(x))['dead']
    return dead
def heal(x):         # 把从上面得到的 'total'或者 'today' (均为字典类型数据) 中'heal'对应的值输出
    heal =  eval(str(x))['heal']
    return heal
# 函数映射
china_data['confirm'] = china_data['total'].map(confirm)
china_data['wzz'] = china_data['total'].map(wzz)
china_data['dead'] = china_data['total'].map(dead)
china_data['heal'] = china_data['total'].map(heal)
china_data['addconfirm'] = china_data['today'].map(confirm)
china_data = china_data[["province","city","confirm","wzz","dead","heal","addconfirm"]]
china_data=china_data.rename(columns={"province":"省份","city":"城市","confirm":"累计感染","wzz":"无症状感染者","dead":"死亡","heal":"治愈","addconfirm":"新增感染"})

china_data['最近更新时间']=listtime
china_data=china_data[-china_data.城市.isin(["境外输入"])]  #消除各省市“境外输入”的行

with pd.ExcelWriter('中国各省情况表.xlsx') as writer:
    china_data.to_excel(writer)                    #输出到excel

'''
#计算各省感染的总人数，并绘制柱状图
'''
area_data = china_data.groupby("省份")["累计感染"].sum().reset_index()
area_data.columns = ["省份","累计感染"]
# print('\n各省份感染总人数比较\n')
# print(area_data )
matplotlib.rcParams['font.sans-serif'] = ['SimHei']  # 用黑体显示中文
# 绘图
plt.figure(figsize = (10,8),dpi=100)  #调整图像大小与像素
plt.bar(x=0,bottom=area_data['省份'],height=0.5,width=area_data['累计感染'],orientation='horizontal',label='人数',color='red',alpha=0.5 )

#在柱状图上显示具体数值, ha参数控制水平对齐方式, va控制垂直对齐方式
for x1, yy in zip(area_data['累计感染'], area_data['省份']):
  plt.text(x1+1, yy , str(x1),  va='center', fontsize=10, rotation=0)
# 设置标题
plt.title("各省感染总人数情况")
# 为两条坐标轴设置名称
plt.xlabel("感染人数")
plt.ylabel("省份")
# 显示图例
plt.legend(loc="upper right")
plt.show()
plt.close()

'''
#绘制中国疫情累计感染分布图
'''

privince=[]
columns=[]
x=[]   # 把各省感染人数与各省对应
for i in range(len(area_data)):
    privince.append(area_data.loc[i]['省份'])
    columns.append(int(area_data.loc[i]['累计感染']))
for z in zip(list(privince), list(columns)):
    list(z)
    x.append(z)
area_map = Map()
area_map.add("中国疫情感染人数分布图",x, "china",is_map_symbol_show=False)
area_map.set_global_opts(title_opts=opts.TitleOpts(title="中国疫情累计感染人数分布地图"),visualmap_opts=opts.VisualMapOpts(is_piecewise=True,
              pieces=[
                    {"min": 1500, "label": '>10000人', "color": "#6F171F"},
                    {"min": 500, "max": 15000, "label": '500-1000人', "color": "#C92C34"},
                    {"min": 100, "max": 499, "label": '100-499人', "color": "#E35B52"},
                    {"min": 10, "max": 99, "label": '10-99人', "color": "#F39E86"},
                    {"min": 1, "max": 9, "label": '1-9人', "color": "#FDEBD0"}]))
area_map.render_notebook() #输出到render。html
print("结束")

