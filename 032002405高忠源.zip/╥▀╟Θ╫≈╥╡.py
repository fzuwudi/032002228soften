import requests
import re
import xlwt
from bs4 import BeautifulSoup
import uagant
from selenium import webdriver

driver = webdriver.Edge() # 获取动态cookie
driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
    "source": """
    Object.defineProperty(navigator, 'webdriver', {
      get: () => undefined
    })
  """
})
driver.get('http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml')
Cookie = driver.get_cookies()
strr = ''
for c in Cookie:
    strr += c['name']
    strr += '='
    strr += c['value']
    strr += ';'
full_cookie = strr

ua = uagant.get_ua()

url_1 = "http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml"
headers1 = {
    "user_agent": ua,
    "cookie": full_cookie
}
headers2 = {
    "user_agent": ua,
    "cookie": full_cookie
}

resp_1 = requests.get(url_1, headers=headers1)
resp_1.encoding = 'utf-8'
page = BeautifulSoup(resp_1.text, "html.parser")
table = page.find("div", class_="list")
time = table.find_all("span") # 获取日期
web = table.find_all("a")  # 获得一整页的网址

col = []
data_list = []
web_list = []
for it in web:  # 找出一整页的数据

    result_1 = "http://www.nhc.gov.cn" + it.get("href")  # 获取完整的网址
    url_2 = result_1
    resp_2 = requests.get(url_2, headers=headers2)
    page_2 = resp_2.text
    web_list.append(page_2)  # 把一整页的子页面的源代码爬下来

for j in range(0, len(web_list)):
    if(j>19):
        break
    col.clear()
    data_list.clear()
    i = web_list[j]
# 本土确诊
    obj_2 = re.compile(r'本土病例.*?16pt;">(?P<bentunum>.*?)</span>', re.S)  # 本土病例
    bentu_result = obj_2.search(i)
    print("本土病例", bentu_result.group("bentunum"))
    col.append("本土病例")
    data_list.append(bentu_result.group("bentunum"))

    obj_3 = re.compile(r'本土病例.*?</span>(?P<data>.*?)例），含', re.S)  # 截取整块的各个省份的数据
    data_result = obj_3.search(i)

    obj_4 = re.compile(r'例.(?P<province>.*?)<span .*?16pt;">(?P<pnum>.*?)</span>', re.S)  # 分解出各个省份数据
    other_result = obj_4.finditer(data_result.group("data"))
    for it_2 in other_result:
        print(it_2.group("province"), it_2.group("pnum"))  # 本土确诊
        col.append(it_2.group("province"))
        data_list.append(it_2.group("pnum"))

    # 无症状感染者
    print("无症状感染者")
    obj_6 = re.compile(r'新增无症状感染者.*?</span>.*?</span>(?P<data>.*?)例）。', re.S)  # 截取本土无症状的整块数据
    data_result = obj_6.search(i)

    obj_7 = re.compile(r'例.(?P<province>.*?)<span .*?16pt;">(?P<pnum>.*?)</span>', re.S)  # 分解出各个省份数据
    other_result = obj_7.finditer(data_result.group("data"))
    for it_2 in other_result:
        print(it_2.group("province"), it_2.group("pnum"))  # 本土无症状
        col.append(it_2.group("province"))
        data_list.append(it_2.group("pnum"))

    # 港澳台
    obj_gangao = re.compile(r'其中，香港特别行政区<span .*?16pt;">(?P<gangao>.*?)</span>', re.S)
    gangao_result = obj_gangao.search(i)
    print("香港特别行政区", gangao_result.group("gangao"))
    col.append("香港特别行政区")
    data_list.append(gangao_result.group("gangao"))

    obj_gangao = re.compile(r'澳门特别行政区<span .*?16pt;">(?P<gangao>.*?)</span>', re.S)
    gangao_result = obj_gangao.search(i)
    print("澳门特别行政区", gangao_result.group("gangao"))
    col.append("澳门特别行政区")
    data_list.append(gangao_result.group("gangao"))

    obj_gangao = re.compile(r'台湾地区<span .*?16pt;">(?P<gangao>.*?)</span>', re.S)
    gangao_result = obj_gangao.search(i)
    print("台湾地区", gangao_result.group("gangao"))
    col.append("台湾地区")
    data_list.append(gangao_result.group("gangao"))
# 导出到execl
    book = xlwt.Workbook(encoding='utf-8', style_compression=0)

    sheet = book.add_sheet('test')
    sheet.write(0, 0, "日期")
    for i3 in range(0, len(col)):
        sheet.write(0, i3 + 1, col[i3])
    for i3 in range(0, len(time)):
        sheet.write(i3 + 1, 0, time[i3].text)
    for i3 in range(0, len(data_list)):
        sheet.write(j + 1, i3 + 1, data_list[i3])

    savepath = 'D:\python\数据\execl表格.xls'
    book.save(savepath)




