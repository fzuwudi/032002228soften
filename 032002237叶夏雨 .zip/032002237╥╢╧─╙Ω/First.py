import requests
import re
import json
import xlsxwriter
import xlrd2
from pyecharts.charts import Bar
from pyecharts.globals import ThemeType
from pyecharts import options as opts  #生成图表的配置
import cProfile
def main():
    URL="https://voice.baidu.com/act/newpneumonia/newpneumonia/?from=osari_aladin_banner"
    headers={
        # 浏览器基本信息
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.42'
    }           #伪装

    response = requests.get(url=URL, headers = headers)      #发送请求
    data_html = response.text    #获取数据
    json_s = re.findall('"component":\[(.*)\],', data_html)[0]  #解析数据
    json_d =json.loads(json_s)     # 类型转换，json字符串转换成python字典

    summaryDataIn = json_d['summaryDataIn']
    workbook = xlsxwriter.Workbook('疫情数据统计.xlsx') # 创建一个excel文件
    worksheet = workbook.add_worksheet('')  #创建工作表
    worksheet.write(0, 2, '省份')
    worksheet.write(0, 3, '新增确诊')
    worksheet.write(0, 4, '新增无症状感染')
    worksheet.write(0, 0, '大陆新增确诊')
    worksheet.write(0, 1, '大陆新增无症状')
    worksheet.write(1, 0, summaryDataIn['unOverseasInputNewAdd']) #大陆新增确诊
    worksheet.write(1, 1, summaryDataIn['asymptomaticLocalRelative'])#大陆新增无症状
    List = json_d['caseList']  # 字典中嵌套的列表
    row = 1
    for elem in List:
        area = elem['area']         #省份
        nativeRelative = elem['nativeRelative']  #新增确诊
        asymptomaticLocalRelative = elem['asymptomaticLocalRelative'] #新增无症状感染
        asymptomaticRelative = elem['asymptomaticRelative']
        confirmedRelative =elem['confirmedRelative']
        worksheet.write(row, 2, area)   #导入到excel表格
        worksheet.write(row, 3,nativeRelative) #导入到excel表格
        worksheet.write(row, 4, asymptomaticLocalRelative) #导入到excel表格
        if row==2 or row==4 or row==5:
            worksheet.write(row, 3, confirmedRelative)  # 导入到excel表格
            worksheet.write(row, 4, asymptomaticRelative)  # 导入到excel表格
        row += 1
    workbook.close()

    #数据可视化
    data = xlrd2.open_workbook('疫情数据统计.xlsx')
    table = data.sheets()[0]
    areas = []
    nativeRelatives = []
    asymptomaticLocalRelatives = []
    for i in range(1,35):
        # if i == 4:
        #     continue
        area = table.row_values(i)[2]
        areas.append(area)
        nativeRelative = table.row_values(i)[3] #新增确诊
        nativeRelatives.append(nativeRelative)
        asymptomaticLocalRelative = table.row_values(i)[4] #新增无症状感染
        asymptomaticLocalRelatives.append(asymptomaticLocalRelative)
    areas.append(table.row_values(0)[0])
    nativeRelatives.append(table.row_values(1)[0]) #大陆新增确诊
    areas.append(table.row_values(0)[1])
    asymptomaticLocalRelatives.append(table.row_values(1)[1]) #大陆新增无症状

    bar = Bar(
        init_opts=opts.InitOpts(
        theme=ThemeType.DARK,
        width="1300px",
        height='650px'),
    )    #柱状图
    bar.add_xaxis(areas) #x轴

    bar.add_yaxis('新增确诊',nativeRelatives)   #y轴
    bar.add_yaxis('新增无症状',asymptomaticLocalRelatives)
    bar.set_global_opts(
        toolbox_opts=opts.ToolboxOpts(),#允许切换折线/堆叠/柱状
        datazoom_opts=[opts.DataZoomOpts()],#柱状图带窗口滑块效果
        xaxis_opts=opts.AxisOpts(axislabel_opts={"rotate":25})# 倾斜x轴，解决显示不全的问题
        )
    bar.render_notebook()
    bar.render('可视化.html')

if __name__ == '__main__':
    main()

