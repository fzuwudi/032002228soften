import re

import requests
from bs4 import BeautifulSoup

#判断是否属于31个省份中的一个
def City(city):
    #城市列表
    Province = ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东', '河南', '湖北', '湖南', '广东', '海南',
            '四川', '贵州', '云南', '陕西', '甘肃', '青海', '内蒙古', '广西', '西藏', '宁夏', '新疆', '北京', '天津', '上海', '重庆']
    return Province.count(city)


def getHTMLText(url):
    headers = {
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36',
        'cookie': 'yfx_c_g_u_id_10006654=_ck22090522142012772195013675521; insert_cookie=91349450; sVoELocvxVW0T=53SLtWCWFkrGqqqDkoM.jsAZXMs6MhV.QZa11hGaT2WGOmdmbQqXyFwxwA5NVcVfTkKGlER3Dd6vQsNF5amRhMXc7J_OUPFnYVificZMQK6xVWl1ctTvqTt4rLiFXDE7VmEn5rL4AyublPKFq3g9BjDnzYtEoWDxRNoRHD_Sn8Rj4HKSdnhqxl6ROfWh6MTd8K6dEDHEb4gnyeRJFpdrtxyksCsio_.yfYkcnlBDuQIuJw56myw88jF69mZPhTPbqqCX0m712pPcQUWdiZyA0naC10516Av7oToUwG6W34anJJ_fsy5CCuI0238DzjfIS9MLDlR11VQ_zIvawe9egU31TD8.bX.kGoAwEC1zqW_3A; yfx_f_l_v_t_10006654=f_t_1662387260271__r_t_1662686249486__v_t_1662686249486__r_c_2; security_session_verify=89607556861ac76924e5df4695f3c6bd'
       # 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36 Edg/105.0.1343.27'
    }
    try:
        r = requests.get(url=url, headers=headers, timeout=30)
        r.raise_for_status()
        r.encoding = r.apparent_encoding
        return r.text
    except:
        return "产生异常"

def main():
    fp  = open('./本土新增确诊人数.txt','w',encoding='utf-8')
    fp2 = open('./本土新增无症状感染人数.txt','w',encoding='utf-8')
    fp3 = open('./港澳台累计确诊.txt', 'w', encoding='utf-8')
    Str = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd'
    for i in range(1, 43):
        if i == 1:
            str2 = Str
        else:
            str2 = Str + '_' + str(i)
        url = str2 + '.shtml'
        page_text = getHTMLText(url)
        soup = BeautifulSoup(page_text,'lxml')
        # 解析每日数据和详情页url
        li_list = soup.select('.zxxx_list >  li')
        for li in li_list:
            title = li.a.string
            if title[0:9] == '国务院联防联控机制' or title[0:6] == '[武汉发布]' or title == '湖北省武汉市新冠肺炎疫情数据订正情况':
                continue

            detail_url = 'http://www.nhc.gov.cn/' + li.a['href']
            # 对详情页发起请求，解析出新链接内容
            detail_page_text = getHTMLText(detail_url)
            # 匹配发布时间
            detail_time = re.findall('20[0-9][0-9]-[0-9][0-9]-[0-9][0-9]',detail_page_text)[-1]
            # 解析子网页
            detail_soup = BeautifulSoup(detail_page_text, 'lxml')
            div_tag = detail_soup.find('div', class_='con', id='xw_box')
            fp.write(detail_time + ':')
            fp2.write(detail_time + ':')

            # 获取子网页文本内容
            Content = div_tag.text
            # 以下是国家卫健委对于新增病例的8种描述：
            # 1 本土病例5例（上海3例，内蒙古1例，辽宁1例）    2022-06-19
            # 2 本土病例6例，均在北京 2020-06-13
            # 3 其中10例为本土病例（湖北5例，吉林3例，辽宁1例，黑龙江1例）  2020-05-11
            # 4 新增确诊病例4例，均为本土病例（均在吉林）  2020-05-15
            # 5 新增病例17例，无死亡病例。
            # 6 新增确诊病例119例，        （此时还没有境外输入，所以都是属于本土） 2020-03-04
            # 7 新增新型冠状病毒感染的肺炎确诊病例77例（湖北省72例，上海市2例，北京市3例）  2020-01-21
            # 8 新型冠状病毒感染的肺炎病例41例    2020-01-11

            describe = -1  # describe = i表示描述i的匹配
            describe_list = ['本土病例[0-9]{1,10}例（.*?）',
                             '本土病例[0-9]{1,10}例，均在[\u4e00-\u9fa5]{2,3}',
                             '[0-9]{1,10}例为本土病例（.*?）',
                             '新增确诊病例[0-9]{1,10}例，均为本土病例',
                             '新增病例[0-9]{1,10}例',
                             '新增确诊病例[0-9]{1,10}例',
                             '新增新型冠状病毒感染的肺炎确诊病例[0-9]{1,10}例（.*?）',
                             '新型冠状病毒感染的肺炎病例[0-9]{1,10}例'
                             ]

            for j in range(0, 8):
                pattern = describe_list[j]
                if describe == -1:
                    try:
                        new_confirmed = re.findall(pattern, Content)[0]
                        describe = j
                    except:
                        pass


            # 排除类似‘新增确诊病例19例，均为境外输入病例’
            # 新增确诊病例1例，为境外输入病例（在广东）  2020-06-04
            # 无新增新型冠状病毒感染的肺炎病例 2020-01-15
            try:
                other_country = re.findall('新增确诊病例[0-9]{1,10}例，均为境外输入病例',Content)[0]
                describe = -1
            except:
                pass
            try:
                other_country = re.findall('新增确诊病例[0-9]{1,10}例，为境外输入病例',Content)[0]
                describe = -1
                # new_confirmed = '无新增确诊'
            except:
                pass
            try:
                is_new = re.findall('无新增新型冠状病毒感染的肺炎病例',Content)[0]
                describe = -1
                # new_confirmed = '无新增确诊'
            except:
                pass

            if describe == -1:
                new_confirmed = '无新增确诊'

            # 处理描述6的详细信息
            if describe == 5:
                try:
                    detail_msg = re.findall('湖北新增确诊病例[0-9]{1,10}例',Content)[0]
                    new_confirmed = new_confirmed + '，' + detail_msg
                except:
                    pass





            # 本土新增无症状人数处理
            try:
                new_asymptomatic = re.findall('本土[0-9]{1,10}例（.*?）',Content)[0]
            except:
                new_asymptomatic = '无新增无症状'




            new_asymptomatic = str(new_asymptomatic)
            new_confirmed = str(new_confirmed)
            fp.write(new_confirmed + '\n')
            fp2.write(new_asymptomatic + '\n')

            # 爬取港澳台
            # 两种描述
            success = 0
            Hongkong = ''
            Macao = ''
            Taiwan = ''
            pattern2 = [
                '中国香港[0-9]{1,10}例',
                '中国澳门[0-9]{1,10}例',
                '中国台湾[0-9]{1,10}例',
                '香港特别行政区[0-9]{1,10}例',
                '澳门特别行政区[0-9]{1,10}例',
                '台湾地区[0-9]{1,10}例',
            ]
            for k in range(0, 2):
                if success == 0:
                    try:
                        Hongkong = re.findall(pattern2[0 + k * 3], Content)[0]
                        Macao = re.findall(pattern2[1 + k * 3], Content)[0]
                        Taiwan = re.findall(pattern2[2 + k * 3], Content)[0]
                        success = 1
                        if k == 0:
                            Hongkong = '香港特别行政区' + re.findall('[0-9]{1,10}', Hongkong)[0] + '例'
                            Macao = '澳门特别行政区' + re.findall('[0-9]{1,10}', Macao)[0] + '例'
                            Taiwan = '台湾地区' + + re.findall('[0-9]{1,10}', Taiwan)[0] + '例'
                    except:
                        pass
            # 2020-01-26特殊处理  香港特别行政区5例，澳门特别行政区2例，中国台湾3例
            if detail_time == '2020-01-26':
                fp3.write(detail_time + ':香港特别行政区5例，澳门特别行政区2例，台湾地区3例\n')
                print(title, '爬取成功！')
                continue
            # 2020-01-22以后都不是0例
            timeSplit = detail_time.split('-')
            if timeSplit[0] >= '2020' and (timeSplit[1] > '01' or (timeSplit[1] == '01' and timeSplit[2] > '22'))  and success == 0:
                continue

            fp3.write(detail_time + ':')
            if success == 1:
                fp3.write(Hongkong + '，' + Macao + '，' + Taiwan + '\n')
            else:
                fp3.write('香港特别行政区0例，澳门特别行政区0例，台湾地区0例\n')

            print(title, '爬取成功！')
main()
