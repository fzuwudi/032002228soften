import xlrd
from pyecharts import options as opts
from pyecharts.charts import Geo
from pyecharts.globals import ChartType

def main():
    data= xlrd.open_workbook('./所有省份新增确诊人数.xls')
    data2 = xlrd.open_workbook('./大陆新增确诊及无症状人数.xls')


    table = data.sheets()[0]     # 打开各省详细确诊数据的第一张表
    table2 = data2.sheets()[0]   # 打开大陆确诊总数的第一张表


    # 读入第一列作为时间,其中Time[0] = '时间'
    Time = table.col_values(0)
    # 读入第一行省份
    Province = table.row_values(0)
    # 读入大陆土新增确诊人数
    total = table2.col_values(1)
    for row_idx in range(1, len(Time)):
        Total = int(total[row_idx])
        z = []
        rowi = table.row_values(row_idx)   # rowi[0]是时间，后面是疫情数据
        for col_idx in range(1, len(Province)):

           # idx为列索引的位置
            if rowi[col_idx] == 0:
                continue
            tmp_tuple = (Province[col_idx], rowi[col_idx])
            z.append(tmp_tuple)

        path = './所有省份新增确诊一览/' + Time[row_idx] + "所有省份新增确诊人数.html"
        geo = (
            Geo(init_opts=opts.InitOpts(width="1900px",height="910px", bg_color='pink', page_title=Time[row_idx] + "所有省份新增确诊人数"))
                .add_schema(maptype="china" )
                .add(
                "新增省份",
                z,
                type_=ChartType.EFFECT_SCATTER,
            )
                .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
                .set_global_opts(title_opts=opts.TitleOpts(title=Time[row_idx] + "所有省份新增确诊人数",pos_left="center",
                                                           subtitle = '今日中国大陆新增确诊人数：' + str(Total),
                                                           title_textstyle_opts=opts.TextStyleOpts(font_size=50)),
                                 legend_opts=opts.LegendOpts(pos_right="28%", pos_bottom="32%", is_show=True),
                                 visualmap_opts=opts.VisualMapOpts(max_=2000, pos_left="10%",pos_bottom="10%")
                                 )

                .render(path)
        )
main()