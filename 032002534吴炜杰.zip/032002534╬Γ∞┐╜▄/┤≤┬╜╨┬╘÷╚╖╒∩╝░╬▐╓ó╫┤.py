import xlwt
import os
import re
dataset = xlwt.Workbook(encoding='utf-8',style_compression=0)
sheet = dataset.add_sheet('大陆新增确诊及无症状人数',cell_overwrite_ok=True)
col = ('时间','大陆土新增确诊人数','大陆新增无症状感染人数')
for i in range(0,3):
		sheet.write(0,i,col[i])

times = []  # 时间
data1 = []  # 大陆土新增确诊人数
data2 = []  # 大陆新增无症状感染人数

f1 = open('本土新增确诊人数.txt',encoding='utf-8')
f2 = open('本土新增无症状感染人数.txt',encoding='utf-8')

# 读取时间和大陆新增确诊人数
lines = f1.readline()
# 判断重复
repeattime = ''
while lines:
	Times = re.findall('20[0-9][0-9]-[0-9][0-9]-[0-9][0-9]',lines)[0]
	times.append(Times)

	if repeattime == Times:
		print(Times)
	repeattime = Times


	try:
		Data1 = re.findall('[0-9]{1,10}例',lines)[0]
		Data1 = Data1.strip('例')
	except:
		Data1 = '0'
	data1.append(Data1)
	lines = f1.readline()


lines = f2.readline()

# 读取大陆新增无症状
while lines:
	try:
		Data2 = re.findall('土\d.*?例',lines)[0]
		# 剃掉首尾的中文，只保留数字
		Data2 = Data2.strip('例')
		Data2 = Data2.strip('土')
	except:
		Data2 = '0'
	data2.append(Data2)
	lines = f2.readline()
f1.close()
f2.close()

times.reverse()
data1.reverse()
data2.reverse()




for i in range(0, len(times)):
	sheet.write(i + 1, 0, times[i])
	sheet.write(i + 1, 1, eval(data1[i]))
	sheet.write(i + 1, 2, eval(data2[i]))

dataset.save('./大陆新增确诊及无症状人数.xls')
