import re
import xlwt

#省份列表
Province = ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建',
                '江西', '山东', '河南', '湖北', '湖南', '广东', '海南','四川', '贵州',
                '云南', '陕西', '甘肃', '青海', '内蒙古', '广西', '西藏', '宁夏', '新疆',
                '北京', '天津', '上海', '重庆']
# 构造31个空列表
cityList = []
times = []
for i in range(0, len(Province)):
    cityList.append([])
# 读入文件
f = open('本土新增无症状感染人数.txt',encoding='utf-8')
lines = f.readline()
while lines:

    # 匹配时间
    Times = re.findall('20[0-9][0-9]-[0-9][0-9]-[0-9][0-9]', lines)[0]
    times.append(Times)

    # 还未匹配,先让各省当日新增无症状等于0
    for i in range(0, len(Province)):
        cityList[i].append(0)

    situation_list = re.findall('[\u4e00-\u9fa5]{2,3}[0-9]{1,10}例', lines)
    allIn = re.findall('（均在', lines)
    # 匹配不到无症状，continue
    # len(situation_list) = 0
    # situation_list 类似['本土2例''辽宁1例'，'安徽1例']
    if situation_list == []:
        lines = f.readline()
        continue
    # 排除以下两种情况
    # 2022-01-15:本土2例（均在广东，其中广州市1例、珠海市1例）
    # 2022-01-18:本土1例（在辽宁大连市）
    # 匹配 '(均在'

    elif len(situation_list) == 1 or len(allIn) == 1:
        detail_num = re.findall('[0-9]{1,10}',situation_list[0])[0]
        detail_pro = re.findall('在[\u4e00-\u9fa5]{2,3}', lines)[0]
        detail_pro = detail_pro.strip('在')
        # 处理除了黑龙江的三个字，如广东珠海市的‘广东珠’,或者湖北省变湖北
        if len(detail_pro) == 3 and Province.count(detail_pro) == 0:
            detail_pro = detail_pro[0:2]
        if Province.count(detail_pro) == 1:
            idx = Province.index(detail_pro)
            # 把该省份列表最后一个值改为detail_num
            if cityList[idx][-1] == 0:
                cityList[idx][-1] = eval(detail_num)


    else:
        # situation_list[0]是'本土X例'
        for i in range(1, len(situation_list)):
            item = situation_list[i]
            # item的省份
            #detail_pro = re.findall('[\u4e00-\u9fa5]{2,3}[0-9]{1,10}例', item)[0]
            detail_pro = re.findall('[\u4e00-\u9fa5]{2,3}', item)[0]
            # item的数据
            detail_num = re.findall('[0-9]{1,10}',item)[0]
            # 判断detail_pro在不在31个省份中
            # 处理除了黑龙江的三个字，如广东珠海市的‘广东珠’,或者湖北省变湖北
            if len(detail_pro) == 3 and Province.count(detail_pro) == 0:
                detail_pro = detail_pro[0:2]
            if Province.count(detail_pro) == 1:
                idx = Province.index(detail_pro)
                # 把该省份列表最后一个值改为detail_num
                if cityList[idx][-1] == 0:
                    cityList[idx][-1] = eval(detail_num)

    lines = f.readline()

f.close()


# 反转各列表
times.reverse()
for i in range(0, len(Province)):
    cityList[i].reverse()


# 数据写入excel
dataset = xlwt.Workbook(encoding='utf-8',style_compression=0)
sheet = dataset.add_sheet('大陆各省份新增无症状',cell_overwrite_ok=True)
# 写入标签
sheet.write(0, 0, '时间')
for i in range(0, len(Province)):
    sheet.write(0, i + 1, Province[i])
# 写入数据
for i in range(0, len(times)):
    for j in range(0, len(Province) + 1):
        if j == 0:
            sheet.write(i + 1, j, times[i])
        else:
            sheet.write(i + 1, j, cityList[j - 1][i])

dataset.save('./大陆各省份新增无症状.xls')