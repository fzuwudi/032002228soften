import cProfile
import pstats
import 可视化处理各省新增无症状

cProfile.run('可视化处理各省新增无症状.main()','restats')

q = pstats.Stats('restats')
q.sort_stats('cumulative').print_stats(10)