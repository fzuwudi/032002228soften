import re
import xlwt
import xlrd
from xlutils.copy import copy

#省份列表
Province = ['河北', '山西', '辽宁', '吉林', '黑龙江', '江苏', '浙江', '安徽', '福建',
                '江西', '山东', '河南', '湖北', '湖南', '广东', '海南','四川', '贵州',
                '云南', '陕西', '甘肃', '青海', '内蒙古', '广西', '西藏', '宁夏', '新疆',
                '北京', '天津', '上海', '重庆']
# 构造31个空列表
cityList = []
for i in range(0, len(Province)):
    cityList.append([])
# 读入文件
f = open('本土新增确诊人数.txt',encoding='utf-8')


# 共以下几种描述：
# 1 本土病例350例（海南300例，广东25例，内蒙古16例，吉林2例，福建2例，重庆2例，广西1例，四川1例，西藏1例）111
# 2 本土病例1807例（吉林1412例，其中长春市831例、吉林市571例、延边朝鲜族自治州9例、
#        四平市1例；江苏23例，均在连云港市；湖南1例，在湘潭市）111
# 3 本土病例6例（均在广东）111
# 4 本土病例1例（在安徽）  1111
# 5 本土病例5例（安徽3例，辽宁2例）111
# 6 6例为本土病例（黑龙江5例，广东1例）    6例为本土病例（均在吉林） 比较特殊 111
# 7 1例为本土病例（在山西）111
# 8 新增确诊病例15例，湖北新增确诊病例8例
# 9 新增确诊病例2590例 111
# 10 新增新型冠状病毒感染的肺炎确诊病例77例（湖北省72例，上海市2例，北京市3例） 111
# 11 新型冠状病毒感染的肺炎病例45例 111
# 12 无新增确诊 111


lines = f.readline()
while lines:
    detail_pro = ''
    detail_num = ''
    # 还未匹配,先让各省当日新增无症状等于0
    for i in range(0, len(Province)):
        cityList[i].append(0)

    # 单独处理类似  ’新增确诊病例15152例，湖北新增确诊病例14840例‘
    isHuBei = re.findall('新增确诊病例\d.*?例，湖北新增确诊病例\d.*?例',lines)
    if len(isHuBei) == 1:
        detail_pro = '湖北'
        detail_num = re.findall('[0-9]{1,10}', isHuBei[0])[1]
        idx = Province.index(detail_pro)
        cityList[idx][-1] = eval(detail_num)




    situation_list = re.findall('[\u4e00-\u9fa5]{2,3}[0-9]{1,10}例', lines)
    allIn = re.findall('（均?在', lines)
    # 匹配不到无症状，continue
    # len(situation_list) = 0
    # situation_list 类似['本土2例''辽宁1例'，'安徽1例']
    if situation_list == [] and len(allIn) == 0:
        lines = f.readline()
        continue
    # 排除以下两种情况
    # 2022-01-15:本土2例（均在广东，其中广州市1例、珠海市1例）
    # 2022-01-18:本土1例（在辽宁大连市）
    # 匹配 '(均在'

    elif len(situation_list) == 1 or len(allIn) == 1:
        # 排除  6例为本土病例（均在吉林） 即len(situation_list) = 0， len(allIn) = 1
        if len(situation_list) == 0:
            situation_list = re.findall('[0-9]{1,10}例',lines)
        detail_num = re.findall('[0-9]{1,10}',situation_list[0])[0]
        try:
            detail_pro = re.findall('在[\u4e00-\u9fa5]{2,3}', lines)[0]
            detail_pro = detail_pro.strip('在')
        except:
            # 匹配不到说明是在其他，可能是疫情初期发布的信息，暂时归为湖北
            detail_pro = '湖北'
            detail_num = re.findall('[0-9]{1,10}',lines)[-1]
        # 处理除了黑龙江的三个字，如广东珠海市的‘广东珠’
        if len(detail_pro) == 3 and Province.count(detail_pro) == 0:
            detail_pro = detail_pro[0:2]
        if Province.count(detail_pro) == 1:
            idx = Province.index(detail_pro)
            # 把该省份列表最后一个值改为detail_num
            if cityList[idx][-1] == 0:
                cityList[idx][-1] = eval(detail_num)



    else:
        # situation_list[0]是'本土X例' 所以索引从1开始
        # 4例为本土病例（黑龙江3例，广东1例） 改情况索引从0开始
        # 判断是哪种情况，然后选择begin的值
        begin = 1
        flag_list = re.findall('\d.*?例为本土病例',lines)
        if len(flag_list) == 1:
            begin = 0
        for i in range(begin, len(situation_list)):
            item = situation_list[i]
            # item的省份
            #detail_pro = re.findall('[\u4e00-\u9fa5]{2,3}[0-9]{1,10}例', item)[0]
            detail_pro = re.findall('[\u4e00-\u9fa5]{2,3}', item)[0]
            # item的数据
            detail_num = re.findall('[0-9]{1,10}',item)[0]
            # 判断detail_pro在不在31个省份中
            if len(detail_pro) == 3 and Province.count(detail_pro) == 0:
                detail_pro = detail_pro[0:2]
            if Province.count(detail_pro) == 1:
                idx = Province.index(detail_pro)
                # 把该省份列表最后一个值改为detail_num
                if cityList[idx][-1] == 0:
                    cityList[idx][-1] = eval(detail_num)

    lines = f.readline()

f.close()



# 反转各列表
for i in range(0, len(Province)):
    cityList[i].reverse()


# 数据写入excel
dataset = xlrd.open_workbook('所有省份新增确诊人数.xls',formatting_info=True)
wb = copy(dataset)
sheet = wb.get_sheet(0)
# dataset = xlwt.Workbook(encoding='utf-8',style_compression=0)
# sheet = dataset.add_sheet('大陆各省份新增无症状',cell_overwrite_ok=True)
# 写入标签
for i in range(0, len(Province)):
    sheet.write(0, i + 4, Province[i])
# 写入数据
for i in range(0, len(Province)):
    for j in range(0, len(cityList[0])):
        sheet.write(j + 1, i + 4, cityList[i][j])

wb.save('./所有省份新增确诊人数.xls')