import asyncio
from bs4 import BeautifulSoup
import re
from pyppeteer import launcher
import xlwings as xw
launcher.DEFAULT_ARGS.remove("--enable-automation")
from pyppeteer import launch


async def pyppteer_fetchUrl(url):
    #网上学习使用pyppeteer避免反爬
    browser = await launch({'headless': False, 'dumpio': True, 'autoClose': True})
    page = await browser.newPage()
    await page.goto(url, timeout=30000)
    await asyncio.wait([page.waitForNavigation()])
    str = await page.content()
    await browser.close()
    return str


wb = xw.Book()  # 相当于打开excel操作
sht = wb.sheets('sheet1')  # 相当于在excel里加了一个工作表


def fetchUrl(url):

    return asyncio.get_event_loop().run_until_complete(pyppteer_fetchUrl(url))


def getPageUrl():
#获取网页链接
    #yield 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
#   抓取多个网页

    for page in range(1,3):#3可以为为任意数
        if page == 1:
            yield 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd.shtml'
        else:
            url = 'http://www.nhc.gov.cn/xcs/yqtb/list_gzbd_' + str(page) + '.shtml'

            yield url



def getTitleUrl(html):
#获取标题，链接，时间
    bsobj = BeautifulSoup(html, 'html.parser')
    titleList = bsobj.find('div', attrs={"class": "list"}).ul.find_all("li")
    for item in titleList:
        link = "http://www.nhc.gov.cn" + item.a["href"]
        title = item.a["title"]
        date = item.span.text
        yield title, link, date


def getContent(html):
#通过html得到网页文本
    bsobj = BeautifulSoup(html, 'html.parser')
    cnt = bsobj.find('div', attrs={"id": "xw_box"}).find_all("p")
    s = ""
    if cnt:
        for item in cnt:
            s += item.text
        return s

    return "爬取失败！"


if "__main__" == __name__:

    for url in getPageUrl():
        s = fetchUrl(url)
        i = 0
        for title, link, date in getTitleUrl(s):
            print(title, link)
            sht.range(f'A{i + 1}').value = title
            i = i + 1
            html = fetchUrl(link)
            #存入Excel
            sht.range(f'A{i + 1}').value = '地区'
            sht.range(f'B{i + 1}').value = '新增本土'
            sht.range(f'C{i + 1}').value = '新增无症状'
            i = i + 1
            content = getContent(html)
            #分析数据
            td_demostic_num = re.search('本土病例(.*?)例', content).group(1)#正则分析
            newinc_demostic = re.search('本土病例(.*?)。', content).group(1)
            newincwzz = re.search('新增无症状感染者(.*?)。', content).group(1)
            new_wzz_num = re.search('本土(\d+)例', newincwzz).group(1)

            sht.range(f'A{i + 1}').value = '中国'
            sht.range(f'B{i + 1}').value = td_demostic_num
            sht.range(f'C{i + 1}').value = new_wzz_num
            i=i+1


            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '福建'
            #抓取数据
            if re.search('福建(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('福建(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('福建(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('福建(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '四川'
            if re.search('四川(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('四川(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('四川(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('四川(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '山西'
            if re.search('山西(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('山西(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('山西(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('山西(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '辽宁'
            if re.search('辽宁(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('辽宁(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('辽宁(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('辽宁(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '吉林'
            if re.search('吉林(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('吉林(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('吉林(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('吉林(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '黑龙江'
            if re.search('黑龙江(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('黑龙江(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('黑龙江(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('黑龙江(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '江苏'
            if re.search('江苏(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('江苏(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else: sht.range(f'B{i + 1}').value = '0'
            if re.search('江苏(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('江苏(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '浙江'
            if re.search('浙江(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('浙江(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('浙江(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('浙江(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '安徽'
            if re.search('安徽(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('安徽(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('安徽(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('安徽(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '江西'
            if re.search('江西(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('江西(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('江西(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('江西(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '山东'
            if re.search('山东(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('山东(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else: sht.range(f'B{i + 1}').value= '0'
            if re.search('山东(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('山东(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else: sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '河南'
            if re.search('河南(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('河南(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('河南(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('河南(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '湖北'
            if re.search('湖北(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('湖北(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('湖北(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('湖北(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '湖南'
            if re.search('湖南(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('湖南(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('湖南(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('湖南(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '广东'
            if re.search('广东(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('广东(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('广东(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('广东(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '海南'
            if re.search('海南(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('海南(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('海南(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('海南(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '贵州'
            if re.search('贵州(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('贵州(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('贵州(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('贵州(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '云南'
            if re.search('云南(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('云南(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('云南(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('云南(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '陕西'
            if re.search('陕西(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('陕西(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('陕西(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('陕西(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '甘肃'
            if re.search('甘肃(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('甘肃(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('甘肃(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('甘肃(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '青海'
            if re.search('青海(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('青海(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('青海(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('青海(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '内蒙古'
            if re.search('内蒙古(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('内蒙古(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('内蒙古(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('内蒙古(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '广西'
            if re.search('广西(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('广西(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('广西(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('广西(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '西藏'
            if re.search('西藏(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('西藏(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('西藏(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('西藏(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '宁夏'
            if re.search('宁夏(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('宁夏(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('宁夏(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('宁夏(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '新疆'
            if re.search('新疆(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('新疆(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('新疆(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('新疆(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '北京'
            if re.search('北京(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('北京(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('北京(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('北京(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '天津'
            if re.search('天津(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('天津(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('天津(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('天津(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '重庆'
            if re.search('重庆(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('重庆(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('重庆(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('重庆(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1

            newinc_demostic_num = 0
            newinc_wzz_num = 0
            sht.range(f'A{i + 1}').value = '上海'
            if re.search('上海(\d+)例', newinc_demostic) is not None:
                newinc_demostic_num = re.search('上海(\d+)例', newinc_demostic).group(1)
                sht.range(f'B{i + 1}').value = newinc_demostic_num
            else:
                sht.range(f'B{i + 1}').value = '0'
            if re.search('上海(\d+)例', newincwzz) is not None:
                newinc_wzz_num = re.search('上海(\d+)例', newincwzz).group(1)
                sht.range(f'C{i + 1}').value = newinc_wzz_num
            else:
                sht.range(f'C{i + 1}').value = '0'
            i = i + 1


wb.save('疫情.xls')
wb.close()
