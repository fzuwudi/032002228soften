import xlrd

from pyecharts.charts import Bar

#导入Excel
data = xlrd.open_workbook("疫情.xls")
table = data.sheets()[0]
xdata=[]
y1data=[]
y2data=[]

#提取数据
for i in range(2,33):
 print(table.row_values(i))

 xdata.append(table.row_values(i)[0])
 y1data.append(table.row_values(i)[1])

 y2data.append(table.row_values(i)[2])

print(xdata)

print(y1data)
print(y2data)

#生成柱状图
bar=Bar()

bar.add_xaxis(xdata)

bar.add_yaxis("本土新增",y1data)
bar.add_yaxis("本土新增无症状",y2data)


bar.render("show.html")








