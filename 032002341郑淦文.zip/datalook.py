import sys
import matplotlib.pyplot as plt
from openpyxl import load_workbook
province = ['河\n北', '山\n西', '辽\n宁', '吉\n林',  '黑\n龙\n江', '江\n苏', '浙\n江', '安\n徽', '福\n建', '江\n西', '山\n东',
            '河\n南', '湖\n北', '湖\n南', '广\n东', '海\n南', '四\n川', '贵\n州', '云\n南', '陕\n西', '甘\n肃', '青\n海', '台\n湾', '内\n蒙\n古',
            '广\n西', '西\n藏', '宁\n夏', '新\n疆', '北\n京', '天\n津', '上\n海', '重\n庆', '香\n港', '澳\n门']
province_1 = ['河北', '山西', '辽宁', '吉林',  '黑龙江', '江苏', '浙江', '安徽', '福建', '江西', '山东',
            '河南', '湖北', '湖南', '广东', '海南', '四川', '贵州', '云南', '陕西', '甘肃', '青海', '台湾', '内蒙古',
            '广西', '西藏', '宁夏', '新疆', '北京', '天津', '上海', '重庆', '香港', '澳门']
new_sum = 0
wzz_sum = 0
new_hot = []
wzz_hot = []
temp = input('请输入查询日期(****-**-**）:')
date = temp + '\n'
workbook_1 = load_workbook('./新增确诊.xlsx')
workbook_2 = load_workbook('./无症状感染.xlsx')
active_1 = workbook_1.active
active_2 = workbook_2.active
flag = 0
for col in active_1.iter_cols(min_col=2, values_only=True):  #获取查询日期当天的各省份新增数据
    if flag == 1:
        new_pass = col    #获取查询前一天数据用于比对
        break
    if col[0] in date:
        new = col
        flag = 1
        print("查询成功！请稍后")
        continue
else:
    print('未找到相应结果')   #若没有匹配的日期则停止程序
    sys.exit()
flag = 0
for col in active_2.iter_cols(min_col=2, values_only=True):  #获得查询当天各省份无症状感染者数据
    if flag == 1:
        wzz_pass = col
        break
    if col[0] in date:
        wzz = col
        flag = 1
        continue
new = list(new)  #获得的结果为元组，转为列表
del(new[0])
wzz = list(wzz)
del(wzz[0])
new_pass = list(new_pass)
del(new_pass[0])
wzz_pass = list(wzz_pass)
del(wzz_pass[0])
for i in range(0, 34):   #查询新出现新增的省份
    if int(new[i]) > int(new_pass[i]):
        new_hot.append(province_1[i])
    if int(wzz[i]) > int(wzz_pass[i]):
        wzz_hot.append(province_1[i])
for i in new_pass:
    new_sum += int(i)
print(f"今日新增感染者{new_sum}人")
for i in wzz_pass:
    wzz_sum += int(i)
print(f"今日新增无症状感染者{wzz_sum}人")
if len(new_hot) == 0:
    print("无新增出现疫情省份！")
else:
    print('新出现疫情省份：')
    for i in new_hot:
        print(i)
plt.rcParams['font.sans-serif'] = ["SimHei"]   #数据可视化部分
plt.rcParams["axes.unicode_minus"] = False  #设置使得可以正常显示中文
fig, ax = plt.subplots(nrows=2, ncols=1)  #一图双表
ax[0].bar(province, new)
ax[0].set_title('新增确诊')
ax[0].set_ylabel("人数/人")
index = 0
for label in ax[0].get_xticklabels():
    if new[index] >0:
        ax[0].text(province[index], new[index] + 0.01, "%d" % new[index], ha='center', fontsize=8)
        index +=1
        continue
    label.set_visible(False)
    index +=1


ax[1].bar(province, wzz)
ax[1].set_title('新增无症状感染者')
ax[1].set_xlabel('省份')
ax[1].set_ylabel("人数/人")
index = 0
for label in ax[1].get_xticklabels():
    if wzz[index] >0:
        ax[1].text(province[index], wzz[index] + 0.01, "%d" % wzz[index], ha='center', fontsize=8)
        index +=1
        continue
    label.set_visible(False)
    index +=1

plt.tight_layout()
plt.show()


